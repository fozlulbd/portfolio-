# Mill Floor

A workforce and production system for a knitwear factory — worker records with documents, attendance and payroll, line output, quality, yarn store, gate movement, and the commercial side (buyers, requirements, shipment dates). Built as a Vite + React + Tailwind app across 59 files under `src/`, roughly 7,100 lines.

## Running it

```bash
npm install
npm run dev      # http://localhost:5173
```

Other scripts: `npm run build` for a production bundle, `npm run preview` to serve that bundle, `npm test` to run the unit tests and the static checks together, `npm run check` for the static checks alone, and `npm run check:icons` to verify every icon name against the lucide version you actually installed (that one needs `node_modules`, so run it after `npm install`).

One thing to know up front: `npm install` was never run while this was assembled, because the sandbox it was written in has no access to the npm registry (`403 Forbidden` on every package). That means `vite build` has not been executed against this code — the first real bundle will be the one on your machine. To compensate, two suites run without any dependencies at all: 57 unit tests over the pure helpers, and a static checker that walks all 59 source files verifying that every import path resolves, every named import matches an actual export, every `C.x` / `F.x` / `palette.x` token exists, every component used in JSX was imported, every JSX element nests and closes correctly, and no dataset carries a field name React reserves as a DOM prop. Both pass. They were themselves tested by injecting eight classes of deliberate breakage and confirming each one is caught, so a clean run is worth something — but they are not a substitute for a compile, and if `npm run dev` complains about something, that gap is the likely reason.

## If the screen goes blank

This happened once for real, and the cause is worth writing down because the field name involved is one any garment app would reach for.

The dashboard charts line output with Recharts, and **Recharts spreads every field of a data row onto the SVG shape it draws**. The rows in `LINE_PERFORMANCE` originally carried `style: "NK-118"` — the style number off the job card. React received `style="NK-118"`, threw *"The `style` prop expects a mapping from style properties to values, not a string"*, and unmounted the entire tree, which is why the login screen worked and everything after it was a black rectangle. The field is called `styleNo` throughout the app for exactly this reason, and `npm run check` now fails on any `style`, `className`, `children`, `ref` or `dangerouslySetInnerHTML` key appearing in `src/data/`, so it cannot come back quietly.

That class of bug is invisible until it renders, so two other things exist to make the next one announce itself instead of hiding.

`src/components/ErrorBoundary.jsx` wraps the app in `main.jsx`, outside the theme and store providers so it survives even if one of those is the thing that broke. Any render-time throw now paints the message, the component stack and a guess at the cause on screen instead of leaving you with a blank page — that panel is what identified the `style` collision above, from the stack line `BarRectangle → Shape → path`.

`src/icons.js` is the only module that imports from `lucide-react`; every other file imports its icons from there. A component that evaluates to `undefined` throws at render time and takes the tree down the same way, and a wrong icon name is the easiest way to get one — lucide renamed a large batch partway through the 0.x line (`AlertCircle` → `CircleAlert`, `CheckCircle2` → `CircleCheckBig`, `UploadCloud` → `CloudUpload` and so on), so the same source can break by upgrading *or* by pinning older. Each icon is resolved through a `pick()` call that tries the current name, the legacy name, and a visual stand-in, ending at a plain circle — a cosmetic bug rather than a crash. `npm run check:icons` lists anything that landed on the fallback, tells you which files use it, and suggests the spelling your installed version does export.

If something still fails, open the console with `⌥⌘I` and read the first red line — it will name the file.

## Signing in

There is no password — pick a role on the login screen and the whole app reshapes around it. `pages` decides what appears in the sidebar; `can` decides which buttons exist. Permissions are absent rather than disabled, so a supervisor simply never sees an Edit button instead of seeing a greyed-out one.

| Role | Username | Sees | Can |
|---|---|---|---|
| Admin | `admin.hr` | everything | create, edit, delete, export, salary, approve leave, upload docs |
| HR Officer | `hr.officer` | people, attendance, leave, gate | everything except delete |
| Merchandiser | `merch.desk` | buyers, requirements, shipments, production, quality, store | edit, export, upload docs — no people, no payroll |
| Line Supervisor | `line.super` | own-floor workers, attendance, production, quality, leave | export only — read-only elsewhere, no salary |
| Security | `gate.desk` | gate, devices, worker and security directories | read-only, no salary, no export |

Worth trying: sign in as Security and note that the salary tab in an employee's drawer is replaced by an explanation rather than a blank panel, and that the sidebar has lost three-quarters of its entries. Sign in as Merchandiser and the People group disappears entirely. Requesting a page a role cannot see falls through to a "no access" screen rather than rendering an empty page.

## What's in the tree

```
src/
  App.jsx              shell: owns the signed-in role, current page, open drawer, open form
  main.jsx             mounts ErrorBoundary > ThemeProvider > AppStore > App
  index.css            Tailwind layers, --mf-* custom properties for both themes, focus rings
  icons.js             the single lucide-react entry point, with per-icon name fallbacks
  theme/               tokens.js (C, F, PALETTE) + ThemeProvider (flips data-theme on <html>)
  auth/                roles.js (pure data + 4 predicates) + navIcons.js (icon map)
  store/AppStore.jsx   useReducer store: people CRUD, documents, leave decisions, toasts
  data/                seeded mock factory — people, production, quality, inventory, gate,
                       leave, commercial, and the shared constants they all draw on
  lib/                 pure helpers: table (search/filter/sort/paginate), csv, payroll, format
  hooks/dom.js         media query, click-outside, escape key, body scroll lock, fake load
  components/ui/       16 primitives — Button, Card, Modal, Drawer, Tabs, Meter, KpiCard,
                       StatusPill, Skeleton, Pagination, Toaster, Stitch, …
  components/          DataTable, Sidebar, Topbar, GlobalSearch, NotificationsMenu,
                       ErrorBoundary
  components/people/   PersonForm (add/edit), PersonDrawer (detail), DocumentUploader
  pages/               13 pages — login, dashboard, people directory, attendance & salary,
                       leave, production, quality, inventory, gate, buyer, requirement,
                       shipment, no-access
tests/                 run-tests.mjs (57 tests), check-modules.mjs (static checks),
                       check-icons.mjs (needs node_modules)
```

## What actually works

The tables are real. Search, per-column filters, sorting, pagination and CSV export all run through pure functions in `lib/table.js` and `lib/csv.js` rather than being decorative — sorting sinks blanks to the bottom and is stable, and the CSV writer prefixes a quote to any cell starting with `=`, `+`, `-` or `@` so a downloaded file can't execute a formula in Excel.

Document upload is real browser file handling, which is the part you specifically asked for. Drag a file onto the uploader or use the picker; images get a thumbnail via `URL.createObjectURL`, everything gets a working download link, and type and size are validated before the file is accepted. Documents are categorised as NID copy, passport photo, appointment letter, medical fitness, training record, or Other — so anything that doesn't fit still has somewhere to go. Joining date, mobile number and emergency mobile are first-class fields on every employee, validated as Bangladeshi numbers (`01[3-9]` + 8 digits) with NID accepted at 10, 13 or 17 digits; the drawer turns the joining date into length of service.

Add, edit and delete work through the store, with a toast on every mutation and a confirmation step before a delete. Payroll is computed rather than hardcoded: house rent at 50% of basic, medical, transport and food allowances, overtime at 2× the hourly rate derived from 208 ordinary hours, absence deducted at the daily gross rate, provident fund at 5%. The tests reconcile gross, overtime, deductions and net across 25 seeded employees.

Everything else — the theme toggle, the mobile off-canvas sidebar, global search across all employees from any page, keyboard focus rings, Esc to close, and reduced-motion support — is wired rather than mocked.

## What's mock

All data is seeded in `src/data/` by a small deterministic PRNG, so the factory looks randomly staffed but is identical on every reload, and the dashboard numbers don't jump between renders. There is no backend and no persistence: a reload resets to the seeded state. The pre-seeded documents on each employee are records without real files behind them, marked `seeded: true`, so the drawer shows them but offers no download — only files you upload yourself in the session are downloadable. Uploaded files live in browser memory, not on disk.

The obvious next step, if this goes anywhere, is swapping `AppStore` for API calls; it is deliberately the only place that mutates state, so the pages wouldn't need to change.
