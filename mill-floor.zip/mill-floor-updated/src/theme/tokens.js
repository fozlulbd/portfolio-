/* ---------------------------------------------------------------
   TOKENS — a garment-mill palette: charcoal loom-room dark, a
   brass/thread-gold accent (the colour of factory nameplates and
   spool thread, not a generic SaaS blue), stitched hairlines as
   the recurring structural motif instead of plain borders.

   `C` returns var() references so a single attribute flip on
   <html> re-themes the whole app. `PALETTE` holds the raw hexes
   because Recharts needs computed colours for gradients.
----------------------------------------------------------------*/
export const C = {
  bg: "var(--mf-bg)",
  panel: "var(--mf-panel)",
  panelAlt: "var(--mf-panel-alt)",
  line: "var(--mf-line)",
  gold: "var(--mf-gold)",
  goldDim: "var(--mf-gold-dim)",
  text: "var(--mf-text)",
  muted: "var(--mf-muted)",
  green: "var(--mf-green)",
  greenDim: "var(--mf-green-dim)",
  red: "var(--mf-red)",
  redDim: "var(--mf-red-dim)",
  amber: "var(--mf-amber)",
  amberDim: "var(--mf-amber-dim)",
  shadow: "var(--mf-shadow)",
};

export const PALETTE = {
  dark: {
    bg: "#10131A",
    panel: "#171B24",
    panelAlt: "#1D2230",
    line: "#262C39",
    gold: "#C9A24B",
    text: "#EDEEF3",
    muted: "#8A92A6",
    green: "#4FA07A",
    red: "#D9694F",
    amber: "#D6A24A",
  },
  light: {
    bg: "#F4F2ED",
    panel: "#FFFEFB",
    panelAlt: "#F1EEE6",
    line: "#DDD7CA",
    gold: "#8A6A1F",
    text: "#1D2028",
    muted: "#6B7183",
    green: "#2F7A56",
    red: "#B1462C",
    amber: "#8F6414",
  },
};

/** Font stacks, referenced inline where a display/mono face is wanted. */
export const F = {
  display: "'Space Grotesk', sans-serif",
  sans: "'Inter', sans-serif",
  mono: "'JetBrains Mono', monospace",
  bn: "'Noto Sans Bengali', 'Nirmala UI', Arial, sans-serif",
};

/** The woven-texture backdrop used on the login screen. */
export function weaveBackground() {
  return {
    backgroundImage: `repeating-linear-gradient(115deg, ${C.goldDim} 0 2px, transparent 2px 26px), repeating-linear-gradient(25deg, ${C.line} 0 1px, transparent 1px 26px)`,
  };
}
