import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { PALETTE } from "./tokens.js";

const ThemeContext = createContext(null);

/**
 * Flips `data-theme` on <html>; every component reads colours through
 * CSS custom properties, so nothing else has to re-render to re-theme.
 * Charts get raw hexes via `palette`.
 */
export function ThemeProvider({ children, initial = "dark" }) {
  const [mode, setMode] = useState(initial);

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", mode);
  }, [mode]);

  const toggle = useCallback(() => setMode((m) => (m === "dark" ? "light" : "dark")), []);

  const value = useMemo(
    () => ({ mode, setMode, toggle, palette: PALETTE[mode] }),
    [mode, toggle]
  );

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error("useTheme must be used inside <ThemeProvider>");
  return ctx;
}

/** Raw hex palette for Recharts, which cannot resolve var() in gradients. */
export function usePalette() {
  return useTheme().palette;
}
