import React from "react";
import { C, F } from "../../theme/tokens.js";

/* Variants map onto how consequential the action is: `primary` for the
   one thing the screen is for, `danger` for destructive, `ghost` for
   everything else. Disabled states never rely on colour alone. */
function styleFor(variant) {
  switch (variant) {
    case "primary":
      return {
        background: `linear-gradient(180deg, rgba(255,255,255,0.22), rgba(255,255,255,0) 55%), ${C.gold}`,
        color: "#181205",
        border: "1px solid transparent",
        boxShadow: "inset 0 1px 0 rgba(255,255,255,0.25)",
      };
    case "danger":
      return { background: C.redDim, color: C.red, border: `1px solid ${C.red}` };
    case "outline":
      return { background: "transparent", color: C.text, border: `1px solid ${C.line}` };
    case "gold-soft":
      return { background: C.goldDim, color: C.gold, border: `1px solid ${C.gold}` };
    case "ghost":
    default:
      return { background: "transparent", color: C.muted, border: "1px solid transparent" };
  }
}

const SIZES = {
  xs: "px-2.5 py-1 text-[11px] gap-1",
  sm: "px-3 py-1.5 text-xs gap-1.5",
  md: "px-4 py-2 text-sm gap-2",
};

export default function Button({
  children,
  variant = "ghost",
  size = "sm",
  icon: Icon,
  iconRight: IconRight,
  disabled = false,
  title,
  className = "",
  ...rest
}) {
  return (
    <button
      type="button"
      disabled={disabled}
      title={title}
      style={{
        ...styleFor(variant),
        fontFamily: variant === "primary" ? F.display : F.sans,
        opacity: disabled ? 0.45 : 1,
        cursor: disabled ? "not-allowed" : "pointer",
      }}
      className={`inline-flex items-center justify-center rounded-md font-medium transition-all duration-150 hover:brightness-110 active:scale-[.98] ${SIZES[size]} ${className}`}
      {...rest}
    >
      {Icon && <Icon size={size === "md" ? 15 : 13} strokeWidth={2} />}
      {children}
      {IconRight && <IconRight size={size === "md" ? 15 : 13} strokeWidth={2} />}
    </button>
  );
}

/** Square icon-only control. `label` is required — it becomes the a11y name. */
export function IconButton({ icon: Icon, label, active = false, size = 36, badge = false, ...rest }) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      style={{
        width: size,
        height: size,
        background: active ? C.goldDim : C.panelAlt,
        border: `1px solid ${active ? C.gold : C.line}`,
        color: active ? C.gold : C.muted,
      }}
      className="rounded-md flex items-center justify-center shrink-0 relative transition-colors duration-150 hover:brightness-125"
      {...rest}
    >
      <Icon size={Math.round(size * 0.42)} strokeWidth={2} />
      {badge && (
        <span
          style={{ background: C.red }}
          className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full"
        />
      )}
    </button>
  );
}
