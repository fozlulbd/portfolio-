import React from "react";
import { ArrowDownRight, ArrowUpRight } from "../../icons.js";
import { C, F } from "../../theme/tokens.js";
import Card from "./Card.jsx";

/**
 * Single headline number. `delta` is a signed fraction (0.032 = +3.2%);
 * `goodDirection` says whether up is good, so absenteeism can go red
 * when it rises while output goes green.
 */
export default function KpiCard({
  label, value, sub, icon: Icon, tone, delta, goodDirection = "up", onClick,
}) {
  const rising = (delta ?? 0) >= 0;
  const deltaGood = goodDirection === "up" ? rising : !rising;
  const DeltaIcon = rising ? ArrowUpRight : ArrowDownRight;

  return (
    <Card
      as={onClick ? "button" : "div"}
      onClick={onClick}
      hover={Boolean(onClick)}
      style={{ padding: "18px 20px 16px", textAlign: "left", width: "100%", position: "relative", overflow: "hidden" }}
      className="animate-rise-in"
    >
      <div
        style={{ background: tone || C.gold, opacity: 0.55 }}
        className="absolute left-0 right-0 bottom-0 h-[3px]"
        aria-hidden="true"
      />
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p style={{ color: C.muted }} className="text-xs uppercase tracking-wide">
            {label}
          </p>
          <p style={{ fontFamily: F.display, color: C.text }} className="text-2xl font-semibold mt-1.5">
            {value}
          </p>
          <div className="flex items-center gap-2 mt-1 flex-wrap">
            {delta != null && (
              <span
                style={{ color: deltaGood ? C.green : C.red, fontFamily: F.mono }}
                className="text-[11px] inline-flex items-center gap-0.5"
              >
                <DeltaIcon size={11} strokeWidth={2.5} />
                {Math.abs(delta * 100).toFixed(1)}%
              </span>
            )}
            {sub && (
              <p style={{ color: C.muted }} className="text-xs">
                {sub}
              </p>
            )}
          </div>
        </div>
        {Icon && (
          <div
            style={{ color: tone || C.gold, background: C.goldDim }}
            className="w-9 h-9 rounded-md flex items-center justify-center shrink-0"
          >
            <Icon size={17} strokeWidth={2} />
          </div>
        )}
      </div>
    </Card>
  );
}
