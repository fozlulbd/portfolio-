import React from "react";
import { C, F } from "../../theme/tokens.js";
import Stitch from "./Stitch.jsx";

export default function Card({ children, style, className = "", hover = false, as: Tag = "div", ...rest }) {
  return (
    <Tag
      style={{
        background: C.panel,
        border: `1px solid ${C.line}`,
        boxShadow: hover ? "none" : "var(--mf-shadow)",
        ...style,
      }}
      className={`rounded-lg transition-all duration-200 ${
        hover ? "hover:-translate-y-0.5 hover:shadow-[var(--mf-shadow)] hover:border-[var(--mf-gold)]" : ""
      } ${className}`}
      {...rest}
    >
      {children}
    </Tag>
  );
}

/** Title row + optional right-hand slot, followed by a stitched rule. */
export function CardHeader({ title, subtitle, right, icon: Icon, divider = true }) {
  return (
    <>
      <div className="px-5 py-4 flex items-start justify-between gap-3 flex-wrap">
        <div className="flex items-start gap-2.5 min-w-0">
          {Icon && (
            <div
              style={{ background: C.goldDim, color: C.gold }}
              className="w-7 h-7 rounded-md flex items-center justify-center shrink-0 mt-0.5"
            >
              <Icon size={14} strokeWidth={2} />
            </div>
          )}
          <div className="min-w-0">
            <h3 style={{ fontFamily: F.display, color: C.text }} className="text-sm font-semibold truncate">
              {title}
            </h3>
            {subtitle && (
              <p style={{ color: C.muted }} className="text-xs mt-0.5">
                {subtitle}
              </p>
            )}
          </div>
        </div>
        {right && <div className="flex items-center gap-2 flex-wrap">{right}</div>}
      </div>
      {divider && <Stitch />}
    </>
  );
}
