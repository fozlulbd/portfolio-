import React, { useEffect, useRef } from "react";
import { X } from "../../icons.js";
import { C, F } from "../../theme/tokens.js";
import { useEscape, useLockBody } from "../../hooks/dom.js";
import Stitch from "./Stitch.jsx";
import { IconButton } from "./Button.jsx";

const WIDTHS = { sm: 420, md: 560, lg: 760 };

export default function Modal({ open, onClose, title, subtitle, footer, width = "md", children }) {
  const panel = useRef(null);
  useEscape(open, onClose);
  useLockBody(open);

  // Move focus into the dialog so keyboard users are not left behind it.
  useEffect(() => {
    if (!open) return;
    const first = panel.current?.querySelector(
      "input, select, textarea, button:not([aria-label='Close'])"
    );
    first?.focus();
  }, [open]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start sm:items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div
        className="fixed inset-0 animate-fade-in"
        style={{ background: "rgba(8,10,14,.66)", backdropFilter: "blur(2px)" }}
        onClick={onClose}
      />
      <div
        ref={panel}
        role="dialog"
        aria-modal="true"
        aria-label={title}
        style={{
          background: C.panel,
          border: `1px solid ${C.line}`,
          boxShadow: C.shadow,
          width: "100%",
          maxWidth: WIDTHS[width],
        }}
        className="relative rounded-lg animate-rise-in my-auto"
      >
        <div className="px-5 py-4 flex items-start justify-between gap-4">
          <div>
            <h2 style={{ fontFamily: F.display, color: C.text }} className="text-base font-semibold">
              {title}
            </h2>
            {subtitle && (
              <p style={{ color: C.muted }} className="text-xs mt-0.5">
                {subtitle}
              </p>
            )}
          </div>
          <IconButton icon={X} label="Close" size={30} onClick={onClose} />
        </div>
        <Stitch />
        <div className="px-5 py-5 max-h-[62vh] overflow-y-auto">{children}</div>
        {footer && (
          <>
            <Stitch />
            <div className="px-5 py-3.5 flex items-center justify-end gap-2 flex-wrap">{footer}</div>
          </>
        )}
      </div>
    </div>
  );
}

/** Small yes/no dialog for destructive actions. */
export function ConfirmModal({ open, onClose, onConfirm, title, message, confirmLabel = "Delete" }) {
  return (
    <Modal
      open={open}
      onClose={onClose}
      title={title}
      width="sm"
      footer={
        <>
          <button
            type="button"
            onClick={onClose}
            style={{ color: C.muted, border: `1px solid ${C.line}` }}
            className="px-3 py-1.5 rounded-md text-xs"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={() => {
              onConfirm();
              onClose();
            }}
            style={{ background: C.redDim, color: C.red, border: `1px solid ${C.red}` }}
            className="px-3 py-1.5 rounded-md text-xs font-medium"
          >
            {confirmLabel}
          </button>
        </>
      }
    >
      <p style={{ color: C.muted }} className="text-sm leading-relaxed">
        {message}
      </p>
    </Modal>
  );
}
