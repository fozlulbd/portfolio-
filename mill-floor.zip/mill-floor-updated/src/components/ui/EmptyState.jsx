import React from "react";
import { SearchX } from "../../icons.js";
import { C, F } from "../../theme/tokens.js";
import Button from "./Button.jsx";

export default function EmptyState({
  icon: Icon = SearchX,
  title = "Nothing here",
  message,
  actionLabel,
  onAction,
}) {
  return (
    <div className="py-14 px-6 flex flex-col items-center text-center animate-fade-in">
      <div
        style={{ background: C.goldDim, color: C.gold, border: `1px solid ${C.line}` }}
        className="w-12 h-12 rounded-lg flex items-center justify-center mb-3.5"
      >
        <Icon size={20} strokeWidth={1.8} />
      </div>
      <p style={{ fontFamily: F.display, color: C.text }} className="text-sm font-semibold">
        {title}
      </p>
      {message && (
        <p style={{ color: C.muted }} className="text-xs mt-1.5 max-w-sm leading-relaxed">
          {message}
        </p>
      )}
      {actionLabel && (
        <Button variant="gold-soft" size="sm" className="mt-4" onClick={onAction}>
          {actionLabel}
        </Button>
      )}
    </div>
  );
}
