import React from "react";
import { C, F } from "../../theme/tokens.js";

/**
 * Horizontal progress meter. Colour is derived from the value against
 * `good`/`warn` thresholds so a struggling line reads red without the
 * caller having to decide.
 */
export default function Meter({ value, good = 0.95, warn = 0.85, height = 6, label, right, tone }) {
  const v = Math.max(0, Math.min(1.2, Number(value) || 0));
  const colour = tone || (v >= good ? C.green : v >= warn ? C.amber : C.red);

  return (
    <div className="w-full">
      {(label || right) && (
        <div className="flex items-center justify-between mb-1.5">
          {label && (
            <span style={{ color: C.muted }} className="text-[11px]">
              {label}
            </span>
          )}
          {right && (
            <span style={{ color: colour, fontFamily: F.mono }} className="text-[11px] font-medium">
              {right}
            </span>
          )}
        </div>
      )}
      <div
        role="progressbar"
        aria-valuenow={Math.round(v * 100)}
        aria-valuemin={0}
        aria-valuemax={100}
        style={{ background: C.line, height, borderRadius: height }}
        className="w-full overflow-hidden"
      >
        <div
          style={{
            width: `${Math.min(100, v * 100)}%`,
            background: colour,
            height: "100%",
            borderRadius: height,
            transition: "width .5s cubic-bezier(.22,.61,.36,1)",
          }}
        />
      </div>
    </div>
  );
}
