import React from "react";
import { C, F } from "../../theme/tokens.js";
import { initials } from "../../lib/format.js";

const SIZES = { sm: 26, md: 32, lg: 44, xl: 64 };

export default function Avatar({ name = "", size = "md", src, ring = false }) {
  const px = SIZES[size] || SIZES.md;
  const fontSize = px <= 26 ? 10 : px <= 32 ? 11 : px <= 44 ? 14 : 20;

  return (
    <div
      title={name}
      style={{
        width: px,
        height: px,
        background: src ? `center/cover url(${src})` : C.goldDim,
        color: C.gold,
        border: `1px solid ${ring ? C.gold : C.line}`,
        fontFamily: F.display,
        fontSize,
      }}
      className="rounded-full flex items-center justify-center font-semibold shrink-0 overflow-hidden"
    >
      {!src && initials(name)}
    </div>
  );
}
