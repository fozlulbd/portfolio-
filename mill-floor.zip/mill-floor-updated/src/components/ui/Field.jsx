import React from "react";
import { AlertCircle } from "../../icons.js";
import { C, F } from "../../theme/tokens.js";

const CONTROL =
  "w-full rounded-md px-3 py-2.5 text-sm outline-none transition-colors duration-150";

export function Label({ children, htmlFor, required = false, hint }) {
  return (
    <label htmlFor={htmlFor} style={{ color: C.muted }} className="text-xs block mb-1.5">
      {children}
      {required && <span style={{ color: C.gold }}> *</span>}
      {hint && <span style={{ color: C.muted }} className="opacity-70"> · {hint}</span>}
    </label>
  );
}

export function FieldError({ children }) {
  if (!children) return null;
  return (
    <p style={{ color: C.red }} className="text-[11px] mt-1 flex items-center gap-1">
      <AlertCircle size={11} /> {children}
    </p>
  );
}

/** Label + control + error, the unit every form row is built from. */
export function Field({ label, required, hint, error, children, className = "" }) {
  return (
    <div className={className}>
      {label && <Label required={required} hint={hint}>{label}</Label>}
      {children}
      <FieldError>{error}</FieldError>
    </div>
  );
}

export function Input({ error, mono = false, ...rest }) {
  return (
    <input
      style={{
        background: C.panelAlt,
        border: `1px solid ${error ? C.red : C.line}`,
        color: C.text,
        fontFamily: mono ? F.mono : F.sans,
      }}
      className={CONTROL}
      {...rest}
    />
  );
}

export function Select({ error, options = [], placeholder, ...rest }) {
  return (
    <select
      style={{
        background: C.panelAlt,
        border: `1px solid ${error ? C.red : C.line}`,
        color: C.text,
      }}
      className={`${CONTROL} appearance-none cursor-pointer`}
      {...rest}
    >
      {placeholder && <option value="">{placeholder}</option>}
      {options.map((o) => {
        const value = typeof o === "string" ? o : o.value;
        const label = typeof o === "string" ? o : o.label;
        return (
          <option key={value} value={value}>
            {label}
          </option>
        );
      })}
    </select>
  );
}

export function Textarea({ error, rows = 3, ...rest }) {
  return (
    <textarea
      rows={rows}
      style={{
        background: C.panelAlt,
        border: `1px solid ${error ? C.red : C.line}`,
        color: C.text,
      }}
      className={`${CONTROL} resize-y`}
      {...rest}
    />
  );
}

/** Compact pill-shaped select used in table toolbars. */
export function FilterSelect({ label, value, onChange, options }) {
  const active = value !== "" && value != null;
  return (
    <select
      aria-label={label}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      style={{
        background: active ? C.goldDim : C.panelAlt,
        border: `1px solid ${active ? C.gold : C.line}`,
        color: active ? C.gold : C.muted,
      }}
      className="rounded-full px-3 py-1.5 text-xs outline-none cursor-pointer appearance-none transition-colors"
    >
      <option value="">{label}: all</option>
      {options.map((o) => (
        <option key={o} value={o}>
          {label}: {o}
        </option>
      ))}
    </select>
  );
}
