import React from "react";
import {
  CheckCircle2, XCircle, AlertCircle, Clock3, ArrowDownLeft,
  ArrowUpRight, PackageCheck, PackageX, Ban,
} from "../../icons.js";
import { C, F } from "../../theme/tokens.js";

/* One place that decides what colour a word is. Anything not listed
   falls back to a neutral chip rather than a misleading green. */
const MAP = {
  Present: { c: C.green, bg: C.greenDim, Icon: CheckCircle2 },
  Late: { c: C.amber, bg: C.amberDim, Icon: AlertCircle },
  Absent: { c: C.red, bg: C.redDim, Icon: XCircle },
  "On leave": { c: C.muted, bg: C.goldDim, Icon: Clock3 },

  "On track": { c: C.green, bg: C.greenDim, Icon: CheckCircle2 },
  "At risk": { c: C.amber, bg: C.amberDim, Icon: AlertCircle },
  Delayed: { c: C.red, bg: C.redDim, Icon: XCircle },

  Pass: { c: C.green, bg: C.greenDim, Icon: PackageCheck },
  Fail: { c: C.red, bg: C.redDim, Icon: PackageX },

  Approved: { c: C.green, bg: C.greenDim, Icon: CheckCircle2 },
  Pending: { c: C.amber, bg: C.amberDim, Icon: Clock3 },
  Rejected: { c: C.red, bg: C.redDim, Icon: Ban },

  "In stock": { c: C.green, bg: C.greenDim, Icon: PackageCheck },
  Reorder: { c: C.amber, bg: C.amberDim, Icon: AlertCircle },
  "Out of stock": { c: C.red, bg: C.redDim, Icon: PackageX },

  Online: { c: C.green, bg: C.greenDim, Icon: CheckCircle2 },
  Offline: { c: C.red, bg: C.redDim, Icon: XCircle },

  IN: { c: C.green, bg: C.greenDim, Icon: ArrowDownLeft },
  OUT: { c: C.amber, bg: C.amberDim, Icon: ArrowUpRight },

  Inside: { c: C.green, bg: C.greenDim, Icon: CheckCircle2 },
  Left: { c: C.muted, bg: C.goldDim, Icon: ArrowUpRight },
};

export default function StatusPill({ status, size = "sm" }) {
  const m = MAP[status] || { c: C.muted, bg: C.goldDim, Icon: null };
  const { Icon } = m;
  const pad = size === "xs" ? "px-2 py-0.5" : "px-2.5 py-1";
  return (
    <span
      style={{ color: m.c, background: m.bg, fontFamily: F.mono }}
      className={`inline-flex items-center gap-1.5 ${pad} rounded text-xs font-medium whitespace-nowrap`}
    >
      {Icon && <Icon size={12} strokeWidth={2.5} />}
      {status}
    </span>
  );
}

/** Plain outlined chip for values that carry no health signal. */
export function Badge({ children, tone, mono = true }) {
  return (
    <span
      style={{
        color: tone || C.muted,
        border: `1px solid ${C.line}`,
        fontFamily: mono ? F.mono : F.sans,
      }}
      className="inline-flex items-center gap-1.5 text-xs px-2.5 py-1 rounded whitespace-nowrap"
    >
      {children}
    </span>
  );
}
