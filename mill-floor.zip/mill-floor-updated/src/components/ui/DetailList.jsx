import React from "react";
import { C, F } from "../../theme/tokens.js";

/** Two-column label/value list used throughout the detail drawer. */
export default function DetailList({ items, columns = 2 }) {
  return (
    <dl className={`grid ${columns === 1 ? "grid-cols-1" : "grid-cols-2"} gap-x-4 gap-y-3.5`}>
      {items
        .filter((it) => it && it.value !== undefined)
        .map((it) => (
          <div key={it.label} className={it.wide ? "col-span-full" : undefined}>
            <dt style={{ color: C.muted }} className="text-[11px] uppercase tracking-wide">
              {it.label}
            </dt>
            <dd
              style={{
                color: it.tone || C.text,
                fontFamily: it.mono ? F.mono : F.sans,
              }}
              className="text-sm mt-0.5 break-words"
            >
              {it.value === "" || it.value === null ? "—" : it.value}
            </dd>
          </div>
        ))}
    </dl>
  );
}
