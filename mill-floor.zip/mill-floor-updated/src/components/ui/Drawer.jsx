import React from "react";
import { X } from "../../icons.js";
import { C, F } from "../../theme/tokens.js";
import { useEscape, useLockBody } from "../../hooks/dom.js";
import Stitch from "./Stitch.jsx";
import { IconButton } from "./Button.jsx";

/** Right-hand sheet for record detail. Full-width on phones. */
export default function Drawer({ open, onClose, title, subtitle, header, footer, width = 480, children }) {
  useEscape(open, onClose);
  useLockBody(open);
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      <div
        className="fixed inset-0 animate-fade-in"
        style={{ background: "rgba(8,10,14,.6)", backdropFilter: "blur(2px)" }}
        onClick={onClose}
      />
      <aside
        role="dialog"
        aria-modal="true"
        aria-label={title}
        style={{
          background: C.panel,
          borderLeft: `1px solid ${C.line}`,
          boxShadow: C.shadow,
          width: "100%",
          maxWidth: width,
        }}
        className="relative h-full flex flex-col animate-slide-left"
      >
        <div className="px-5 py-4 flex items-start justify-between gap-3">
          <div className="min-w-0">
            <h2 style={{ fontFamily: F.display, color: C.text }} className="text-base font-semibold truncate">
              {title}
            </h2>
            {subtitle && (
              <p style={{ color: C.muted }} className="text-xs mt-0.5 truncate">
                {subtitle}
              </p>
            )}
          </div>
          <IconButton icon={X} label="Close" size={30} onClick={onClose} />
        </div>
        {header}
        <Stitch />
        <div className="flex-1 overflow-y-auto px-5 py-5">{children}</div>
        {footer && (
          <>
            <Stitch />
            <div className="px-5 py-3.5 flex items-center justify-end gap-2 flex-wrap">{footer}</div>
          </>
        )}
      </aside>
    </div>
  );
}
