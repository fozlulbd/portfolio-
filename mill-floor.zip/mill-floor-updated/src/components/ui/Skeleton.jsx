import React from "react";
import { C } from "../../theme/tokens.js";

/** A single shimmering placeholder block. */
export default function Skeleton({ w = "100%", h = 12, radius = 6, className = "" }) {
  return (
    <div
      aria-hidden="true"
      style={{
        width: w,
        height: h,
        borderRadius: radius,
        background: `linear-gradient(90deg, ${C.panelAlt} 0%, ${C.line} 40%, ${C.panelAlt} 80%)`,
        backgroundSize: "500px 100%",
      }}
      className={`animate-shimmer ${className}`}
    />
  );
}

export function TableSkeleton({ rows = 6, cols = 5 }) {
  return (
    <div className="p-5 space-y-3">
      {Array.from({ length: rows }).map((_, r) => (
        <div key={r} className="flex items-center gap-4">
          {Array.from({ length: cols }).map((_, c) => (
            <Skeleton key={c} w={c === 1 ? "26%" : `${Math.max(10, 18 - c)}%`} h={c === 1 ? 16 : 10} />
          ))}
        </div>
      ))}
    </div>
  );
}

export function CardsSkeleton({ count = 4, height = 92 }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
      {Array.from({ length: count }).map((_, i) => (
        <div
          key={i}
          style={{ background: C.panel, border: `1px solid ${C.line}`, height }}
          className="rounded-lg p-4 flex flex-col justify-between"
        >
          <Skeleton w="52%" h={9} />
          <Skeleton w="38%" h={20} />
          <Skeleton w="64%" h={8} />
        </div>
      ))}
    </div>
  );
}

export function ChartSkeleton({ height = 220 }) {
  return (
    <div style={{ height }} className="flex items-end gap-2 px-1">
      {[42, 58, 36, 71, 52, 84, 63, 48, 76].map((h, i) => (
        <Skeleton key={i} w="100%" h={`${h}%`} radius={4} />
      ))}
    </div>
  );
}
