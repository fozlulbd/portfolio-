import React from "react";
import { ChevronLeft, ChevronRight } from "../../icons.js";
import { C, F } from "../../theme/tokens.js";

const SIZES = [10, 25, 50, 100];

export default function Pagination({ page, pageCount, from, to, total, pageSize, onPage, onPageSize }) {
  return (
    <div className="px-5 py-3 flex items-center justify-between gap-3 flex-wrap">
      <p style={{ color: C.muted, fontFamily: F.mono }} className="text-[11px]">
        {total === 0 ? "No rows" : `${from}–${to} of ${total}`}
      </p>

      <div className="flex items-center gap-2">
        <select
          aria-label="Rows per page"
          value={pageSize}
          onChange={(e) => onPageSize(Number(e.target.value))}
          style={{ background: C.panelAlt, border: `1px solid ${C.line}`, color: C.muted }}
          className="rounded-md px-2 py-1.5 text-[11px] outline-none cursor-pointer"
        >
          {SIZES.map((s) => (
            <option key={s} value={s}>
              {s} / page
            </option>
          ))}
        </select>

        <div className="flex items-center gap-1">
          <button
            type="button"
            aria-label="Previous page"
            disabled={page <= 1}
            onClick={() => onPage(page - 1)}
            style={{
              border: `1px solid ${C.line}`,
              color: page <= 1 ? C.line : C.muted,
              cursor: page <= 1 ? "not-allowed" : "pointer",
            }}
            className="w-7 h-7 rounded-md flex items-center justify-center"
          >
            <ChevronLeft size={14} />
          </button>
          <span style={{ color: C.muted, fontFamily: F.mono }} className="text-[11px] px-1.5">
            {page} / {pageCount}
          </span>
          <button
            type="button"
            aria-label="Next page"
            disabled={page >= pageCount}
            onClick={() => onPage(page + 1)}
            style={{
              border: `1px solid ${C.line}`,
              color: page >= pageCount ? C.line : C.muted,
              cursor: page >= pageCount ? "not-allowed" : "pointer",
            }}
            className="w-7 h-7 rounded-md flex items-center justify-center"
          >
            <ChevronRight size={14} />
          </button>
        </div>
      </div>
    </div>
  );
}
