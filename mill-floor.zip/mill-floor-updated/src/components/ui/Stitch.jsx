import React from "react";
import { C } from "../../theme/tokens.js";

/**
 * The recurring structural motif: a dashed hairline that reads as a
 * row of stitches rather than a plain CSS border.
 */
export default function Stitch({ style, vertical = false }) {
  return (
    <div
      aria-hidden="true"
      style={
        vertical
          ? {
              width: 1,
              alignSelf: "stretch",
              backgroundImage: `repeating-linear-gradient(180deg, ${C.line} 0 6px, transparent 6px 13px)`,
              ...style,
            }
          : {
              height: 1,
              backgroundImage: `repeating-linear-gradient(90deg, ${C.line} 0 6px, transparent 6px 13px)`,
              ...style,
            }
      }
    />
  );
}
