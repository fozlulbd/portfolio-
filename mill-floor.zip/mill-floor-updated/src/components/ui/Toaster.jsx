import React from "react";
import { CheckCircle2, AlertTriangle, Trash2, Info } from "../../icons.js";
import { C, F } from "../../theme/tokens.js";
import { useStore } from "../../store/AppStore.jsx";

const TONE = {
  success: { c: C.green, bg: C.greenDim, Icon: CheckCircle2 },
  warn: { c: C.amber, bg: C.amberDim, Icon: AlertTriangle },
  danger: { c: C.red, bg: C.redDim, Icon: Trash2 },
  info: { c: C.gold, bg: C.goldDim, Icon: Info },
};

/** Bottom-right action confirmations. Auto-dismissed by the store. */
export default function Toaster() {
  const { toasts, dismissToast } = useStore();
  if (!toasts.length) return null;

  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed bottom-4 right-4 z-[60] flex flex-col gap-2 items-end pointer-events-none"
    >
      {toasts.map((t) => {
        const tone = TONE[t.tone] || TONE.info;
        const { Icon } = tone;
        return (
          <button
            key={t.id}
            onClick={() => dismissToast(t.id)}
            style={{
              background: C.panel,
              border: `1px solid ${C.line}`,
              borderLeft: `3px solid ${tone.c}`,
              boxShadow: C.shadow,
              fontFamily: F.sans,
            }}
            className="pointer-events-auto max-w-xs text-left rounded-md pl-3 pr-4 py-2.5 flex items-start gap-2.5 animate-rise-in"
          >
            <span style={{ color: tone.c, background: tone.bg }} className="w-5 h-5 rounded flex items-center justify-center shrink-0 mt-0.5">
              <Icon size={12} strokeWidth={2.5} />
            </span>
            <span style={{ color: C.text }} className="text-xs leading-relaxed">
              {t.message}
            </span>
          </button>
        );
      })}
    </div>
  );
}
