import React from "react";
import { C } from "../../theme/tokens.js";

/**
 * Pill tab strip.
 * @param {{key:string,label:string,count?:number}[]} tabs
 */
export default function Tabs({ tabs, value, onChange, size = "sm" }) {
  const pad = size === "md" ? "px-4 py-2 text-sm" : "px-4 py-1.5 text-xs";
  return (
    <div role="tablist" className="flex gap-2 flex-wrap">
      {tabs.map((t) => {
        const active = value === t.key;
        return (
          <button
            key={t.key}
            role="tab"
            aria-selected={active}
            onClick={() => onChange(t.key)}
            style={{
              background: active ? C.goldDim : "transparent",
              color: active ? C.gold : C.muted,
              border: `1px solid ${active ? C.gold : C.line}`,
            }}
            className={`${pad} rounded-full font-medium transition-colors duration-150 inline-flex items-center gap-2`}
          >
            {t.label}
            {t.count != null && (
              <span
                style={{ background: active ? C.gold : C.line, color: active ? "#181205" : C.muted }}
                className="text-[10px] leading-none px-1.5 py-0.5 rounded-full font-semibold"
              >
                {t.count}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}
