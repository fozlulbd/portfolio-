import React, { useState } from "react";
import { IdCard, RotateCw } from "../../icons.js";
import { C, F } from "../../theme/tokens.js";
import { code39Svg, code39Supported } from "../../lib/barcode.js";
import { qrSvg, qrSupported } from "../../lib/qrcode.js";
import { initials } from "../../lib/format.js";
import { FACTORY_NAME_BN, EMPLOYMENT_BN, ID_CARD_LABELS_BN, bnDate, toBnDigits } from "../../data/constants.js";

const L = ID_CARD_LABELS_BN;

/* Orange badge palette — kept local to this component (rather than
   the app's gold theme tokens) because the card is a printed
   physical document with its own fixed identity, matching the
   factory's abstract-chevron badge template regardless of which
   in-app theme (light/dark) is active around it. */
const OR = {
  a: "#FF8A3D",
  b: "#F0591B",
  dark: "#C94910",
  ink: "#221806",
  text: "#14161c",
  muted: "#8A8577",
  line: "#EEE3D6",
  photoBg: "#F1EEE6",
};

/** Inline SVG string -> DOM, for the Code 39 gate-scan barcode. */
function Barcode({ value, height = 30 }) {
  if (!code39Supported(value)) return null;
  const svg = code39Svg(value, { narrow: 1.5, height, showText: true });
  return <div style={{ width: "100%" }} dangerouslySetInnerHTML={{ __html: svg }} />;
}

/** Inline SVG string -> DOM, for the worker-ID QR on the card back. */
function QrCode({ value, size = 62 }) {
  if (!qrSupported(value)) return null;
  const svg = qrSvg(value, { size, margin: 1 });
  return <div style={{ width: size, height: size }} dangerouslySetInnerHTML={{ __html: svg }} />;
}

/* The factory mark — a small bracket glyph on an ink chip, standing
   in for the printed logo in the template this badge is modelled on. */
function LogoMark({ light = false }) {
  return (
    <div className="flex items-center gap-1">
      <div
        style={{ background: light ? "rgba(255,255,255,.22)" : OR.ink, color: "#fff" }}
        className="w-5 h-5 rounded flex items-center justify-center shrink-0"
      >
        <IdCard size={11} />
      </div>
    </div>
  );
}

/* Fixed-size circular photo slot — always the same diameter no matter
   what the uploaded image's own dimensions are, via object-fit: cover,
   so the badge layout never shifts between employees. Falls back to
   initials on a soft tint when no photo has been uploaded. */
function PhotoSlot({ name, src }) {
  return (
    <div
      style={{
        width: 84,
        height: 84,
        background: src ? `center/cover url(${src})` : OR.photoBg,
        border: "3px solid #fff",
        boxShadow: "0 1px 3px rgba(0,0,0,.18), 0 0 0 1.5px " + OR.b,
        color: OR.b,
        fontFamily: F.display,
      }}
      className="rounded-full flex items-center justify-center text-xl font-semibold shrink-0 overflow-hidden mx-auto"
    >
      {!src && initials(name)}
    </div>
  );
}

/** Bangla label over an English/mono value — the shape a real factory
    পরিচয় পত্র row takes: label in Bangla, the recorded value as-is. */
function Row({ label, value }) {
  return (
    <div className="flex items-baseline justify-between gap-2">
      <span style={{ opacity: 0.6, fontFamily: F.bn, color: OR.muted }} className="text-[9.5px] shrink-0">{label}</span>
      <span style={{ color: OR.text }} className="text-[10.5px] text-right truncate">{value || "—"}</span>
    </div>
  );
}

function FrontFace({ person }) {
  return (
    <div className="flex flex-col h-full" style={{ color: OR.text }}>
      {/* chevron header, orange gradient, clipped to a downward point
          so the photo sits inset into it like the template badge */}
      <div
        style={{
          background: `linear-gradient(135deg, ${OR.a}, ${OR.b})`,
          clipPath: "polygon(0 0, 100% 0, 100% 58%, 50% 72%, 0 58%)",
        }}
        className="px-3.5 pt-2.5 pb-4 flex items-start justify-between"
      >
        <span style={{ color: "#fff", fontFamily: F.bn, opacity: 0.95 }} className="text-[8.5px] font-semibold leading-tight max-w-[110px]">
          {FACTORY_NAME_BN}
        </span>
        <LogoMark light />
      </div>

      <div className="px-3.5 -mt-7">
        <PhotoSlot name={person.name} src={person.photo} />
      </div>

      <div className="px-3.5 mt-2 text-center">
        <p style={{ fontFamily: F.display }} className="text-[14px] font-semibold leading-tight">{person.name}</p>
        <p style={{ color: OR.muted }} className="text-[10.5px] leading-tight mt-0.5">{person.designation || person.role}</p>
        <p style={{ fontFamily: F.mono, color: OR.b }} className="text-[11.5px] mt-1 font-semibold">{person.id}</p>
      </div>

      <div className="px-3.5 flex items-center justify-center gap-1.5 mt-2">
        <span
          style={{ background: "#FBE3D2", color: OR.dark, fontFamily: F.mono }}
          className="text-[9px] font-semibold px-1.5 py-0.5 rounded"
        >
          {person.bloodGroup || "—"}
        </span>
        <span style={{ color: OR.muted }} className="text-[9px]">{person.role}</span>
      </div>

      <div className="px-3.5 flex-1 flex flex-col">
        <div style={{ borderTop: `1px dashed ${OR.line}` }} className="mt-2.5 pt-2 space-y-1">
          <Row label={L.idNo} value={toBnDigits(String(person.id).replace(/\D/g, ""))} />
          <Row label={L.joinDate} value={bnDate(person.joinDate)} />
          <Row label={L.employment} value={EMPLOYMENT_BN[person.employment] || person.employment} />
        </div>
        <div className="flex-1" />
        <div style={{ borderTop: `1px solid ${OR.line}` }} className="pt-2 mt-2 pb-3">
          <Barcode value={person.id} />
        </div>
      </div>
    </div>
  );
}

function BackFace({ person }) {
  return (
    <div className="flex h-full" style={{ color: OR.text }}>
      <div className="flex-1 min-w-0 px-3.5 pt-3.5 pb-3 flex flex-col">
        <p style={{ opacity: 0.7, fontFamily: F.bn, color: OR.dark }} className="text-[10px] font-semibold mb-2">{L.backTitle}</p>
        <div className="space-y-1.5">
          <Row label={L.dept} value={person.dept} />
          <Row label={L.line} value={person.line} />
          <Row label={L.shift} value={person.shift} />
          <Row label={L.employment} value={EMPLOYMENT_BN[person.employment] || person.employment} />
          <Row label={L.joinDate} value={bnDate(person.joinDate)} />
          <Row label={L.mobile} value={person.mobile ? toBnDigits(person.mobile) : "—"} />
          <Row label={L.nid} value={person.nid ? toBnDigits(person.nid) : "—"} />
          <Row label={L.district} value={person.district} />
        </div>
        <div style={{ borderTop: `1px solid ${OR.line}` }} className="mt-2.5 pt-2.5">
          <p style={{ opacity: 0.7, fontFamily: F.bn, color: OR.dark }} className="text-[9.5px] mb-1 font-semibold">{L.emergencyTitle}</p>
          <Row label={L.emergencyName} value={person.emergencyName} />
          <Row label={L.emergencyMobile} value={person.emergencyMobile ? toBnDigits(person.emergencyMobile) : "—"} />
        </div>
        <div className="flex-1" />
        <div style={{ borderTop: `1px solid ${OR.line}` }} className="pt-2 mt-2 flex items-center gap-2">
          <QrCode value={person.id} size={54} />
          <div className="min-w-0">
            <p style={{ opacity: 0.7, fontFamily: F.bn, color: OR.muted }} className="text-[8px] leading-tight">{L.qrScan}</p>
            <p style={{ fontFamily: F.mono, color: OR.b }} className="text-[10px] font-semibold truncate">{person.id}</p>
          </div>
        </div>
        <p
          style={{ opacity: 0.75, fontFamily: F.bn, color: OR.muted, borderTop: `1px solid ${OR.line}` }}
          className="text-[8px] leading-snug pt-2"
        >
          {L.ownership}
        </p>
      </div>

      {/* orange side panel, echoing the template's angled department
          strip — a fixed decorative band, not a data field */}
      <div
        style={{
          width: 30,
          background: `linear-gradient(160deg, ${OR.a}, ${OR.b})`,
          clipPath: "polygon(35% 0, 100% 0, 100% 100%, 0 100%)",
        }}
        className="shrink-0 flex items-center justify-center py-4"
      >
        <span
          style={{ writingMode: "vertical-rl", color: "#fff", fontFamily: F.bn, letterSpacing: "0.06em" }}
          className="text-[9px] font-semibold rotate-180"
        >
          {L.brandSub}
        </span>
      </div>
    </div>
  );
}

/**
 * On-screen badge — a long, portrait "lanyard" frame with a front
 * (photo, name, role, blood group, gate-scan barcode) and a back
 * (full employee record) reachable via the flip control, labelled in
 * Bangla the way the factory's own পরিচয় পত্র is, styled after the
 * factory's orange abstract-chevron badge template. `dense` shows
 * only the front with no flip, for contexts too small for both sides
 * (kept for callers that just want a quick identity chip).
 */
export default function IdCardBadge({ person, dense = false }) {
  const [flipped, setFlipped] = useState(false);

  return (
    <div
      style={{ background: "#fff", borderRadius: 14, border: `1px solid ${C.line}`, position: "relative" }}
      className="overflow-hidden mx-auto w-full max-w-[210px]"
    >
      {/* lanyard punch */}
      <div
        style={{ background: "#fff", border: "1px solid " + OR.line }}
        className="absolute left-1/2 -translate-x-1/2 top-1.5 w-5 h-5 rounded-full z-10"
        aria-hidden="true"
      />

      <div style={{ minHeight: 268 }}>
        {dense || !flipped ? <FrontFace person={person} /> : <BackFace person={person} />}
      </div>

      {!dense && (
        <div
          style={{ background: `linear-gradient(135deg, ${OR.a}, ${OR.b})` }}
          className="px-3 py-1.5 flex items-center justify-between"
        >
          <span style={{ color: "#fff" }} className="text-[8.5px] font-medium opacity-90">
            {flipped ? "Back" : "Front"} · tap ↻ to flip
          </span>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setFlipped((f) => !f);
            }}
            aria-label={flipped ? "Show front of card" : "Show back of card"}
            title={flipped ? "Show front" : "Show back"}
            style={{ color: "#fff" }}
            className="w-5 h-5 rounded-full flex items-center justify-center hover:bg-white/20"
          >
            <RotateCw size={11} strokeWidth={2.5} />
          </button>
        </div>
      )}
    </div>
  );
}
