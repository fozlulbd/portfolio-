import React, { useMemo, useState } from "react";
import { Pencil, Trash2, Phone, Wallet, CalendarClock, Paperclip, UserRound, Printer } from "../../icons.js";
import { C, F } from "../../theme/tokens.js";
import { formatMobile, prettyDate, taka, tenure } from "../../lib/format.js";
import { computeSalary, mockMonthInputs } from "../../lib/payroll.js";
import { printPayslip } from "../../lib/print.js";
import Drawer from "../ui/Drawer.jsx";
import Button from "../ui/Button.jsx";
import Tabs from "../ui/Tabs.jsx";
import StatusPill, { Badge } from "../ui/StatusPill.jsx";
import DetailList from "../ui/DetailList.jsx";
import Stitch from "../ui/Stitch.jsx";
import DocumentUploader from "./DocumentUploader.jsx";
import PhotoUploader from "./PhotoUploader.jsx";
import { useStore } from "../../store/AppStore.jsx";

/* Deterministic 21-day attendance history so the strip is stable
   between renders — a real build would read this from the device log. */
function history(person) {
  const seed = String(person.id)
    .split("")
    .reduce((a, ch) => a + ch.charCodeAt(0), 0);
  return Array.from({ length: 21 }, (_, i) => {
    const n = (seed + i * 13) % 17;
    if (n === 0) return "Absent";
    if (n === 3 || n === 11) return "Late";
    if (n === 7) return "On leave";
    return "Present";
  });
}

const DOT = {
  Present: C.green,
  Late: C.amber,
  Absent: C.red,
  "On leave": C.muted,
};

export default function PersonDrawer({
  person, open, onClose, onEdit, onDelete, onAddDocs, onRemoveDoc,
  canEdit = false, canDelete = false, canSeeSalary = false, canUploadDocs = false, actor = "you",
}) {
  const [tab, setTab] = useState("profile");
  const { setPersonPhoto } = useStore();
  if (!person) return null;

  const days = useMemo(() => history(person), [person]);
  const month = useMemo(() => mockMonthInputs(person), [person]);
  const pay = useMemo(() => computeSalary(person, month), [person, month]);
  const counts = days.reduce((a, d) => ({ ...a, [d]: (a[d] || 0) + 1 }), {});

  return (
    <Drawer
      open={open}
      onClose={onClose}
      title={person.name}
      subtitle={`${person.id} · ${person.designation}`}
      header={
        <div className="px-5 pb-4 flex items-center gap-3.5">
          <PhotoUploader
            name={person.name}
            src={person.photo}
            size={64}
            editable={canEdit}
            onChange={(url) => setPersonPhoto(person.id, url)}
          />
          <div className="min-w-0 space-y-1.5">
            <div className="flex items-center gap-2 flex-wrap">
              <StatusPill status={person.status} />
              <Badge>{person.employment}</Badge>
            </div>
            <p style={{ color: C.muted }} className="text-xs">
              {person.dept} · {person.line !== "—" ? `${person.line} · ` : ""}
              {person.shift} shift
            </p>
          </div>
        </div>
      }
      footer={
        <>
          <a
            href={`tel:${person.mobile}`}
            style={{ color: C.muted, border: `1px solid ${C.line}` }}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs mr-auto"
          >
            <Phone size={13} /> Call
          </a>
          {canDelete && (
            <Button variant="danger" icon={Trash2} onClick={() => onDelete(person)}>
              Delete
            </Button>
          )}
          {canEdit && (
            <Button variant="primary" icon={Pencil} onClick={() => onEdit(person)}>
              Edit record
            </Button>
          )}
        </>
      }
    >
      <Tabs
        value={tab}
        onChange={setTab}
        tabs={[
          { key: "profile", label: "Profile" },
          { key: "attendance", label: "Attendance" },
          { key: "docs", label: "Documents", count: person.documents?.length || 0 },
        ]}
      />

      {tab === "profile" && (
        <div className="mt-5 space-y-5 animate-fade-in">
          <Group title="Contact" icon={Phone}>
            <DetailList
              items={[
                { label: "Mobile", value: formatMobile(person.mobile), mono: true },
                { label: "Home district", value: person.district },
                { label: "Emergency contact", value: person.emergencyName },
                {
                  label: "Emergency mobile",
                  value: person.emergencyMobile ? formatMobile(person.emergencyMobile) : "—",
                  mono: true,
                },
              ]}
            />
          </Group>

          <Group title="Service record" icon={UserRound}>
            <DetailList
              items={[
                { label: "Staff ID", value: person.id, mono: true },
                { label: "Role", value: person.role },
                { label: "Designation", value: person.designation },
                { label: "Department", value: person.dept },
                { label: "Line", value: person.line },
                { label: "Shift", value: person.shift },
                { label: "Joined", value: prettyDate(person.joinDate), mono: true },
                { label: "Length of service", value: tenure(person.joinDate), mono: true, tone: C.gold },
                { label: "National ID", value: person.nid, mono: true },
                { label: "Blood group", value: person.bloodGroup || "—", tone: C.red },
                ...(person.notes ? [{ label: "Notes", value: person.notes, wide: true }] : []),
              ]}
            />
          </Group>
        </div>
      )}

      {tab === "attendance" && (
        <div className="mt-5 space-y-5 animate-fade-in">
          <Group title="Last 21 working days" icon={CalendarClock}>
            <div className="flex flex-wrap gap-1.5 mb-3">
              {days.map((d, i) => (
                <span
                  key={i}
                  title={`Day ${i + 1}: ${d}`}
                  style={{ background: DOT[d], opacity: d === "On leave" ? 0.4 : 1 }}
                  className="w-4 h-6 rounded-sm"
                />
              ))}
            </div>
            <div className="flex gap-2 flex-wrap">
              {Object.entries(counts).map(([k, v]) => (
                <Badge key={k} tone={DOT[k]}>
                  {k} {v}
                </Badge>
              ))}
            </div>
          </Group>

          <Group title="Today's punch">
            <DetailList
              items={[
                { label: "In", value: person.punchIn, mono: true },
                { label: "Out", value: person.punchOut, mono: true },
                { label: "Status", value: person.status },
                { label: "Overtime this month", value: `${month.otHours} h`, mono: true },
              ]}
            />
          </Group>

          {canSeeSalary && (
            <Group
              title="Current month pay"
              icon={Wallet}
              right={
                <Button variant="outline" size="xs" icon={Printer} onClick={() => printPayslip(person, pay)}>
                  Print payslip
                </Button>
              }
            >
              <div className="space-y-1.5">
                <Row label="Basic" value={taka(pay.basic)} />
                <Row label="House rent" value={taka(pay.houseRent)} />
                <Row label="Medical + transport + food" value={taka(pay.medical + pay.transport + pay.food)} />
                <Stitch style={{ margin: "8px 0" }} />
                <Row label="Gross" value={taka(pay.gross)} />
                <Row label={`Overtime (${pay.otHours} h @ 2×)`} value={`+ ${taka(pay.ot)}`} tone={C.green} />
                <Row label={`Absence (${pay.absentDays} d)`} value={`− ${taka(pay.absenceDeduction)}`} tone={C.red} />
                <Row label="Provident fund 5%" value={`− ${taka(pay.providentFund)}`} tone={C.red} />
                {pay.advance > 0 && <Row label="Advance drawn" value={`− ${taka(pay.advance)}`} tone={C.red} />}
                <Stitch style={{ margin: "8px 0" }} />
                <Row label="Net payable" value={taka(pay.net)} tone={C.gold} strong />
                <Stitch style={{ margin: "8px 0" }} />
                <Row
                  label={person.bankAccount ? "Bank account" : person.mobileBanking ? "Mobile banking" : "Payout channel"}
                  value={person.bankAccount || person.mobileBanking || "Not on file"}
                />
              </div>
            </Group>
          )}
        </div>
      )}

      {tab === "docs" && (
        <div className="mt-5 animate-fade-in">
          <DocumentUploader
            docs={person.documents || []}
            readOnly={!canUploadDocs}
            uploadedBy={actor}
            onAdd={(docs) => onAddDocs(person.id, docs)}
            onRemove={(doc) => onRemoveDoc(person.id, doc.id, doc.name)}
          />
        </div>
      )}
    </Drawer>
  );
}

function Group({ title, icon: Icon, right, children }) {
  return (
    <section>
      <div className="flex items-center gap-2 mb-3 justify-between">
        <div className="flex items-center gap-2">
          {Icon ? (
            <Icon size={13} style={{ color: C.gold }} />
          ) : (
            <Paperclip size={13} style={{ color: C.gold }} />
          )}
          <h3
            style={{ color: C.gold, fontFamily: F.display }}
            className="text-[11px] uppercase tracking-wider font-semibold"
          >
            {title}
          </h3>
        </div>
        {right}
      </div>
      {children}
    </section>
  );
}

function Row({ label, value, tone, strong = false }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <span style={{ color: C.muted }} className="text-xs">
        {label}
      </span>
      <span
        style={{ color: tone || C.text, fontFamily: F.mono }}
        className={`text-xs ${strong ? "font-semibold" : ""}`}
      >
        {value}
      </span>
    </div>
  );
}
