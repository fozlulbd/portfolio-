import React, { useRef, useState } from "react";
import {
  UploadCloud, FileText, FileImage, Trash2, Download, Paperclip, AlertCircle,
} from "../../icons.js";
import { C, F } from "../../theme/tokens.js";
import { DOC_KINDS, MAX_DOC_MB } from "../../data/constants.js";
import { fileSize, prettyDate } from "../../lib/format.js";
import Button from "../ui/Button.jsx";
import { Select } from "../ui/Field.jsx";
import Stitch from "../ui/Stitch.jsx";

/* ---------------------------------------------------------------
   DOCUMENT UPLOADER — real browser file handling: drag-and-drop or
   picker, per-file type/size validation, image thumbnails and a
   working download for anything uploaded this session.

   Files are held as object URLs in memory. Nothing is persisted, so a
   refresh clears them; seeded records show without a download link
   because there is no blob behind them.
----------------------------------------------------------------*/

const ALLOWED = ["application/pdf", "image/jpeg", "image/png", "image/webp"];
const MAX_BYTES = MAX_DOC_MB * 1024 * 1024;

let seq = 0;

function describe(file) {
  if (!ALLOWED.includes(file.type)) return "Only PDF, JPG, PNG or WebP is accepted";
  if (file.size > MAX_BYTES) return `Larger than ${MAX_DOC_MB} MB`;
  return null;
}

export default function DocumentUploader({ docs = [], onAdd, onRemove, readOnly = false, uploadedBy = "you" }) {
  const inputRef = useRef(null);
  const [kind, setKind] = useState(DOC_KINDS[0]);
  const [dragging, setDragging] = useState(false);
  const [rejected, setRejected] = useState([]);

  function ingest(fileList) {
    const files = Array.from(fileList || []);
    if (!files.length) return;

    const bad = [];
    const good = [];
    files.forEach((file) => {
      const problem = describe(file);
      if (problem) bad.push(`${file.name} — ${problem}`);
      else good.push(file);
    });

    setRejected(bad);

    if (good.length) {
      onAdd(
        good.map((file) => ({
          id: `DOC-U${Date.now()}-${++seq}`,
          kind,
          name: file.name,
          size: file.size,
          mime: file.type,
          url: URL.createObjectURL(file),
          isImage: file.type.startsWith("image/"),
          uploadedAt: new Date().toISOString().slice(0, 10),
          uploadedBy,
          seeded: false,
        }))
      );
    }
    if (inputRef.current) inputRef.current.value = "";
  }

  return (
    <div>
      {!readOnly && (
        <>
          <div className="flex items-end gap-2 mb-3 flex-wrap">
            <div className="flex-1 min-w-[180px]">
              <label style={{ color: C.muted }} className="text-xs block mb-1.5">
                File type
              </label>
              <Select value={kind} onChange={(e) => setKind(e.target.value)} options={DOC_KINDS} />
            </div>
            <Button variant="gold-soft" size="md" icon={Paperclip} onClick={() => inputRef.current?.click()}>
              Choose files
            </Button>
          </div>

          <div
            onDragOver={(e) => {
              e.preventDefault();
              setDragging(true);
            }}
            onDragLeave={() => setDragging(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragging(false);
              ingest(e.dataTransfer.files);
            }}
            onClick={() => inputRef.current?.click()}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && inputRef.current?.click()}
            style={{
              border: `1px dashed ${dragging ? C.gold : C.line}`,
              background: dragging ? C.goldDim : C.panelAlt,
            }}
            className="rounded-lg px-4 py-6 text-center cursor-pointer transition-colors duration-150"
          >
            <UploadCloud size={22} style={{ color: dragging ? C.gold : C.muted }} className="mx-auto mb-2" />
            <p style={{ color: C.text }} className="text-xs font-medium">
              Drop files here, or click to browse
            </p>
            <p style={{ color: C.muted }} className="text-[11px] mt-1">
              PDF, JPG, PNG or WebP · up to {MAX_DOC_MB} MB each · filed as “{kind}”
            </p>
          </div>

          <input
            ref={inputRef}
            type="file"
            multiple
            accept=".pdf,.jpg,.jpeg,.png,.webp"
            onChange={(e) => ingest(e.target.files)}
            className="hidden"
          />

          {rejected.length > 0 && (
            <div
              style={{ background: C.redDim, border: `1px solid ${C.red}` }}
              className="rounded-md px-3 py-2.5 mt-3"
            >
              {rejected.map((r) => (
                <p key={r} style={{ color: C.red }} className="text-[11px] flex items-center gap-1.5">
                  <AlertCircle size={11} /> {r}
                </p>
              ))}
            </div>
          )}
        </>
      )}

      <div className="mt-4">
        <div className="flex items-center justify-between mb-2">
          <p style={{ color: C.muted }} className="text-[11px] uppercase tracking-wide">
            On file
          </p>
          <span style={{ color: C.muted, fontFamily: F.mono }} className="text-[11px]">
            {docs.length}
          </span>
        </div>
        <Stitch />

        {docs.length === 0 ? (
          <p style={{ color: C.muted }} className="text-xs py-4 text-center">
            No documents attached yet.
          </p>
        ) : (
          <ul className="divide-y" style={{ borderColor: C.line }}>
            {docs.map((d) => {
              const Icon = d.isImage ? FileImage : FileText;
              return (
                <li key={d.id} style={{ borderColor: C.line }} className="py-2.5 flex items-center gap-3">
                  {d.isImage && d.url ? (
                    <img
                      src={d.url}
                      alt=""
                      style={{ border: `1px solid ${C.line}` }}
                      className="w-9 h-9 rounded object-cover shrink-0"
                    />
                  ) : (
                    <span
                      style={{ background: C.goldDim, color: C.gold }}
                      className="w-9 h-9 rounded flex items-center justify-center shrink-0"
                    >
                      <Icon size={15} />
                    </span>
                  )}

                  <div className="flex-1 min-w-0">
                    <p style={{ color: C.text }} className="text-xs truncate">
                      {d.name}
                    </p>
                    <p style={{ color: C.muted, fontFamily: F.mono }} className="text-[10px] mt-0.5">
                      {d.kind} · {fileSize(d.size)} · {prettyDate(d.uploadedAt)}
                      {d.uploadedBy ? ` · ${d.uploadedBy}` : ""}
                    </p>
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    {d.url ? (
                      <a
                        href={d.url}
                        download={d.name}
                        aria-label={`Download ${d.name}`}
                        title="Download"
                        style={{ color: C.gold, border: `1px solid ${C.line}` }}
                        className="w-7 h-7 rounded-md flex items-center justify-center"
                      >
                        <Download size={12} />
                      </a>
                    ) : (
                      <span
                        title="Archived on the file server — not available in this demo"
                        style={{ color: C.line, border: `1px solid ${C.line}` }}
                        className="w-7 h-7 rounded-md flex items-center justify-center"
                      >
                        <Download size={12} />
                      </span>
                    )}
                    {!readOnly && (
                      <button
                        type="button"
                        onClick={() => onRemove(d)}
                        aria-label={`Remove ${d.name}`}
                        title="Remove"
                        style={{ color: C.red, border: `1px solid ${C.line}` }}
                        className="w-7 h-7 rounded-md flex items-center justify-center"
                      >
                        <Trash2 size={12} />
                      </button>
                    )}
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
