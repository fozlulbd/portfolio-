import React, { useRef, useState } from "react";
import { Camera, Trash2, AlertCircle } from "../../icons.js";
import { C, F } from "../../theme/tokens.js";
import { initials } from "../../lib/format.js";

/* ---------------------------------------------------------------
   PHOTO UPLOADER — a circular headshot control used wherever a
   worker's profile picture can be set: the People drawer header and
   the add/edit form. Same real-file pattern as DocumentUploader
   (object URL, type/size check before accepting), but scoped to a
   single image rather than a document list, and always rendered at
   a fixed on-screen size so it never distorts the ID card layout
   that reads from the same `photo` field.
----------------------------------------------------------------*/

const ALLOWED = ["image/jpeg", "image/png", "image/webp"];
const MAX_MB = 4;
const MAX_BYTES = MAX_MB * 1024 * 1024;

export default function PhotoUploader({ name, src, onChange, size = 72, editable = true }) {
  const inputRef = useRef(null);
  const [error, setError] = useState("");

  function pick(fileList) {
    const file = fileList?.[0];
    if (!file) return;
    if (!ALLOWED.includes(file.type)) {
      setError("Use a JPG, PNG or WebP image");
      return;
    }
    if (file.size > MAX_BYTES) {
      setError(`Larger than ${MAX_MB} MB`);
      return;
    }
    setError("");
    onChange(URL.createObjectURL(file));
    if (inputRef.current) inputRef.current.value = "";
  }

  return (
    <div className="inline-flex flex-col items-center gap-1.5">
      <div className="relative" style={{ width: size, height: size }}>
        <div
          style={{
            width: size,
            height: size,
            background: src ? `center/cover url(${src})` : C.goldDim,
            color: C.gold,
            border: `1.5px solid ${C.line}`,
            fontFamily: F.display,
            fontSize: size * 0.32,
          }}
          className="rounded-full flex items-center justify-center font-semibold overflow-hidden"
        >
          {!src && initials(name)}
        </div>

        {editable && (
          <button
            type="button"
            onClick={() => inputRef.current?.click()}
            aria-label={src ? "Change profile photo" : "Upload profile photo"}
            title={src ? "Change photo" : "Upload photo"}
            style={{ background: C.gold, color: "#181205", border: "2px solid var(--mf-panel)" }}
            className="absolute -bottom-0.5 -right-0.5 w-6 h-6 rounded-full flex items-center justify-center shadow-sm"
          >
            <Camera size={11} strokeWidth={2.5} />
          </button>
        )}
      </div>

      {editable && (
        <div className="flex items-center gap-2">
          <input
            ref={inputRef}
            type="file"
            accept=".jpg,.jpeg,.png,.webp"
            onChange={(e) => pick(e.target.files)}
            className="hidden"
          />
          {src && (
            <button
              type="button"
              onClick={() => {
                setError("");
                onChange(null);
              }}
              style={{ color: C.red }}
              className="text-[10px] inline-flex items-center gap-1 hover:underline"
            >
              <Trash2 size={10} /> Remove
            </button>
          )}
        </div>
      )}

      {error && (
        <p style={{ color: C.red }} className="text-[10px] flex items-center gap-1">
          <AlertCircle size={10} /> {error}
        </p>
      )}
    </div>
  );
}
