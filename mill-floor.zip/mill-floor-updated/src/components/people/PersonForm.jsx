import React, { useMemo, useState } from "react";
import { Save, UserPlus, Fingerprint, FolderOpen, Landmark } from "../../icons.js";
import { C, F } from "../../theme/tokens.js";
import {
  DEPTS, SHIFTS, LINES, BLOOD_GROUPS, DISTRICTS, DESIGNATIONS,
  EMPLOYMENT_TYPES, ROLE_KEYS, ROLE_LABEL, ATTENDANCE_STATUS, BANKS,
} from "../../data/constants.js";
import { emptyPerson } from "../../data/people.js";
import { isValidBdMobile, isValidNid } from "../../lib/format.js";
import Modal from "../ui/Modal.jsx";
import Button from "../ui/Button.jsx";
import Tabs from "../ui/Tabs.jsx";
import { Field, Input, Select, Textarea } from "../ui/Field.jsx";
import DocumentUploader from "./DocumentUploader.jsx";
import PhotoUploader from "./PhotoUploader.jsx";

/* ---------------------------------------------------------------
   PERSON FORM — add or edit an employee. Validation runs on submit
   and again on every change once a field has been touched, so the
   form corrects itself as you fix it rather than shouting on load.
----------------------------------------------------------------*/

export function validatePerson(p) {
  const e = {};
  if (!p.name || p.name.trim().length < 3) e.name = "Full name is required";
  if (!p.mobile) e.mobile = "Mobile number is required";
  else if (!isValidBdMobile(p.mobile)) e.mobile = "Use a valid BD number, e.g. 01712345678";
  if (!p.joinDate) e.joinDate = "Joining date is required";
  else if (new Date(p.joinDate) > new Date()) e.joinDate = "Joining date cannot be in the future";
  if (p.nid && !isValidNid(p.nid)) e.nid = "NID must be 10, 13 or 17 digits";
  if (p.emergencyMobile && !isValidBdMobile(p.emergencyMobile))
    e.emergencyMobile = "Not a valid BD number";
  if (!p.basic || Number(p.basic) <= 0) e.basic = "Basic salary is required";
  return e;
}

export default function PersonForm({ open, onClose, person, defaultRole = "worker", onSave, canSeeSalary = true }) {
  const isEdit = Boolean(person);
  const [draft, setDraft] = useState(() => person || emptyPerson(defaultRole));
  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});
  const [tab, setTab] = useState("details");

  // Remount on a different record: the modal is cheap, so keying the
  // draft off the person id keeps stale values from leaking between rows.
  const formKey = person?.id || `new-${defaultRole}`;
  const [lastKey, setLastKey] = useState(formKey);
  if (lastKey !== formKey) {
    setLastKey(formKey);
    setDraft(person || emptyPerson(defaultRole));
    setErrors({});
    setTouched({});
    setTab("details");
  }

  const designations = useMemo(
    () => DESIGNATIONS[ROLE_LABEL[draft.roleKey]] || [],
    [draft.roleKey]
  );

  function set(key, value) {
    const next = { ...draft, [key]: value };
    // Switching role invalidates the designation list — snap to the first.
    if (key === "roleKey") {
      next.role = ROLE_LABEL[value];
      next.designation = (DESIGNATIONS[ROLE_LABEL[value]] || [""])[0];
      next.line = value === "worker" || value === "supervisor" ? LINES[0] : "—";
    }
    setDraft(next);
    if (touched[key] || Object.keys(errors).length) setErrors(validatePerson(next));
  }

  function blur(key) {
    setTouched((t) => ({ ...t, [key]: true }));
    setErrors(validatePerson(draft));
  }

  function submit() {
    const found = validatePerson(draft);
    setErrors(found);
    setTouched(Object.fromEntries(Object.keys(found).map((k) => [k, true])));
    if (Object.keys(found).length) {
      setTab("details");
      return;
    }
    onSave(draft);
    onClose();
  }

  const err = (k) => (touched[k] ? errors[k] : undefined);

  return (
    <Modal
      open={open}
      onClose={onClose}
      width="lg"
      title={isEdit ? `Edit ${person.name}` : "Add employee"}
      subtitle={
        isEdit
          ? `${person.id} · ${person.role} · joined ${person.joinDate}`
          : "A staff ID is generated automatically on save."
      }
      footer={
        <>
          <Button variant="outline" size="md" onClick={onClose}>
            Cancel
          </Button>
          <Button variant="primary" size="md" icon={isEdit ? Save : UserPlus} onClick={submit}>
            {isEdit ? "Save changes" : "Add employee"}
          </Button>
        </>
      }
    >
      <Tabs
        value={tab}
        onChange={setTab}
        tabs={[
          { key: "details", label: "Details" },
          { key: "docs", label: "Documents", count: draft.documents?.length || 0 },
        ]}
      />

      {tab === "details" ? (
        <div className="mt-5 space-y-5">
          <Section title="Identity" icon={Fingerprint}>
            <div className="sm:col-span-2 flex items-center gap-4">
              <PhotoUploader
                name={draft.name}
                src={draft.photo}
                size={68}
                onChange={(url) => set("photo", url)}
              />
              <p style={{ color: C.muted }} className="text-[11px] leading-relaxed">
                Used on the ID card and throughout the app. JPG, PNG or WebP.
              </p>
            </div>

            <Field label="Full name" required error={err("name")} className="sm:col-span-2">
              <Input
                value={draft.name}
                onChange={(e) => set("name", e.target.value)}
                onBlur={() => blur("name")}
                placeholder="e.g. Salma Akter"
                error={err("name")}
              />
            </Field>

            <Field label="Mobile number" required error={err("mobile")}>
              <Input
                value={draft.mobile}
                onChange={(e) => set("mobile", e.target.value)}
                onBlur={() => blur("mobile")}
                placeholder="01712345678"
                inputMode="numeric"
                mono
                error={err("mobile")}
              />
            </Field>

            <Field label="National ID" hint="optional" error={err("nid")}>
              <Input
                value={draft.nid}
                onChange={(e) => set("nid", e.target.value)}
                onBlur={() => blur("nid")}
                placeholder="13 or 17 digits"
                inputMode="numeric"
                mono
                error={err("nid")}
              />
            </Field>

            <Field label="Blood group">
              <Select
                value={draft.bloodGroup}
                onChange={(e) => set("bloodGroup", e.target.value)}
                options={BLOOD_GROUPS}
                placeholder="Not recorded"
              />
            </Field>

            <Field label="Home district">
              <Select
                value={draft.district}
                onChange={(e) => set("district", e.target.value)}
                options={DISTRICTS}
              />
            </Field>
          </Section>

          <Section title="Posting">
            <Field label="Role" required>
              <Select
                value={draft.roleKey}
                onChange={(e) => set("roleKey", e.target.value)}
                options={ROLE_KEYS.map((k) => ({ value: k, label: ROLE_LABEL[k] }))}
              />
            </Field>

            <Field label="Designation">
              <Select
                value={draft.designation}
                onChange={(e) => set("designation", e.target.value)}
                options={designations}
              />
            </Field>

            <Field label="Department">
              <Select value={draft.dept} onChange={(e) => set("dept", e.target.value)} options={DEPTS} />
            </Field>

            <Field label="Line">
              <Select
                value={draft.line}
                onChange={(e) => set("line", e.target.value)}
                options={["—", ...LINES]}
              />
            </Field>

            <Field label="Shift">
              <Select value={draft.shift} onChange={(e) => set("shift", e.target.value)} options={SHIFTS} />
            </Field>

            <Field label="Employment type">
              <Select
                value={draft.employment}
                onChange={(e) => set("employment", e.target.value)}
                options={EMPLOYMENT_TYPES}
              />
            </Field>

            <Field label="Joining date" required error={err("joinDate")}>
              <Input
                type="date"
                value={draft.joinDate}
                onChange={(e) => set("joinDate", e.target.value)}
                onBlur={() => blur("joinDate")}
                mono
                error={err("joinDate")}
              />
            </Field>

            <Field label="Today's status">
              <Select
                value={draft.status}
                onChange={(e) => set("status", e.target.value)}
                options={ATTENDANCE_STATUS}
              />
            </Field>

            {canSeeSalary && (
              <Field label="Basic salary (৳ / month)" required error={err("basic")}>
                <Input
                  type="number"
                  value={draft.basic}
                  onChange={(e) => set("basic", e.target.value)}
                  onBlur={() => blur("basic")}
                  min={0}
                  step={100}
                  mono
                  error={err("basic")}
                />
              </Field>
            )}
          </Section>

          {canSeeSalary && (
            <Section title="Payout details" icon={Landmark}>
              <Field label="Bank name" hint="optional — type any bank">
                <Input
                  value={draft.bankName}
                  onChange={(e) => set("bankName", e.target.value)}
                  placeholder="e.g. Dutch-Bangla Bank"
                  list="bank-name-options"
                />
                <datalist id="bank-name-options">
                  {BANKS.map((b) => (
                    <option key={b} value={b} />
                  ))}
                </datalist>
              </Field>
              <Field label="Bank account number" hint="optional">
                <Input
                  value={draft.bankAccount}
                  onChange={(e) => set("bankAccount", e.target.value)}
                  placeholder="e.g. 1234567890"
                  inputMode="numeric"
                  mono
                />
              </Field>
              <Field label="Mobile banking (bKash / Nagad / Rocket)" hint="optional" className="sm:col-span-2">
                <Input
                  value={draft.mobileBanking}
                  onChange={(e) => set("mobileBanking", e.target.value)}
                  placeholder="e.g. bKash: 01712345678"
                  mono
                />
              </Field>
              <p style={{ color: C.muted }} className="text-[11px] leading-relaxed sm:col-span-2">
                Printed on the payslip as the payout channel. Fill in a bank account, or a mobile
                banking number if the worker is paid through bKash/Nagad/Rocket instead.
              </p>
            </Section>
          )}

          <Section title="Emergency contact">
            <Field label="Contact name">
              <Input
                value={draft.emergencyName}
                onChange={(e) => set("emergencyName", e.target.value)}
                placeholder="Relative or guardian"
              />
            </Field>
            <Field label="Contact mobile" error={err("emergencyMobile")}>
              <Input
                value={draft.emergencyMobile}
                onChange={(e) => set("emergencyMobile", e.target.value)}
                onBlur={() => blur("emergencyMobile")}
                placeholder="01812345678"
                inputMode="numeric"
                mono
                error={err("emergencyMobile")}
              />
            </Field>
            <Field label="Notes" className="sm:col-span-2">
              <Textarea
                value={draft.notes}
                onChange={(e) => set("notes", e.target.value)}
                placeholder="Training completed, machine skills, transfer history…"
              />
            </Field>
          </Section>
        </div>
      ) : (
        <div className="mt-5">
          <div
            style={{ background: C.panelAlt, border: `1px solid ${C.line}` }}
            className="rounded-md px-3.5 py-3 mb-4 flex items-start gap-2.5"
          >
            <FolderOpen size={14} style={{ color: C.gold }} className="mt-0.5 shrink-0" />
            <p style={{ color: C.muted }} className="text-[11px] leading-relaxed">
              Attach the NID copy, passport photo, appointment letter and any other paperwork.
              Files stay attached to this draft and are saved together with the record.
            </p>
          </div>
          <DocumentUploader
            docs={draft.documents || []}
            onAdd={(docs) => setDraft((d) => ({ ...d, documents: [...(d.documents || []), ...docs] }))}
            onRemove={(doc) =>
              setDraft((d) => ({ ...d, documents: d.documents.filter((x) => x.id !== doc.id) }))
            }
          />
        </div>
      )}
    </Modal>
  );
}

function Section({ title, icon: Icon, children }) {
  return (
    <fieldset>
      <legend className="flex items-center gap-2 mb-3">
        {Icon && <Icon size={13} style={{ color: C.gold }} />}
        <span
          style={{ color: C.gold, fontFamily: F.display }}
          className="text-[11px] uppercase tracking-wider font-semibold"
        >
          {title}
        </span>
      </legend>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-3.5">{children}</div>
    </fieldset>
  );
}
