import React, { useEffect, useMemo, useState } from "react";
import {
  ArrowDown, ArrowUp, ChevronsUpDown, Download, Printer, Search, X, SlidersHorizontal,
} from "../icons.js";
import { C, F } from "../theme/tokens.js";
import { buildView, distinct } from "../lib/table.js";
import { downloadCSV, stampedName } from "../lib/csv.js";
import { printRows } from "../lib/print.js";
import Card from "./ui/Card.jsx";
import Stitch from "./ui/Stitch.jsx";
import Pagination from "./ui/Pagination.jsx";
import EmptyState from "./ui/EmptyState.jsx";
import { TableSkeleton } from "./ui/Skeleton.jsx";
import Button from "./ui/Button.jsx";
import { FilterSelect } from "./ui/Field.jsx";

/* ---------------------------------------------------------------
   DATATABLE — one table to serve every list in the app. Search,
   per-column sort, equality filters, page size, row selection with
   bulk actions and CSV export all run off the pure helpers in
   lib/table.js, so the behaviour is unit-tested rather than eyeballed.

   columns: { key, label, render?, mono?, align?, width?, sortable?,
              csv? (false to omit from export), hideBelow? ('md'|'lg') }
----------------------------------------------------------------*/
export default function DataTable({
  columns,
  rows,
  searchKeys = [],
  filterKeys = [],
  title,
  subtitle,
  icon: Icon,
  selectable = false,
  bulkActions = [],
  onRowClick,
  exportName,
  canExport = true,
  toolbarRight,
  loading = false,
  emptyTitle = "No matching records",
  emptyMessage = "Try clearing the search box or a filter.",
  initialSort = { key: "", dir: "asc" },
  rowKey = "id",
  dense = false,
}) {
  const [query, setQuery] = useState("");
  const [filters, setFilters] = useState({});
  const [sortKey, setSortKey] = useState(initialSort.key);
  const [sortDir, setSortDir] = useState(initialSort.dir);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [selected, setSelected] = useState([]);
  const [showFilters, setShowFilters] = useState(false);

  const view = useMemo(
    () => buildView(rows, { query, searchKeys, filters, sortKey, sortDir, page, pageSize }),
    [rows, query, searchKeys, filters, sortKey, sortDir, page, pageSize]
  );

  // Narrowing the result set can leave the cursor past the last page.
  useEffect(() => setPage(1), [query, filters, pageSize, rows.length]);

  // Drop selections whose rows no longer exist (deleted or filtered away).
  useEffect(() => {
    const live = new Set(rows.map((r) => r[rowKey]));
    setSelected((prev) => {
      const next = prev.filter((id) => live.has(id));
      return next.length === prev.length ? prev : next;
    });
  }, [rows, rowKey]);

  const filterDefs = useMemo(
    () => filterKeys.map((k) => ({
      key: typeof k === "string" ? k : k.key,
      label: typeof k === "string" ? k : k.label,
      options: distinct(rows, typeof k === "string" ? k : k.key),
    })),
    [filterKeys, rows]
  );

  const activeFilterCount = Object.values(filters).filter((v) => v !== "" && v != null).length;
  const dirty = Boolean(query) || activeFilterCount > 0;

  function toggleSort(key) {
    if (sortKey !== key) {
      setSortKey(key);
      setSortDir("asc");
    } else if (sortDir === "asc") {
      setSortDir("desc");
    } else {
      setSortKey("");
      setSortDir("asc");
    }
  }

  const allMatchedIds = view.all.map((r) => r[rowKey]);
  const allSelected = allMatchedIds.length > 0 && selected.length === allMatchedIds.length;

  function toggleAll() {
    setSelected(allSelected ? [] : allMatchedIds);
  }

  function toggleOne(id) {
    setSelected((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  }

  function exportTarget() {
    const cols = columns.filter((c) => c.csv !== false).map((c) => ({ key: c.key, label: c.label }));
    const target = selected.length
      ? view.all.filter((r) => selected.includes(r[rowKey]))
      : view.all;
    return { cols, target };
  }

  function runExport() {
    const { cols, target } = exportTarget();
    downloadCSV(target, cols, stampedName(exportName || "export"));
  }

  function runPrint() {
    const { cols, target } = exportTarget();
    printRows(target, cols, title || exportName || "Mill Floor");
  }

  const cellPad = dense ? "px-4 py-2" : "px-5 py-3";

  return (
    <Card className="overflow-hidden">
      {/* ── toolbar ─────────────────────────────────────────── */}
      <div className="px-5 py-4 flex items-start justify-between gap-3 flex-wrap">
        <div className="flex items-start gap-2.5 min-w-0">
          {Icon && (
            <div style={{ background: C.goldDim, color: C.gold }} className="w-7 h-7 rounded-md flex items-center justify-center shrink-0 mt-0.5">
              <Icon size={14} strokeWidth={2} />
            </div>
          )}
          <div className="min-w-0">
            <h3 style={{ fontFamily: F.display, color: C.text }} className="text-sm font-semibold">
              {title}
            </h3>
            <p style={{ color: C.muted }} className="text-xs mt-0.5">
              {subtitle || `${view.matched} of ${rows.length} records`}
              {selected.length > 0 && ` · ${selected.length} selected`}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <div
            style={{ background: C.panelAlt, border: `1px solid ${query ? C.gold : C.line}` }}
            className="flex items-center gap-2 px-2.5 py-1.5 rounded-md"
          >
            <Search size={13} style={{ color: query ? C.gold : C.muted }} />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search…"
              aria-label={`Search ${title}`}
              style={{ background: "transparent", color: C.text }}
              className="text-xs outline-none w-28 sm:w-40"
            />
            {query && (
              <button type="button" aria-label="Clear search" onClick={() => setQuery("")}>
                <X size={12} style={{ color: C.muted }} />
              </button>
            )}
          </div>

          {filterDefs.length > 0 && (
            <Button
              variant={activeFilterCount ? "gold-soft" : "outline"}
              icon={SlidersHorizontal}
              onClick={() => setShowFilters((s) => !s)}
            >
              Filters{activeFilterCount ? ` · ${activeFilterCount}` : ""}
            </Button>
          )}

          {canExport && (
            <>
              <Button variant="outline" icon={Download} onClick={runExport} title="Download CSV">
                {selected.length ? `CSV (${selected.length})` : "CSV"}
              </Button>
              <Button variant="outline" icon={Printer} onClick={runPrint} title="Print this list">
                Print
              </Button>
            </>
          )}

          {toolbarRight}
        </div>
      </div>

      {showFilters && filterDefs.length > 0 && (
        <>
          <Stitch />
          <div className="px-5 py-3 flex items-center gap-2 flex-wrap animate-fade-in">
            {filterDefs.map((f) => (
              <FilterSelect
                key={f.key}
                label={f.label}
                value={filters[f.key] || ""}
                onChange={(v) => setFilters((prev) => ({ ...prev, [f.key]: v }))}
                options={f.options}
              />
            ))}
            {dirty && (
              <Button
                variant="ghost"
                icon={X}
                onClick={() => {
                  setFilters({});
                  setQuery("");
                }}
              >
                Clear all
              </Button>
            )}
          </div>
        </>
      )}

      {/* ── bulk action bar ─────────────────────────────────── */}
      {selectable && selected.length > 0 && bulkActions.length > 0 && (
        <div
          style={{ background: C.goldDim, borderTop: `1px solid ${C.line}`, borderBottom: `1px solid ${C.line}` }}
          className="px-5 py-2.5 flex items-center gap-2 flex-wrap animate-fade-in"
        >
          <span style={{ color: C.gold, fontFamily: F.mono }} className="text-[11px] mr-1">
            {selected.length} selected
          </span>
          {bulkActions.map((a) => (
            <Button
              key={a.label}
              variant={a.tone === "danger" ? "danger" : "outline"}
              icon={a.icon}
              size="xs"
              onClick={() => {
                a.onRun(selected);
                if (a.clearAfter !== false) setSelected([]);
              }}
            >
              {a.label}
            </Button>
          ))}
          <button
            type="button"
            onClick={() => setSelected([])}
            style={{ color: C.muted }}
            className="text-[11px] ml-auto underline"
          >
            Clear selection
          </button>
        </div>
      )}

      <Stitch />

      {/* ── table ───────────────────────────────────────────── */}
      {loading ? (
        <TableSkeleton rows={Math.min(pageSize, 6)} cols={Math.min(columns.length, 6)} />
      ) : view.rows.length === 0 ? (
        <EmptyState
          title={emptyTitle}
          message={dirty ? emptyMessage : "This list is empty."}
          actionLabel={dirty ? "Clear search & filters" : undefined}
          onAction={() => {
            setQuery("");
            setFilters({});
          }}
        />
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm" style={{ minWidth: 640 }}>
            <thead>
              <tr style={{ background: C.panel }} className="sticky top-0 z-10">
                {selectable && (
                  <th className={`${cellPad} w-10`}>
                    <input
                      type="checkbox"
                      aria-label="Select all matching rows"
                      checked={allSelected}
                      onChange={toggleAll}
                      style={{ accentColor: C.gold }}
                      className="cursor-pointer"
                    />
                  </th>
                )}
                {columns.map((col) => {
                  const isSorted = sortKey === col.key;
                  const SortIcon = !isSorted ? ChevronsUpDown : sortDir === "asc" ? ArrowUp : ArrowDown;
                  const hide =
                    col.hideBelow === "lg" ? "hidden lg:table-cell" :
                    col.hideBelow === "md" ? "hidden md:table-cell" : "";
                  return (
                    <th
                      key={col.key}
                      style={{ color: isSorted ? C.gold : C.muted, width: col.width }}
                      className={`${cellPad} font-medium text-xs uppercase tracking-wide ${
                        col.align === "right" ? "text-right" : "text-left"
                      } ${hide}`}
                    >
                      {col.sortable === false ? (
                        col.label
                      ) : (
                        <button
                          type="button"
                          onClick={() => toggleSort(col.key)}
                          className={`inline-flex items-center gap-1.5 hover:opacity-80 ${
                            col.align === "right" ? "flex-row-reverse" : ""
                          }`}
                        >
                          {col.label}
                          <SortIcon size={11} strokeWidth={2.5} style={{ opacity: isSorted ? 1 : 0.45 }} />
                        </button>
                      )}
                    </th>
                  );
                })}
              </tr>
              <tr>
                <td colSpan={columns.length + (selectable ? 1 : 0)} style={{ padding: 0 }}>
                  <Stitch />
                </td>
              </tr>
            </thead>
            <tbody>
              {view.rows.map((row) => {
                const id = row[rowKey];
                const isSelected = selected.includes(id);
                return (
                  <tr
                    key={id}
                    onClick={onRowClick ? () => onRowClick(row) : undefined}
                    style={{
                      borderTop: `1px solid ${C.line}`,
                      background: isSelected ? C.goldDim : "transparent",
                      cursor: onRowClick ? "pointer" : "default",
                    }}
                    className="transition-colors duration-100 hover:brightness-125"
                  >
                    {selectable && (
                      <td className={cellPad} onClick={(e) => e.stopPropagation()}>
                        <input
                          type="checkbox"
                          aria-label={`Select ${row.name || id}`}
                          checked={isSelected}
                          onChange={() => toggleOne(id)}
                          style={{ accentColor: C.gold }}
                          className="cursor-pointer"
                        />
                      </td>
                    )}
                    {columns.map((col) => {
                      const hide =
                        col.hideBelow === "lg" ? "hidden lg:table-cell" :
                        col.hideBelow === "md" ? "hidden md:table-cell" : "";
                      return (
                        <td
                          key={col.key}
                          style={{
                            color: col.mono ? C.text : C.muted,
                            fontFamily: col.mono ? F.mono : F.sans,
                          }}
                          className={`${cellPad} ${col.mono ? "text-xs" : ""} ${
                            col.align === "right" ? "text-right" : ""
                          } ${hide}`}
                        >
                          {col.render ? col.render(row) : row[col.key] ?? "—"}
                        </td>
                      );
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {!loading && view.total > 0 && (
        <>
          <Stitch />
          <Pagination
            page={view.page}
            pageCount={view.pageCount}
            from={view.from}
            to={view.to}
            total={view.total}
            pageSize={pageSize}
            onPage={setPage}
            onPageSize={setPageSize}
          />
        </>
      )}
    </Card>
  );
}
