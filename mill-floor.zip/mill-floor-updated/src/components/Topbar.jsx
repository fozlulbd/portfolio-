import React from "react";
import { Menu, Moon, Sun } from "../icons.js";
import { C, F } from "../theme/tokens.js";
import { useTheme } from "../theme/ThemeProvider.jsx";
import { IconButton } from "./ui/Button.jsx";
import Avatar from "./ui/Avatar.jsx";
import GlobalSearch from "./GlobalSearch.jsx";
import NotificationsMenu from "./NotificationsMenu.jsx";

export default function Topbar({ title, group, role, onOpenMobileNav, onNavigate, onSelectPerson }) {
  const { mode, toggle } = useTheme();

  return (
    <header
      style={{ borderBottom: `1px solid ${C.line}`, background: C.bg }}
      className="px-4 sm:px-6 py-3.5 flex items-center justify-between gap-3 sticky top-0 z-30"
    >
      <div className="flex items-center gap-3 min-w-0">
        <button
          type="button"
          onClick={onOpenMobileNav}
          aria-label="Open menu"
          style={{ color: C.muted, border: `1px solid ${C.line}` }}
          className="lg:hidden w-9 h-9 rounded-md flex items-center justify-center shrink-0"
        >
          <Menu size={16} />
        </button>

        <div className="min-w-0">
          <p style={{ color: C.muted }} className="text-[10px] uppercase tracking-wide truncate">
            {group} · {role.label}
          </p>
          <h1
            style={{ fontFamily: F.display, color: C.text }}
            className="text-base sm:text-lg font-semibold truncate"
          >
            {title}
          </h1>
        </div>
      </div>

      <div className="flex items-center gap-2 sm:gap-3">
        <div className="hidden sm:block">
          <GlobalSearch onSelect={onSelectPerson} />
        </div>
        <IconButton
          icon={mode === "dark" ? Sun : Moon}
          label={mode === "dark" ? "Switch to light mode" : "Switch to dark mode"}
          onClick={toggle}
        />
        <NotificationsMenu role={role} onNavigate={onNavigate} />
        <Avatar name={role.label} ring />
      </div>
    </header>
  );
}
