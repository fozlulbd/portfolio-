import React from "react";
import { ScanFace, LogOut, PanelLeftClose, PanelLeftOpen, X } from "../icons.js";
import { C, F } from "../theme/tokens.js";
import { navFor } from "../auth/roles.js";
import { navIcon } from "../auth/navIcons.js";
import Stitch from "./ui/Stitch.jsx";
import Avatar from "./ui/Avatar.jsx";

/* ---------------------------------------------------------------
   SIDEBAR — one component serving three layouts: full desktop rail,
   collapsed icon rail, and an off-canvas drawer on phones. Only the
   pages the signed-in role may open are rendered at all.
----------------------------------------------------------------*/
export default function Sidebar({
  role, page, onNavigate, collapsed, onToggleCollapse, mobile = false, onCloseMobile, onLogout,
}) {
  const groups = navFor(role);
  const width = collapsed && !mobile ? 68 : 232;

  return (
    <aside
      style={{
        background: C.panel,
        borderRight: `1px solid ${C.line}`,
        width,
        transition: "width .2s cubic-bezier(.22,.61,.36,1)",
      }}
      className={`shrink-0 flex flex-col h-full ${mobile ? "animate-slide-right" : ""}`}
    >
      {/* brand */}
      <div className="px-4 py-4 flex items-center gap-2.5">
        <div
          style={{ background: C.goldDim, color: C.gold }}
          className="w-9 h-9 rounded-md flex items-center justify-center shrink-0"
        >
          <ScanFace size={17} />
        </div>
        {(!collapsed || mobile) && (
          <div className="min-w-0 flex-1">
            <p style={{ fontFamily: F.display, color: C.text }} className="text-sm font-semibold leading-tight">
              Mill Floor
            </p>
            <p style={{ color: C.muted }} className="text-[10px] leading-tight truncate">
              Knitwear Ltd · Unit 2
            </p>
          </div>
        )}
        {mobile && (
          <button type="button" aria-label="Close menu" onClick={onCloseMobile} style={{ color: C.muted }}>
            <X size={18} />
          </button>
        )}
      </div>

      <Stitch />

      {/* navigation */}
      <nav className="flex-1 py-3 px-2.5 overflow-y-auto">
        {groups.map((g, gi) => (
          <div key={g.group} className={gi > 0 ? "mt-4" : ""}>
            {(!collapsed || mobile) && (
              <p
                style={{ color: C.muted }}
                className="text-[10px] uppercase tracking-wider px-2.5 mb-1.5 opacity-70"
              >
                {g.group}
              </p>
            )}
            <div className="space-y-0.5">
              {g.items.map((n) => {
                const active = page === n.key;
                const Icon = navIcon(n.key);
                return (
                  <button
                    key={n.key}
                    type="button"
                    onClick={() => {
                      onNavigate(n.key);
                      if (mobile) onCloseMobile();
                    }}
                    title={collapsed && !mobile ? n.label : undefined}
                    aria-current={active ? "page" : undefined}
                    style={{
                      background: active ? C.goldDim : "transparent",
                      color: active ? C.gold : C.muted,
                      borderLeft: `2px solid ${active ? C.gold : "transparent"}`,
                    }}
                    className={`w-full flex items-center gap-2.5 py-2 rounded-md text-[13px] font-medium transition-colors duration-150 hover:brightness-125 ${
                      collapsed && !mobile ? "justify-center px-0" : "px-2.5"
                    }`}
                  >
                    <Icon size={15} strokeWidth={2} className="shrink-0" />
                    {(!collapsed || mobile) && <span className="truncate">{n.label}</span>}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </nav>

      <Stitch />

      {/* signed-in identity */}
      <div className={`px-3 py-3 flex items-center gap-2.5 ${collapsed && !mobile ? "justify-center" : ""}`}>
        <Avatar name={role.label} size="sm" />
        {(!collapsed || mobile) && (
          <div className="min-w-0 flex-1">
            <p style={{ color: C.text }} className="text-xs truncate">
              {role.label}
            </p>
            <p style={{ color: C.muted, fontFamily: F.mono }} className="text-[10px] truncate">
              {role.username}
            </p>
          </div>
        )}
      </div>

      <div className={`px-2.5 pb-3 flex items-center gap-1 ${collapsed && !mobile ? "flex-col" : ""}`}>
        <button
          type="button"
          onClick={onLogout}
          style={{ color: C.muted }}
          className={`flex items-center gap-2.5 px-2.5 py-2 rounded-md text-[13px] hover:brightness-125 ${
            collapsed && !mobile ? "justify-center w-full" : "flex-1"
          }`}
          title="Log out"
        >
          <LogOut size={15} />
          {(!collapsed || mobile) && "Log out"}
        </button>
        {!mobile && (
          <button
            type="button"
            onClick={onToggleCollapse}
            aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
            title={collapsed ? "Expand sidebar" : "Collapse sidebar"}
            style={{ color: C.muted }}
            className="w-8 h-8 rounded-md flex items-center justify-center hover:brightness-125"
          >
            {collapsed ? <PanelLeftOpen size={15} /> : <PanelLeftClose size={15} />}
          </button>
        )}
      </div>
    </aside>
  );
}
