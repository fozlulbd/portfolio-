import React from "react";

/* ---------------------------------------------------------------
   ERROR BOUNDARY — without this, a throw during render unmounts the
   whole tree and you are left staring at a blank page with the real
   message buried in the browser console. This puts the message, the
   component stack and a likely cause on screen instead.

   Deliberately plain CSS-in-style: if the theme or token layer is
   what broke, this panel still has to render.
----------------------------------------------------------------*/

const HINTS = [
  {
    match: /Element type is invalid|type is invalid/i,
    title: "A component came out as undefined",
    body:
      "Usually an icon name the installed lucide-react version does not export, or an import that " +
      "should be a default import but was written as a named one (or the reverse). " +
      "Run `node tests/check-icons.mjs` to list every icon name that resolves to undefined.",
  },
  {
    match: /Cannot read propert(y|ies) of (undefined|null)/i,
    title: "Something read a field off an empty value",
    body:
      "A record or list was missing when a component expected it. The component name at the top " +
      "of the stack below is where to look.",
  },
  {
    match: /Rendered (more|fewer) hooks|hook.*order|Rendered fewer hooks than expected/i,
    title: "Hooks ran in a different order",
    body:
      "A hook is being called conditionally, or after an early return. Every useState / useMemo / " +
      "useEffect has to run on every render of that component.",
  },
  {
    match: /Too many re-?renders|Maximum update depth/i,
    title: "A render loop",
    body:
      "Something calls setState during render, or an effect's dependency array is a fresh object " +
      "or array on every pass.",
  },
  {
    match: /must be used inside/i,
    title: "A context provider is missing",
    body:
      "A hook was called outside its provider. Check the nesting in src/main.jsx — ThemeProvider " +
      "has to wrap AppStoreProvider, which has to wrap App.",
  },
];

export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { error: null, stack: "" };
  }

  static getDerivedStateFromError(error) {
    return { error };
  }

  componentDidCatch(error, info) {
    this.setState({ stack: info?.componentStack || "" });
    // Keep the console copy too — it is the one you can expand and click through.
    console.error("Mill Floor crashed while rendering:", error, info);
  }

  render() {
    const { error, stack } = this.state;
    if (!error) return this.props.children;

    const message = String(error?.message || error);
    const hint = HINTS.find((h) => h.match.test(message));
    const frames = stack.trim().split("\n").slice(0, 12);

    const mono =
      "ui-monospace, SFMono-Regular, Menlo, Consolas, 'JetBrains Mono', monospace";

    return (
      <div
        style={{
          minHeight: "100vh",
          background: "#10131a",
          color: "#edeef3",
          fontFamily: "Inter, system-ui, sans-serif",
          padding: "40px 20px",
          display: "flex",
          justifyContent: "center",
          alignItems: "flex-start",
        }}
      >
        <div style={{ maxWidth: 720, width: "100%" }}>
          <p
            style={{
              color: "#d9694f",
              fontSize: 11,
              letterSpacing: ".08em",
              textTransform: "uppercase",
              margin: 0,
            }}
          >
            Mill Floor stopped rendering
          </p>
          <h1 style={{ fontSize: 22, margin: "8px 0 18px", fontWeight: 600 }}>
            Something threw while drawing the screen
          </h1>

          <div
            style={{
              background: "#171b24",
              border: "1px solid #262c39",
              borderLeft: "3px solid #d9694f",
              borderRadius: 8,
              padding: "14px 16px",
              fontFamily: mono,
              fontSize: 12.5,
              lineHeight: 1.6,
              whiteSpace: "pre-wrap",
              wordBreak: "break-word",
            }}
          >
            {message}
          </div>

          {hint && (
            <div
              style={{
                background: "rgba(201, 162, 75, 0.12)",
                border: "1px solid #c9a24b",
                borderRadius: 8,
                padding: "14px 16px",
                marginTop: 14,
              }}
            >
              <p style={{ color: "#c9a24b", fontSize: 13, fontWeight: 600, margin: 0 }}>
                Likely cause — {hint.title}
              </p>
              <p style={{ color: "#8a92a6", fontSize: 12.5, lineHeight: 1.65, margin: "6px 0 0" }}>
                {hint.body}
              </p>
            </div>
          )}

          {frames.length > 0 && (
            <>
              <p
                style={{
                  color: "#8a92a6",
                  fontSize: 11,
                  textTransform: "uppercase",
                  letterSpacing: ".08em",
                  margin: "22px 0 8px",
                }}
              >
                Component stack — innermost first
              </p>
              <div
                style={{
                  background: "#171b24",
                  border: "1px solid #262c39",
                  borderRadius: 8,
                  padding: "12px 16px",
                  fontFamily: mono,
                  fontSize: 12,
                  lineHeight: 1.7,
                  color: "#8a92a6",
                  overflowX: "auto",
                }}
              >
                {frames.map((line, i) => (
                  <div key={i} style={{ color: i === 0 ? "#edeef3" : undefined }}>
                    {line.trim()}
                  </div>
                ))}
              </div>
            </>
          )}

          <p style={{ color: "#8a92a6", fontSize: 12.5, lineHeight: 1.7, marginTop: 22 }}>
            The same message is in the browser console with clickable file links — open it with
            <span style={{ fontFamily: mono, color: "#edeef3" }}> ⌥⌘I </span>
            on a Mac and pick the Console tab.
          </p>

          <button
            type="button"
            onClick={() => window.location.reload()}
            style={{
              marginTop: 8,
              background: "#c9a24b",
              color: "#181205",
              border: "none",
              borderRadius: 6,
              padding: "9px 18px",
              fontSize: 13,
              fontWeight: 600,
              cursor: "pointer",
            }}
          >
            Reload
          </button>
        </div>
      </div>
    );
  }
}
