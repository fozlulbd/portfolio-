import React, { useMemo, useRef, useState } from "react";
import { Bell, PackageX, Truck, CalendarClock, WifiOff, BadgeAlert, Megaphone } from "../icons.js";
import { C, F } from "../theme/tokens.js";
import { STOCK, stockState } from "../data/inventory.js";
import { SHIPMENTS } from "../data/commercial.js";
import { DEVICES } from "../data/gate.js";
import { INSPECTIONS } from "../data/quality.js";
import { NOTICES } from "../data/notices.js";
import { useStore } from "../store/AppStore.jsx";
import { canSee } from "../auth/roles.js";
import { useClickOutside } from "../hooks/dom.js";
import { IconButton } from "./ui/Button.jsx";
import Stitch from "./ui/Stitch.jsx";

/* ---------------------------------------------------------------
   NOTIFICATIONS — derived from the data rather than a static list,
   and filtered by what the signed-in role is allowed to see. Each
   item deep-links to the page that can resolve it.
----------------------------------------------------------------*/
export default function NotificationsMenu({ role, onNavigate }) {
  const { leave } = useStore();
  const [open, setOpen] = useState(false);
  const wrap = useRef(null);
  useClickOutside(wrap, open, () => setOpen(false));

  const items = useMemo(() => {
    const out = [];

    NOTICES.filter((n) => n.pinned).forEach((n) =>
      out.push({
        id: `notice-${n.id}`,
        page: "notice",
        tone: C.gold,
        Icon: Megaphone,
        title: n.title,
        body: `Pinned notice · ${n.category}`,
      })
    );

    STOCK.filter((s) => stockState(s) === "Out of stock").forEach((s) =>
      out.push({
        id: `stock-${s.id}`,
        page: "inventory",
        tone: C.red,
        Icon: PackageX,
        title: "Yarn out of stock",
        body: `${s.item} — ${s.buyer}`,
      })
    );

    SHIPMENTS.filter((s) => s.status === "At risk").forEach((s) =>
      out.push({
        id: `ship-${s.id}`,
        page: "shipment",
        tone: C.amber,
        Icon: Truck,
        title: `${s.buyer} shipment at risk`,
        body: s.risk || `Ex-factory ${s.date}`,
      })
    );

    INSPECTIONS.filter((q) => q.result === "Fail").forEach((q) =>
      out.push({
        id: `qc-${q.id}`,
        page: "quality",
        tone: C.red,
        Icon: BadgeAlert,
        title: `${q.line} failed AQL ${q.aql}`,
        body: `${q.rejected} rejected of ${q.checked} · style ${q.styleNo}`,
      })
    );

    const pending = leave.filter((l) => l.status === "Pending").length;
    if (pending) {
      out.push({
        id: "leave-pending",
        page: "leave",
        tone: C.gold,
        Icon: CalendarClock,
        title: `${pending} leave request${pending > 1 ? "s" : ""} waiting`,
        body: "Approve or reject before the shift closes",
      });
    }

    DEVICES.filter((d) => d.status === "Offline").forEach((d) =>
      out.push({
        id: `dev-${d.id}`,
        page: "gate",
        tone: C.red,
        Icon: WifiOff,
        title: `${d.name} offline`,
        body: `${d.gate} · last sync ${d.lastSync}`,
      })
    );

    return out.filter((i) => canSee(role, i.page));
  }, [leave, role]);

  return (
    <div ref={wrap} className="relative">
      <IconButton
        icon={Bell}
        label={`Notifications${items.length ? ` (${items.length})` : ""}`}
        badge={items.length > 0}
        active={open}
        onClick={() => setOpen((o) => !o)}
      />

      {open && (
        <div
          style={{ background: C.panel, border: `1px solid ${C.line}`, boxShadow: C.shadow }}
          className="absolute right-0 mt-2 w-80 rounded-lg overflow-hidden z-50 animate-rise-in"
        >
          <div className="px-4 py-3 flex items-center justify-between">
            <p style={{ fontFamily: F.display, color: C.text }} className="text-sm font-semibold">
              Needs attention
            </p>
            <span style={{ color: C.muted, fontFamily: F.mono }} className="text-[11px]">
              {items.length}
            </span>
          </div>
          <Stitch />

          {items.length === 0 ? (
            <p style={{ color: C.muted }} className="text-xs px-4 py-6 text-center">
              Nothing outstanding. The floor is clear.
            </p>
          ) : (
            <ul className="max-h-80 overflow-y-auto">
              {items.map((it) => (
                <li key={it.id} style={{ borderTop: `1px solid ${C.line}` }}>
                  <button
                    type="button"
                    onClick={() => {
                      onNavigate(it.page);
                      setOpen(false);
                    }}
                    className="w-full text-left px-4 py-3 flex items-start gap-2.5 transition-colors hover:brightness-125"
                  >
                    <span
                      style={{ color: it.tone, background: C.goldDim }}
                      className="w-6 h-6 rounded flex items-center justify-center shrink-0 mt-0.5"
                    >
                      <it.Icon size={12} strokeWidth={2.5} />
                    </span>
                    <span className="min-w-0">
                      <span style={{ color: C.text }} className="text-xs block">
                        {it.title}
                      </span>
                      <span style={{ color: C.muted }} className="text-[11px] block mt-0.5 leading-snug">
                        {it.body}
                      </span>
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}
