import React, { useMemo, useRef, useState } from "react";
import { Search, X, CornerDownLeft } from "../icons.js";
import { C, F } from "../theme/tokens.js";
import { search } from "../lib/table.js";
import { useStore } from "../store/AppStore.jsx";
import { useClickOutside, useHotkey } from "../hooks/dom.js";
import Avatar from "./ui/Avatar.jsx";
import StatusPill from "./ui/StatusPill.jsx";
import Stitch from "./ui/Stitch.jsx";

const KEYS = ["name", "id", "mobile", "dept", "designation", "line", "nid"];

/* ---------------------------------------------------------------
   GLOBAL SEARCH — ⌘K, searches the whole employee register by name,
   staff ID, mobile, department or NID. Selecting a hit opens that
   person's drawer wherever you happen to be in the app.
----------------------------------------------------------------*/
export default function GlobalSearch({ onSelect }) {
  const { people } = useStore();
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [cursor, setCursor] = useState(0);
  const wrap = useRef(null);
  const input = useRef(null);

  useClickOutside(wrap, open, () => setOpen(false));
  useHotkey("k", () => {
    input.current?.focus();
    setOpen(true);
  });

  const hits = useMemo(() => {
    if (query.trim().length < 2) return [];
    return search(people, query, KEYS).slice(0, 7);
  }, [people, query]);

  function choose(person) {
    onSelect(person);
    setOpen(false);
    setQuery("");
    input.current?.blur();
  }

  function onKeyDown(e) {
    if (!hits.length) return;
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setCursor((c) => (c + 1) % hits.length);
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setCursor((c) => (c - 1 + hits.length) % hits.length);
    } else if (e.key === "Enter") {
      e.preventDefault();
      choose(hits[cursor] || hits[0]);
    } else if (e.key === "Escape") {
      setOpen(false);
    }
  }

  return (
    <div ref={wrap} className="relative">
      <div
        style={{ background: C.panelAlt, border: `1px solid ${open && query ? C.gold : C.line}` }}
        className="flex items-center gap-2 px-3 py-2 rounded-md transition-colors"
      >
        <Search size={14} style={{ color: C.muted }} />
        <input
          ref={input}
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setCursor(0);
            setOpen(true);
          }}
          onFocus={() => setOpen(true)}
          onKeyDown={onKeyDown}
          placeholder="Search worker ID, name, mobile…"
          aria-label="Search employees"
          style={{ background: "transparent", color: C.text }}
          className="text-xs outline-none w-32 sm:w-52"
        />
        {query ? (
          <button type="button" aria-label="Clear" onClick={() => setQuery("")}>
            <X size={13} style={{ color: C.muted }} />
          </button>
        ) : (
          <kbd
            style={{ color: C.muted, border: `1px solid ${C.line}`, fontFamily: F.mono }}
            className="hidden sm:block text-[10px] px-1.5 py-0.5 rounded"
          >
            ⌘K
          </kbd>
        )}
      </div>

      {open && query.trim().length >= 2 && (
        <div
          style={{ background: C.panel, border: `1px solid ${C.line}`, boxShadow: C.shadow }}
          className="absolute right-0 mt-2 w-[19rem] sm:w-[22rem] rounded-lg overflow-hidden z-50 animate-rise-in"
        >
          {hits.length === 0 ? (
            <p style={{ color: C.muted }} className="text-xs px-4 py-5 text-center">
              No employee matches “{query}”.
            </p>
          ) : (
            <>
              <p style={{ color: C.muted }} className="text-[10px] uppercase tracking-wide px-4 pt-3 pb-2">
                {hits.length} match{hits.length > 1 ? "es" : ""}
              </p>
              <Stitch />
              <ul>
                {hits.map((p, i) => (
                  <li key={p.id}>
                    <button
                      type="button"
                      onMouseEnter={() => setCursor(i)}
                      onClick={() => choose(p)}
                      style={{ background: i === cursor ? C.goldDim : "transparent" }}
                      className="w-full text-left px-4 py-2.5 flex items-center gap-2.5 transition-colors"
                    >
                      <Avatar name={p.name} size="sm" src={p.photo} />
                      <span className="flex-1 min-w-0">
                        <span style={{ color: C.text }} className="text-xs block truncate">
                          {p.name}
                        </span>
                        <span
                          style={{ color: C.muted, fontFamily: F.mono }}
                          className="text-[10px] block truncate"
                        >
                          {p.id} · {p.designation} · {p.dept}
                        </span>
                      </span>
                      <StatusPill status={p.status} size="xs" />
                    </button>
                  </li>
                ))}
              </ul>
              <Stitch />
              <p
                style={{ color: C.muted, fontFamily: F.mono }}
                className="text-[10px] px-4 py-2 flex items-center gap-1.5"
              >
                <CornerDownLeft size={10} /> enter to open · ↑↓ to move
              </p>
            </>
          )}
        </div>
      )}
    </div>
  );
}
