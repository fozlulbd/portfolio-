import React, {
  createContext, useCallback, useContext, useMemo, useReducer, useRef,
} from "react";
import { makeAllPeople, nextId } from "../data/people.js";
import { LEAVE_REQUESTS } from "../data/leave.js";
import { ROLE_LABEL } from "../data/constants.js";

/* ---------------------------------------------------------------
   APP STORE — a reducer over the mutable slices of the app: the
   employee register, leave decisions and the toast queue. Uploaded
   files are held as object URLs in memory only; nothing is persisted,
   so a reload returns the factory to its seeded state.
----------------------------------------------------------------*/

const AppStoreContext = createContext(null);

function init() {
  return {
    people: makeAllPeople(),
    leave: LEAVE_REQUESTS.map((l) => ({ ...l })),
    toasts: [],
  };
}

function reducer(state, action) {
  switch (action.type) {
    case "person/add": {
      const person = action.person;
      return { ...state, people: [person, ...state.people] };
    }

    case "person/update": {
      const { id, patch } = action;
      return {
        ...state,
        people: state.people.map((p) =>
          p.id === id ? { ...p, ...patch, role: ROLE_LABEL[patch.roleKey ?? p.roleKey] } : p
        ),
      };
    }

    case "person/remove":
      return { ...state, people: state.people.filter((p) => !action.ids.includes(p.id)) };

    case "person/status":
      return {
        ...state,
        people: state.people.map((p) =>
          action.ids.includes(p.id)
            ? {
                ...p,
                status: action.status,
                // Clearing a punch when someone is marked away keeps the
                // attendance sheet internally consistent.
                punchIn: action.status === "Absent" || action.status === "On leave" ? "--:--" : p.punchIn,
                punchOut: action.status === "Absent" || action.status === "On leave" ? "--:--" : p.punchOut,
              }
            : p
        ),
      };

    case "person/photo":
      return {
        ...state,
        people: state.people.map((p) => (p.id === action.id ? { ...p, photo: action.photo } : p)),
      };

    case "doc/add":
      return {
        ...state,
        people: state.people.map((p) =>
          p.id === action.personId ? { ...p, documents: [...p.documents, ...action.docs] } : p
        ),
      };

    case "doc/remove":
      return {
        ...state,
        people: state.people.map((p) =>
          p.id === action.personId
            ? { ...p, documents: p.documents.filter((d) => d.id !== action.docId) }
            : p
        ),
      };

    case "leave/decide":
      return {
        ...state,
        leave: state.leave.map((l) =>
          l.id === action.id ? { ...l, status: action.status, note: action.note ?? l.note } : l
        ),
      };

    case "toast/push":
      return { ...state, toasts: [...state.toasts, action.toast].slice(-4) };

    case "toast/dismiss":
      return { ...state, toasts: state.toasts.filter((t) => t.id !== action.id) };

    default:
      return state;
  }
}

export function AppStoreProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, undefined, init);
  const toastSeq = useRef(0);

  const toast = useCallback((message, tone = "success") => {
    const id = `T${++toastSeq.current}`;
    dispatch({ type: "toast/push", toast: { id, message, tone } });
    setTimeout(() => dispatch({ type: "toast/dismiss", id }), 3600);
  }, []);

  const api = useMemo(() => {
    const peopleOf = (roleKey) => state.people.filter((p) => p.roleKey === roleKey);

    return {
      ...state,
      peopleOf,
      byId: (id) => state.people.find((p) => p.id === id) || null,

      addPerson(draft) {
        const person = {
          ...draft,
          id: draft.id || nextId(state.people, draft.roleKey),
          role: ROLE_LABEL[draft.roleKey],
          basic: Number(draft.basic) || 0,
        };
        dispatch({ type: "person/add", person });
        toast(`${person.name} added as ${person.role} · ${person.id}`);
        return person;
      },

      updatePerson(id, patch) {
        dispatch({ type: "person/update", id, patch: { ...patch, basic: Number(patch.basic) || 0 } });
        toast(`${patch.name || id} updated`);
      },

      removePeople(ids) {
        dispatch({ type: "person/remove", ids });
        toast(`${ids.length} record${ids.length > 1 ? "s" : ""} deleted`, "danger");
      },

      setStatus(ids, status) {
        dispatch({ type: "person/status", ids, status });
        toast(`${ids.length} marked ${status.toLowerCase()}`, status === "Absent" ? "warn" : "success");
      },

      // Dedicated action for the profile photo alone — routing this
      // through updatePerson would run patch.basic through Number(),
      // and a photo-only patch has no basic field, so it would zero
      // out the person's salary as a side effect.
      setPersonPhoto(id, photo) {
        dispatch({ type: "person/photo", id, photo });
        toast(photo ? "Profile photo updated" : "Profile photo removed");
      },

      addDocuments(personId, docs) {
        dispatch({ type: "doc/add", personId, docs });
        toast(`${docs.length} document${docs.length > 1 ? "s" : ""} uploaded`);
      },

      removeDocument(personId, docId, label) {
        dispatch({ type: "doc/remove", personId, docId });
        toast(`${label || "Document"} removed`, "danger");
      },

      decideLeave(id, status, note) {
        dispatch({ type: "leave/decide", id, status, note });
        toast(`Leave ${id} ${status.toLowerCase()}`, status === "Approved" ? "success" : "warn");
      },

      toast,
      dismissToast: (id) => dispatch({ type: "toast/dismiss", id }),
    };
  }, [state, toast]);

  return <AppStoreContext.Provider value={api}>{children}</AppStoreContext.Provider>;
}

export function useStore() {
  const ctx = useContext(AppStoreContext);
  if (!ctx) throw new Error("useStore must be used inside <AppStoreProvider>");
  return ctx;
}
