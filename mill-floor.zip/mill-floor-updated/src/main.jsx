import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App.jsx";
import ErrorBoundary from "./components/ErrorBoundary.jsx";
import { ThemeProvider } from "./theme/ThemeProvider.jsx";
import { AppStoreProvider } from "./store/AppStore.jsx";
import "./index.css";

/* ErrorBoundary sits outside the providers on purpose: if the theme or
   the store is what throws, the boundary is still mounted to report it. */
ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <ErrorBoundary>
      <ThemeProvider>
        <AppStoreProvider>
          <App />
        </AppStoreProvider>
      </ThemeProvider>
    </ErrorBoundary>
  </React.StrictMode>
);
