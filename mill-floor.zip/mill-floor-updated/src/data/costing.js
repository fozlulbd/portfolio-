/* Merchandising's numbers: what a style is made of, what it costs to
   land at FOB, and where each order sits between PI and LC. Kept on
   the same three styles as data/commercial.js so a merchandiser can
   follow one order across Buyer Info → Requirement → Costing → PI/LC
   → Shipment without the names drifting. */

export const BOM_LINES = [
  { id: "BOM-01", styleNo: "NK-118", buyer: "NordicKnit AB", material: "Merino wool 2/28 — Charcoal", consumption: 0.312, uom: "kg/pc", rate: 18.4, category: "Yarn" },
  { id: "BOM-02", styleNo: "NK-118", buyer: "NordicKnit AB", material: "Woven main label — NK", consumption: 1, uom: "pcs/pc", rate: 0.06, category: "Trims" },
  { id: "BOM-03", styleNo: "NK-118", buyer: "NordicKnit AB", material: "Care label — NK", consumption: 1, uom: "pcs/pc", rate: 0.03, category: "Trims" },
  { id: "BOM-04", styleNo: "NK-118", buyer: "NordicKnit AB", material: "Polybag 320×420 mm", consumption: 1, uom: "pcs/pc", rate: 0.04, category: "Packing" },

  { id: "BOM-05", styleNo: "MF-42", buyer: "Marlowe & Fenn", material: "Lambswool/nylon 2/30 — Navy", consumption: 0.248, uom: "kg/pc", rate: 15.9, category: "Yarn" },
  { id: "BOM-06", styleNo: "MF-42", buyer: "Marlowe & Fenn", material: "Care label — MF", consumption: 1, uom: "pcs/pc", rate: 0.03, category: "Trims" },
  { id: "BOM-07", styleNo: "MF-42", buyer: "Marlowe & Fenn", material: "Sewing thread 40/2 — Navy", consumption: 0.018, uom: "cone/pc", rate: 4.2, category: "Trims" },
  { id: "BOM-08", styleNo: "MF-42", buyer: "Marlowe & Fenn", material: "Polybag 320×420 mm", consumption: 1, uom: "pcs/pc", rate: 0.04, category: "Packing" },

  { id: "BOM-09", styleNo: "RT-77", buyer: "Rivage Textile", material: "Wool/alpaca 1/12 — Camel", consumption: 0.486, uom: "kg/pc", rate: 24.6, category: "Yarn" },
  { id: "BOM-10", styleNo: "RT-77", buyer: "Rivage Textile", material: "Zip puller — chunky roll-neck", consumption: 1, uom: "pcs/pc", rate: 0.11, category: "Trims" },
  { id: "BOM-11", styleNo: "RT-77", buyer: "Rivage Textile", material: "Trim Card", consumption: 1, uom: "pcs/pc", rate: 0.08, category: "Trims" },
  { id: "BOM-12", styleNo: "RT-77", buyer: "Rivage Textile", material: "Carton 5-ply 60×40×30", consumption: 0.05, uom: "pcs/pc", rate: 0.42, category: "Packing" },
];

/** Cost build-up to FOB. cm = cut-make (or in knitwear, knit-make) labour cost per piece. */
export const COST_SHEET = [
  { styleNo: "NK-118", buyer: "NordicKnit AB", qty: 12_400, cm: 4.85, overheadPct: 0.12, fobPrice: 21.4 },
  { styleNo: "MF-42", buyer: "Marlowe & Fenn", qty: 8_000, cm: 3.95, overheadPct: 0.11, fobPrice: 18.75 },
  { styleNo: "RT-77", buyer: "Rivage Textile", qty: 5_600, cm: 6.4, overheadPct: 0.13, fobPrice: 26.9 },
];

/** Sum of a style's BOM lines, in USD per piece. */
export function materialCost(styleNo) {
  return BOM_LINES.filter((b) => b.styleNo === styleNo).reduce((sum, b) => sum + b.consumption * b.rate, 0);
}

/** Full build-up: material + CM + overhead -> factory cost -> margin against the agreed FOB. */
export function costBuildUp(row) {
  const material = materialCost(row.styleNo);
  const overhead = (material + row.cm) * row.overheadPct;
  const factoryCost = material + row.cm + overhead;
  const marginPerPc = row.fobPrice - factoryCost;
  const marginPct = row.fobPrice ? marginPerPc / row.fobPrice : 0;
  return { material, overhead, factoryCost, marginPerPc, marginPct, orderValue: row.fobPrice * row.qty };
}

export const PI_LC = [
  {
    id: "PI-2214",
    buyer: "NordicKnit AB",
    styleNo: "NK-118",
    value: 265_360,
    currency: "USD",
    piDate: "2026-07-02",
    lcNumber: "LC-SEB-88410",
    lcStatus: "Opened",
    lcExpiry: "2026-11-10",
  },
  {
    id: "PI-0871",
    buyer: "Marlowe & Fenn",
    styleNo: "MF-42",
    value: 150_000,
    currency: "USD",
    piDate: "2026-07-18",
    lcNumber: "—",
    lcStatus: "TT advance",
    lcExpiry: "—",
  },
  {
    id: "PI-3390",
    buyer: "Rivage Textile",
    styleNo: "RT-77",
    value: 150_640,
    currency: "USD",
    piDate: "2026-08-05",
    lcNumber: "LC-BNP-30215",
    lcStatus: "Amended",
    lcExpiry: "2026-12-01",
  },
];
