/* Leave requests awaiting a decision, plus the factory holiday calendar.
   Requests carry a `status` the store mutates on approve / reject. */

export const LEAVE_REQUESTS = [
  { id: "LV-2201", empId: "WK-1003", name: "Salma Akter", dept: "Packing", type: "Sick", from: "2026-08-25", to: "2026-08-27", days: 3, reason: "Fever, doctor advised rest. Prescription attached.", status: "Pending", appliedOn: "2026-08-23" },
  { id: "LV-2202", empId: "WK-1011", name: "Rupa Khatun", dept: "Linking", type: "Casual", from: "2026-08-30", to: "2026-08-30", days: 1, reason: "Sister's wedding at village home.", status: "Pending", appliedOn: "2026-08-22" },
  { id: "LV-2203", empId: "SV-1002", name: "Jamal Islam", dept: "Knitting", type: "Earned", from: "2026-09-05", to: "2026-09-09", days: 5, reason: "Annual leave — 14 days still in balance.", status: "Pending", appliedOn: "2026-08-20" },
  { id: "LV-2204", empId: "WK-1027", name: "Nasrin Begum", dept: "Finishing", type: "Maternity", from: "2026-09-01", to: "2026-12-24", days: 112, reason: "Statutory maternity leave, 16 weeks.", status: "Approved", appliedOn: "2026-08-04" },
  { id: "LV-2205", empId: "BU-1004", name: "Momtaz Sultana", dept: "Packing", type: "Casual", from: "2026-08-21", to: "2026-08-22", days: 2, reason: "Family matter.", status: "Rejected", appliedOn: "2026-08-19", note: "Peak shipment week — asked to reschedule to September." },
  { id: "LV-2206", empId: "ST-1006", name: "Habib Ahmed", dept: "Quality", type: "Casual", from: "2026-09-12", to: "2026-09-13", days: 2, reason: "Passport renewal appointment in Dhaka.", status: "Pending", appliedOn: "2026-08-24" },
];

export const HOLIDAYS = [
  { date: "2026-09-04", name: "Eid-e-Miladunnabi", kind: "Government" },
  { date: "2026-09-29", name: "Durga Puja (Bijoya Dashami)", kind: "Government" },
  { date: "2026-10-16", name: "Factory annual maintenance", kind: "Factory" },
  { date: "2026-12-16", name: "Victory Day", kind: "Government" },
  { date: "2026-12-25", name: "Christmas Day", kind: "Government" },
];

export const LEAVE_BALANCE = [
  { type: "Casual", entitled: 10, taken: 6 },
  { type: "Sick", entitled: 14, taken: 4 },
  { type: "Earned", entitled: 18, taken: 4 },
  { type: "Festival", entitled: 11, taken: 8 },
];
