/* Production floor: line-wise efficiency against SMV-derived targets,
   hourly output for the current shift, and WIP sitting at each process. */

export const LINE_PERFORMANCE = [
  { line: "Line 1", styleNo: "NK-118", operators: 42, smv: 18.4, target: 780, output: 742, defects: 11 },
  { line: "Line 2", styleNo: "NK-118", operators: 40, smv: 18.4, target: 745, output: 769, defects: 8 },
  { line: "Line 3", styleNo: "MF-42", operators: 38, smv: 14.2, target: 910, output: 803, defects: 24 },
  { line: "Line 4", styleNo: "MF-42", operators: 39, smv: 14.2, target: 930, output: 921, defects: 13 },
  { line: "Line 5", styleNo: "RT-77", operators: 36, smv: 26.8, target: 470, output: 388, defects: 19 },
  { line: "Line 6", styleNo: "RT-77", operators: 35, smv: 26.8, target: 455, output: 449, defects: 6 },
];

export const HOURLY_OUTPUT = [
  { hour: "08:00", output: 402, target: 430 },
  { hour: "09:00", output: 448, target: 430 },
  { hour: "10:00", output: 461, target: 430 },
  { hour: "11:00", output: 437, target: 430 },
  { hour: "12:00", output: 296, target: 300 },
  { hour: "13:00", output: 418, target: 430 },
  { hour: "14:00", output: 455, target: 430 },
  { hour: "15:00", output: 469, target: 430 },
  { hour: "16:00", output: 421, target: 430 },
];

export const WIP = [
  { process: "Yarn store", pcs: 0, kg: 4_820 },
  { process: "Knitting", pcs: 9_140, kg: 0 },
  { process: "Linking", pcs: 6_310, kg: 0 },
  { process: "Trimming", pcs: 2_980, kg: 0 },
  { process: "Finishing", pcs: 4_520, kg: 0 },
  { process: "Ironing", pcs: 1_870, kg: 0 },
  { process: "Packing", pcs: 3_240, kg: 0 },
];

export function efficiency(row) {
  return row.target ? row.output / row.target : 0;
}

export function productionSummary(rows = LINE_PERFORMANCE) {
  const output = rows.reduce((a, r) => a + r.output, 0);
  const target = rows.reduce((a, r) => a + r.target, 0);
  const operators = rows.reduce((a, r) => a + r.operators, 0);
  const defects = rows.reduce((a, r) => a + r.defects, 0);
  return {
    output,
    target,
    operators,
    defects,
    efficiency: target ? output / target : 0,
    dhu: output ? (defects / output) * 100 : 0,
    best: [...rows].sort((a, b) => efficiency(b) - efficiency(a))[0],
    worst: [...rows].sort((a, b) => efficiency(a) - efficiency(b))[0],
  };
}
