/* Yarn & trims store. `reorder` is the level at which the store keeper
   is supposed to raise a requisition — anything at or below it is what
   the low-stock strip on the page surfaces. */

export const STOCK = [
  { id: "YRN-001", item: "Merino wool 2/28 — Charcoal", category: "Yarn", unit: "kg", inStock: 1_840, reorder: 900, buyer: "NordicKnit AB", lot: "LOT-8841", location: "Store A · Rack 3" },
  { id: "YRN-002", item: "Merino wool 2/28 — Oat", category: "Yarn", unit: "kg", inStock: 720, reorder: 900, buyer: "NordicKnit AB", lot: "LOT-8842", location: "Store A · Rack 3" },
  { id: "YRN-003", item: "Lambswool/nylon 2/30 — Navy", category: "Yarn", unit: "kg", inStock: 1_260, reorder: 800, buyer: "Marlowe & Fenn", lot: "LOT-9013", location: "Store A · Rack 5" },
  { id: "YRN-004", item: "Lambswool/nylon 2/30 — Ecru", category: "Yarn", unit: "kg", inStock: 410, reorder: 800, buyer: "Marlowe & Fenn", lot: "LOT-9014", location: "Store A · Rack 5" },
  { id: "YRN-005", item: "Wool/alpaca 1/12 — Camel", category: "Yarn", unit: "kg", inStock: 0, reorder: 600, buyer: "Rivage Textile", lot: "—", location: "In transit · customs" },
  { id: "TRM-011", item: "Woven main label — NK", category: "Trims", unit: "pcs", inStock: 14_200, reorder: 6_000, buyer: "NordicKnit AB", lot: "TRM-2214", location: "Store B · Bin 12" },
  { id: "TRM-012", item: "Care label — MF", category: "Trims", unit: "pcs", inStock: 5_100, reorder: 6_000, buyer: "Marlowe & Fenn", lot: "TRM-0871", location: "Store B · Bin 14" },
  { id: "TRM-013", item: "Polybag 320×420 mm", category: "Packing", unit: "pcs", inStock: 22_800, reorder: 10_000, buyer: "All", lot: "PKG-77", location: "Store C · Floor" },
  { id: "TRM-014", item: "Carton 5-ply 60×40×30", category: "Packing", unit: "pcs", inStock: 1_950, reorder: 2_500, buyer: "All", lot: "PKG-91", location: "Store C · Floor" },
  { id: "TRM-015", item: "Sewing thread 40/2 — Navy", category: "Trims", unit: "cone", inStock: 640, reorder: 300, buyer: "Marlowe & Fenn", lot: "TRM-0872", location: "Store B · Bin 09" },
  { id: "YRN-006", item: "Cotton/acrylic 2/24 — Charcoal", category: "Yarn", unit: "kg", inStock: 980, reorder: 700, buyer: "Rivage Textile", lot: "LOT-9102", location: "Store A · Rack 6" },
  { id: "TRM-016", item: "Hang tag — NK collection", category: "Trims", unit: "pcs", inStock: 9_400, reorder: 4_000, buyer: "NordicKnit AB", lot: "TRM-2231", location: "Store B · Bin 16" },
  { id: "TRM-017", item: "Zip puller — chunky roll-neck", category: "Trims", unit: "pcs", inStock: 1_800, reorder: 2_000, buyer: "Rivage Textile", lot: "TRM-3390", location: "Store B · Bin 17" },
  { id: "PKG-021", item: "Master carton label", category: "Packing", unit: "pcs", inStock: 6_200, reorder: 3_000, buyer: "All", lot: "PKG-104", location: "Store C · Floor" },
];

export function stockState(row) {
  if (row.inStock === 0) return "Out of stock";
  if (row.inStock <= row.reorder) return "Reorder";
  return "In stock";
}

export function stockSummary(rows = STOCK) {
  return {
    lines: rows.length,
    out: rows.filter((r) => r.inStock === 0).length,
    reorder: rows.filter((r) => r.inStock > 0 && r.inStock <= r.reorder).length,
    healthy: rows.filter((r) => r.inStock > r.reorder).length,
  };
}

/* ---------------------------------------------------------------
   BUY / SELL — the store keeper's actual transaction log. Purchases
   bring material in against a supplier bill; sales cover both a
   buyer-billed consumption (the normal case: material issued against
   an order and invoiced in the FOB price) and the occasional sale of
   genuine surplus/leftover stock to a local buyer, which is the
   transaction a factory store keeper means by "sell".
----------------------------------------------------------------*/
export const PURCHASES = [
  { id: "PU-3301", item: "Merino wool 2/28 — Charcoal", itemId: "YRN-001", qty: 800, unit: "kg", unitCost: 780, supplier: "Zegna Baruffa (via local agent)", invoice: "INV-77042", date: "2026-08-02" },
  { id: "PU-3302", item: "Lambswool/nylon 2/30 — Ecru", itemId: "YRN-004", qty: 500, unit: "kg", unitCost: 640, supplier: "Woolmark Trading Ltd", invoice: "INV-77098", date: "2026-08-09" },
  { id: "PU-3303", item: "Wool/alpaca 1/12 — Camel", itemId: "YRN-005", qty: 600, unit: "kg", unitCost: 1_140, supplier: "Andes Fibre Co.", invoice: "INV-77121", date: "2026-08-14" },
  { id: "PU-3304", item: "Woven main label — NK", itemId: "TRM-011", qty: 20_000, unit: "pcs", unitCost: 3.2, supplier: "Apex Label & Trims", invoice: "INV-55201", date: "2026-08-05" },
  { id: "PU-3305", item: "Hang tag — NK collection", itemId: "TRM-016", qty: 10_000, unit: "pcs", unitCost: 2.6, supplier: "Apex Label & Trims", invoice: "INV-55238", date: "2026-08-18" },
  { id: "PU-3306", item: "Carton 5-ply 60×40×30", itemId: "TRM-014", qty: 3_000, unit: "pcs", unitCost: 85, supplier: "Bengal Packaging", invoice: "INV-19087", date: "2026-08-11" },
];

export const SALES = [
  { id: "SL-4401", item: "Merino wool 2/28 — Charcoal", itemId: "YRN-001", qty: 12_400, unit: "pcs (consumption)", unitPrice: 21.4 * 82, buyer: "NordicKnit AB", refOrder: "PI-2026-041", type: "Order consumption", date: "2026-08-20" },
  { id: "SL-4402", item: "Lambswool/nylon 2/30 — Navy", itemId: "YRN-003", qty: 8_000, unit: "pcs (consumption)", unitPrice: 18.75 * 82, buyer: "Marlowe & Fenn", refOrder: "PI-2026-042", type: "Order consumption", date: "2026-08-21" },
  { id: "SL-4403", item: "Cotton/acrylic 2/24 — Charcoal", itemId: "YRN-006", qty: 180, unit: "kg", unitPrice: 165, buyer: "Local — Karim Yarn Traders", refOrder: "—", type: "Surplus sale", date: "2026-08-12" },
  { id: "SL-4404", item: "Sewing thread 40/2 — Navy", itemId: "TRM-015", qty: 60, unit: "cone", unitPrice: 210, buyer: "Local — Nabid Accessories", refOrder: "—", type: "Surplus sale", date: "2026-08-15" },
];

export function costSummary() {
  const totalPurchase = PURCHASES.reduce((a, p) => a + p.qty * p.unitCost, 0);
  const totalSales = SALES.reduce((a, s) => a + s.qty * s.unitPrice, 0);
  const surplusSales = SALES.filter((s) => s.type === "Surplus sale");
  const surplusValue = surplusSales.reduce((a, s) => a + s.qty * s.unitPrice, 0);
  return {
    totalPurchase,
    totalSales,
    surplusValue,
    surplusCount: surplusSales.length,
    netPosition: totalSales - totalPurchase,
  };
}

