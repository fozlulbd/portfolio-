/* Quality: defect counts for the current day, ordered so a Pareto
   reads left-to-right, plus per-line inspection results. */

export const DEFECTS = [
  { defect: "Dropped stitch", count: 31, process: "Knitting" },
  { defect: "Uneven linking", count: 24, process: "Linking" },
  { defect: "Loose thread", count: 19, process: "Finishing" },
  { defect: "Measurement out", count: 14, process: "Finishing" },
  { defect: "Yarn shade variation", count: 11, process: "Knitting" },
  { defect: "Hole / cut", count: 8, process: "Knitting" },
  { defect: "Label misplaced", count: 6, process: "Packing" },
  { defect: "Oil stain", count: 5, process: "Finishing" },
];

export const INSPECTIONS = [
  { id: "QC-4471", line: "Line 1", styleNo: "NK-118", offered: 742, checked: 742, rejected: 11, aql: "2.5", result: "Pass" },
  { id: "QC-4472", line: "Line 2", styleNo: "NK-118", offered: 769, checked: 769, rejected: 8, aql: "2.5", result: "Pass" },
  { id: "QC-4473", line: "Line 3", styleNo: "MF-42", offered: 803, checked: 803, rejected: 24, aql: "2.5", result: "Fail" },
  { id: "QC-4474", line: "Line 4", styleNo: "MF-42", offered: 921, checked: 921, rejected: 13, aql: "2.5", result: "Pass" },
  { id: "QC-4475", line: "Line 5", styleNo: "RT-77", offered: 388, checked: 388, rejected: 19, aql: "2.5", result: "Fail" },
  { id: "QC-4476", line: "Line 6", styleNo: "RT-77", offered: 449, checked: 449, rejected: 6, aql: "2.5", result: "Pass" },
];

/** Adds running cumulative share — the line that makes a Pareto a Pareto. */
export function paretoData(rows = DEFECTS) {
  const total = rows.reduce((a, r) => a + r.count, 0) || 1;
  let running = 0;
  return [...rows]
    .sort((a, b) => b.count - a.count)
    .map((r) => {
      running += r.count;
      return { ...r, share: r.count / total, cumulative: Number(((running / total) * 100).toFixed(1)) };
    });
}

export function qualitySummary(rows = INSPECTIONS) {
  const checked = rows.reduce((a, r) => a + r.checked, 0);
  const rejected = rows.reduce((a, r) => a + r.rejected, 0);
  return {
    checked,
    rejected,
    passRate: checked ? (checked - rejected) / checked : 0,
    dhu: checked ? (rejected / checked) * 100 : 0,
    failedLots: rows.filter((r) => r.result === "Fail").length,
  };
}
