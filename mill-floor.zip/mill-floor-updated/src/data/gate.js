/* Gate & device log — what the biometric terminals and the guard desk
   recorded. This is the security role's home screen. */

export const GATE_LOG = [
  { id: "GT-9901", time: "07:38", empId: "WK-1000", name: "Karim Mia", dir: "IN", gate: "Gate 1", device: "SenseFace 3A", method: "Face" },
  { id: "GT-9902", time: "07:41", empId: "WK-1006", name: "Anwar Hossain", dir: "IN", gate: "Gate 1", device: "SenseFace 3A", method: "Face" },
  { id: "GT-9903", time: "07:44", empId: "SV-1001", name: "Rahim Begum", dir: "IN", gate: "Gate 2", device: "ZKTeco F18", method: "Finger" },
  { id: "GT-9904", time: "07:52", empId: "ST-1002", name: "Jamal Islam", dir: "IN", gate: "Gate 1", device: "SenseFace 3A", method: "Face" },
  { id: "GT-9905", time: "08:26", empId: "WK-1004", name: "Nasrin Akter", dir: "IN", gate: "Gate 1", device: "SenseFace 3A", method: "Face", flag: "Late" },
  { id: "GT-9906", time: "08:31", empId: "WK-1009", name: "Selina Khatun", dir: "IN", gate: "Gate 3", device: "ZKTeco F18", method: "Card", flag: "Late" },
  { id: "GT-9907", time: "12:04", empId: "MG-1001", name: "Rahim Ahmed", dir: "OUT", gate: "Gate 1", device: "SenseFace 3A", method: "Face", flag: "Official duty" },
  { id: "GT-9908", time: "13:15", empId: "MG-1001", name: "Rahim Ahmed", dir: "IN", gate: "Gate 1", device: "SenseFace 3A", method: "Face" },
  { id: "GT-9909", time: "17:02", empId: "WK-1000", name: "Karim Mia", dir: "OUT", gate: "Gate 1", device: "SenseFace 3A", method: "Face" },
  { id: "GT-9910", time: "17:06", empId: "BU-1001", name: "Rupa Begum", dir: "OUT", gate: "Gate 3", device: "ZKTeco F18", method: "Finger" },
];

export const VISITORS = [
  { id: "VS-341", time: "10:12", name: "Camille Perrot", org: "Rivage Textile", purpose: "Pre-production meeting", host: "Merchandising", badge: "V-07", status: "Inside" },
  { id: "VS-342", time: "11:40", name: "Md. Sirajul Haque", org: "Bengal Lines", purpose: "Carton delivery", host: "Store", badge: "V-11", status: "Left" },
  { id: "VS-343", time: "14:05", name: "Tanvir Rahman", org: "SGS Bangladesh", purpose: "AQL 2.5 inspection — MF-42", host: "Quality", badge: "V-14", status: "Inside" },
];

export const DEVICES = [
  { id: "DV-1", name: "SenseFace 3A", gate: "Gate 1", status: "Online", punchesToday: 2_914, lastSync: "17:41" },
  { id: "DV-2", name: "ZKTeco F18", gate: "Gate 2", status: "Online", punchesToday: 806, lastSync: "17:40" },
  { id: "DV-3", name: "ZKTeco F18", gate: "Gate 3", status: "Online", punchesToday: 641, lastSync: "17:41" },
  { id: "DV-4", name: "SenseFace 3A", gate: "Gate 4 (yarn store)", status: "Offline", punchesToday: 0, lastSync: "09:12" },
];
