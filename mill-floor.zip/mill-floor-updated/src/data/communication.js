/* Call & Message: two different logs sharing one page.
   CALL_LOG is the front-desk/intercom record — who called or was
   called, about what. MESSAGES are office broadcasts pushed to the
   worker mobile app (and SMS for the workers without the app),
   the same "office notice" channel promised alongside the Android
   attendance app. */

export const CALL_LOG = [
  { id: "CL-771", time: "09:12", direction: "Incoming", party: "Erik Lund — NordicKnit AB", topic: "Ex-factory date confirmation for NK-118", handledBy: "Merchandising", duration: "6 min", status: "Completed" },
  { id: "CL-772", time: "10:03", direction: "Outgoing", party: "Karim Mia — WK-1000", topic: "Called to HR office re: ID card re-issue", handledBy: "HR Officer", duration: "2 min", status: "Completed" },
  { id: "CL-773", time: "11:20", direction: "Incoming", party: "Bengal Lines (forwarder)", topic: "Container booking for 14 Oct shipment", handledBy: "Commercial", duration: "9 min", status: "Completed" },
  { id: "CL-774", time: "12:45", direction: "Missed", party: "Camille Perrot — Rivage Textile", topic: "Returned call pending — audit schedule", handledBy: "Merchandising", duration: "—", status: "Call back" },
  { id: "CL-775", time: "14:10", direction: "Outgoing", party: "Line 5 supervisor — SV-1005", topic: "Asked to report RT-77 knitting delay", handledBy: "Production Manager", duration: "4 min", status: "Completed" },
  { id: "CL-776", time: "15:32", direction: "Incoming", party: "SGS Bangladesh", topic: "Confirming AQL 2.5 inspection date for MF-42", handledBy: "Quality", duration: "5 min", status: "Completed" },
];

export const MESSAGES = [
  {
    id: "MSG-501",
    title: "Overtime roster posted for Line 1–4",
    body: "Please check the notice board or your app for this week's overtime schedule.",
    audience: "Worker",
    channel: "App + SMS",
    sentBy: "Production Manager",
    sentAt: "2026-08-20 18:05",
    delivered: 3820,
    total: 3960,
  },
  {
    id: "MSG-502",
    title: "Fire drill Thursday 10:00 AM",
    body: "Mandatory evacuation drill. Please assemble at the front yard within 5 minutes of the alarm.",
    audience: "All",
    channel: "App + SMS",
    sentBy: "Compliance Manager",
    sentAt: "2026-08-19 09:15",
    delivered: 4012,
    total: 4060,
  },
  {
    id: "MSG-503",
    title: "Salary disbursement — early September",
    body: "August salary will be paid on the 3rd working day of September via bKash/bank.",
    audience: "All",
    channel: "App only",
    sentBy: "HR Manager",
    sentAt: "2026-08-18 17:40",
    delivered: 3705,
    total: 4060,
  },
  {
    id: "MSG-504",
    title: "Line supervisors — meeting at 5 PM today",
    body: "Short meeting in the production office to review this week's efficiency numbers.",
    audience: "Supervisor",
    channel: "App only",
    sentBy: "Factory Manager",
    sentAt: "2026-08-24 13:00",
    delivered: 26,
    total: 28,
  },
];

export const MESSAGE_AUDIENCES = ["All", "Worker", "Staff", "Manager", "Supervisor", "Security", "Bua"];
export const MESSAGE_CHANNELS = ["App only", "SMS only", "App + SMS"];

export function communicationSummary() {
  const missed = CALL_LOG.filter((c) => c.status === "Call back").length;
  const todayCalls = CALL_LOG.length;
  const lastMessage = MESSAGES[MESSAGES.length - 1] || MESSAGES[0];
  const avgDeliveryPct =
    MESSAGES.reduce((a, m) => a + m.delivered / m.total, 0) / (MESSAGES.length || 1);
  return { missed, todayCalls, avgDeliveryPct, messageCount: MESSAGES.length };
}
