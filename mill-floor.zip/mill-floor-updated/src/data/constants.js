/* Shared vocabulary for the whole app — every dropdown, filter and
   generator reads from here so nothing drifts out of sync. */

export const DEPTS = ["Knitting", "Linking", "Finishing", "Packing", "Quality", "Cutting"];

export const SHIFTS = ["Morning", "General", "Night"];

export const LINES = ["Line 1", "Line 2", "Line 3", "Line 4", "Line 5", "Line 6"];

export const ATTENDANCE_STATUS = ["Present", "Late", "Absent", "On leave"];

export const BLOOD_GROUPS = ["A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"];

export const DISTRICTS = [
  "Gazipur", "Dhaka", "Narsingdi", "Mymensingh", "Tangail",
  "Kishoreganj", "Rangpur", "Barishal", "Jamalpur", "Netrokona",
];

export const EMPLOYMENT_TYPES = ["Permanent", "Probation", "Contract", "Seasonal"];

export const DESIGNATIONS = {
  Worker: ["Operator", "Senior Operator", "Linking Operator", "Trimmer", "Packer", "Iron Man"],
  Staff: ["Store Keeper", "Accounts Assistant", "HR Officer", "Merchandiser", "Data Entry"],
  Manager: ["Production Manager", "Factory Manager", "HR Manager", "Compliance Manager"],
  Security: ["Security Guard", "Gate Supervisor", "Fire Warden"],
  Supervisor: ["Line Supervisor", "Floor In-charge", "Quality Supervisor"],
  Bua: ["Cleaner", "Canteen Helper", "Floor Helper"],
};

export const ROLE_KEYS = ["worker", "staff", "manager", "security", "supervisor", "bua"];

export const ROLE_LABEL = {
  worker: "Worker",
  staff: "Staff",
  manager: "Manager",
  security: "Security",
  supervisor: "Supervisor",
  bua: "Bua",
};

export const ID_PREFIX = {
  worker: "WK",
  staff: "ST",
  manager: "MG",
  security: "SC",
  supervisor: "SV",
  bua: "BU",
};

/* Document types a BD garment factory actually files per employee —
   the "Others" bucket is there because there is always an others. */
export const DOC_KINDS = [
  "NID copy",
  "Passport photo",
  "Appointment letter",
  "Birth certificate",
  "Medical fitness",
  "Training record",
  "Bank / bKash details",
  "Previous experience",
  "Others",
];

export const LEAVE_TYPES = ["Casual", "Sick", "Earned", "Maternity", "Festival"];

/* Banking — used on the person form and the printed payslip. Not
   every worker has a bank account, so mobile financial services (MFS)
   are recorded as a fallback payout channel. */
export const BANKS = [
  "Dutch-Bangla Bank", "Islami Bank Bangladesh", "Sonali Bank", "BRAC Bank",
  "City Bank", "Pubali Bank", "Eastern Bank", "Mutual Trust Bank",
  "Agrani Bank", "NCC Bank",
];

export const MOBILE_BANKING_PROVIDERS = ["bKash", "Nagad", "Rocket", "Upay"];

/* English letterhead used on the printed payslip — the ID card keeps
   the Bangla name/address above, the payslip mirrors the paperwork
   HR already issues on the mill's own letterhead. */
export const FACTORY_NAME_EN = "Mill Floor Knitwear Ltd.";
export const FACTORY_ADDRESS_EN = "Baniarchala, Bhabanipur, Gazipur Sadar, Gazipur – 1740";
export const FACTORY_PHONE_EN = "+880 1711-000000";

export const MAX_DOC_MB = 8;

/* Bangla ID-card copy — factory identity, and the label/value maps the
   long-format worker ID badge reads from. Mirrors the wording on a real
   factory-issued পরিচয় পত্র (name, address, per-field labels) so the
   printed and on-screen card reads the way HR and the gate desk expect. */
export const FACTORY_NAME_BN = "মিল ফ্লোর নিটওয়্যার লিমিটেড";
export const FACTORY_ADDRESS_BN = "বানিয়ারচালা, ভবানীপুর, গাজীপুর সদর, গাজীপুর — ১৭৪০";

export const EMPLOYMENT_BN = {
  Permanent: "স্থায়ী",
  Probation: "শিক্ষানবিশ",
  Contract: "চুক্তিভিত্তিক",
  Seasonal: "মৌসুমী",
};

export const ID_CARD_LABELS_BN = {
  brand: "মিল ফ্লোর নিটওয়্যার লিমিটেড",
  brandSub: "পরিচয় পত্র",
  idNo: "আইডি কার্ড নং",
  name: "নাম",
  designation: "পদবী",
  bloodGroup: "রক্তের গ্রুপ",
  backTitle: "কর্মচারীর তথ্য",
  dept: "শাখা",
  line: "লাইন নং",
  shift: "কাজের ধরণ",
  employment: "শ্রমিকের ধরণ",
  joinDate: "যোগদানের তারিখ",
  mobile: "মোবাইল নং",
  nid: "জাতীয় পরিচয় পত্র নং",
  district: "স্থায়ী ঠিকানা",
  emergencyTitle: "জরুরী যোগাযোগ",
  emergencyName: "নাম",
  emergencyMobile: "জরুরী মোবাইল নং",
  qrScan: "স্ক্যান করুন · আইডি",
  ownership: "এই কার্ডটি কারখানার সম্পদ। কার্ডটি কেউ পেয়ে থাকলে HR অফিসে ফেরত দেওয়ার অনুরোধ রইল।",
  factoryAddress: "কারখানা ঠিকানা",
};

const BN_DIGIT = { "0": "০", "1": "১", "2": "২", "3": "৩", "4": "৪", "5": "৫", "6": "৬", "7": "৭", "8": "৮", "9": "৯" };

/** "2024-03-05" / "WK-1005" → Bangla digits, punctuation untouched. */
export function toBnDigits(input) {
  return String(input ?? "").replace(/[0-9]/g, (d) => BN_DIGIT[d]);
}

/** ISO date → দিন-মাস-বছর in Bangla digits, the order used on the card. */
export function bnDate(iso) {
  if (!iso) return "—";
  const [y, m, d] = String(iso).split("-");
  if (!y || !m || !d) return toBnDigits(iso);
  return toBnDigits(`${d}-${m}-${y}`);
}
