import {
  DEPTS, SHIFTS, LINES, BLOOD_GROUPS, DISTRICTS, DESIGNATIONS,
  ROLE_KEYS, ROLE_LABEL, ID_PREFIX, EMPLOYMENT_TYPES,
  BANKS, MOBILE_BANKING_PROVIDERS,
} from "./constants.js";

const FIRST = [
  "Karim", "Rahim", "Jamal", "Salma", "Nasrin", "Habib", "Rupa", "Anwar",
  "Momtaz", "Selina", "Faruk", "Rina", "Shahida", "Bellal", "Parvin",
  "Mizanur", "Jahanara", "Sumon", "Ruma", "Delwar",
];
const LAST = ["Mia", "Begum", "Islam", "Akter", "Hossain", "Khatun", "Ahmed", "Chowdhury", "Uddin", "Sultana"];
const STATUS_CYCLE = ["Present", "Present", "Present", "Present", "Late", "Present", "Absent", "Present", "On leave", "Present"];

/* A small deterministic PRNG: the demo has to look randomly staffed
   but produce the same factory on every reload, otherwise numbers on
   the dashboard jump around between renders. */
function seeded(n) {
  let x = (n * 9301 + 49297) % 233280;
  return () => {
    x = (x * 9301 + 49297) % 233280;
    return x / 233280;
  };
}

function pad(n) {
  return String(n).padStart(2, "0");
}

function punchTimes(status, r) {
  if (status === "Absent" || status === "On leave") return { punchIn: "--:--", punchOut: "--:--" };
  const late = status === "Late";
  const inH = late ? 8 : 7;
  const inM = late ? 20 + Math.floor(r() * 35) : 35 + Math.floor(r() * 24);
  const outH = 17 + (r() > 0.7 ? 1 : 0);
  const outM = Math.floor(r() * 59);
  return { punchIn: `${pad(inH)}:${pad(inM % 60)}`, punchOut: `${pad(outH)}:${pad(outM)}` };
}

function basicFor(roleKey, i) {
  const base = {
    worker: 8500, bua: 8200, security: 9500,
    supervisor: 16500, staff: 19000, manager: 48000,
  }[roleKey];
  return base + (i % 5) * (roleKey === "manager" ? 4000 : 700);
}

function makePerson(roleKey, i) {
  const r = seeded(i + 1 + roleKey.charCodeAt(0) * 31);
  const name = `${FIRST[(i * 3) % FIRST.length]} ${LAST[(i * 5) % LAST.length]}`;
  const status = STATUS_CYCLE[(i * 7) % STATUS_CYCLE.length];
  const { punchIn, punchOut } = punchTimes(status, r);
  const designations = DESIGNATIONS[ROLE_LABEL[roleKey]];
  const joinYear = 2016 + (i % 10);
  const mobileTail = String(10000000 + ((i * 987631 + roleKey.length * 7919) % 89999999)).slice(0, 8);

  // Roughly two in three have a bank account on file; the rest are
  // paid out through mobile financial services instead — both fields
  // are shown on the payslip, whichever is filled in.
  const hasBank = i % 3 !== 0;
  const bankName = hasBank ? BANKS[i % BANKS.length] : "";
  const bankAccount = hasBank
    ? String(1000000000 + ((i * 733921 + roleKey.length * 6151) % 8999999999)).slice(0, 10)
    : "";
  const mfsProvider = MOBILE_BANKING_PROVIDERS[i % MOBILE_BANKING_PROVIDERS.length];
  const mfsTail = String(10000000 + ((i * 654321 + roleKey.length * 313) % 89999999)).slice(0, 8);
  const mobileBanking = !hasBank ? `${mfsProvider}: 01${[3, 5, 6, 7, 8, 9][(i + 2) % 6]}${mfsTail}` : "";

  return {
    id: `${ID_PREFIX[roleKey]}-${1000 + i}`,
    roleKey,
    role: ROLE_LABEL[roleKey],
    name,
    designation: designations[i % designations.length],
    dept: DEPTS[i % DEPTS.length],
    line: roleKey === "worker" || roleKey === "supervisor" ? LINES[i % LINES.length] : "—",
    shift: SHIFTS[i % SHIFTS.length],
    employment: EMPLOYMENT_TYPES[i % EMPLOYMENT_TYPES.length],
    mobile: `01${[3, 5, 6, 7, 8, 9][i % 6]}${mobileTail}`,
    joinDate: `${joinYear}-${pad(1 + (i % 12))}-${pad(1 + ((i * 3) % 27))}`,
    nid: String(1990000000000 + i * 137 + roleKey.length * 11).slice(0, 13),
    bloodGroup: BLOOD_GROUPS[i % BLOOD_GROUPS.length],
    district: DISTRICTS[i % DISTRICTS.length],
    emergencyName: `${FIRST[(i * 11) % FIRST.length]} ${LAST[(i * 2) % LAST.length]}`,
    emergencyMobile: `018${String(70000000 + i * 4231).slice(0, 8)}`,
    bankName,
    bankAccount,
    mobileBanking,
    basic: basicFor(roleKey, i),
    status,
    punchIn,
    punchOut,
    documents: seedDocs(roleKey, i),
    notes: "",
    active: true,
    // No seeded headshot asset exists in this demo — the ID card and
    // avatar fall back to initials until someone uploads a real photo.
    photo: null,
  };
}

/* Pre-seeded paper trail. `seeded: true` marks records that came from
   the mock backend rather than a real browser upload, so the drawer can
   show them without a downloadable blob attached. */
function seedDocs(roleKey, i) {
  const base = [
    { kind: "NID copy", name: `nid-${ID_PREFIX[roleKey]}-${1000 + i}.pdf`, size: 240_000 + i * 1301 },
    { kind: "Passport photo", name: `photo-${ID_PREFIX[roleKey]}-${1000 + i}.jpg`, size: 88_000 + i * 431 },
  ];
  if (i % 3 === 0) base.push({ kind: "Appointment letter", name: `appointment-${1000 + i}.pdf`, size: 156_000 });
  if (i % 4 === 0) base.push({ kind: "Medical fitness", name: `medical-fitness-${1000 + i}.pdf`, size: 310_000 });
  if (i % 5 === 0) base.push({ kind: "Training record", name: `fire-safety-training-${1000 + i}.pdf`, size: 122_000 });
  return base.map((d, k) => ({
    ...d,
    id: `DOC-${ID_PREFIX[roleKey]}${1000 + i}-${k}`,
    uploadedAt: `${2019 + (i % 6)}-${pad(1 + ((i + k) % 12))}-${pad(1 + ((i * 2 + k) % 27))}`,
    uploadedBy: "admin.hr",
    seeded: true,
  }));
}

export const COUNTS = { worker: 46, staff: 18, manager: 8, security: 11, supervisor: 14, bua: 12 };

/** Flat list of every employee — the single source the store owns. */
export function makeAllPeople() {
  return ROLE_KEYS.flatMap((roleKey) =>
    Array.from({ length: COUNTS[roleKey] }, (_, i) => makePerson(roleKey, i))
  );
}

/** Next free ID for a role, e.g. "WK-1046". */
export function nextId(people, roleKey) {
  const prefix = ID_PREFIX[roleKey];
  const max = people
    .filter((p) => p.roleKey === roleKey)
    .reduce((m, p) => Math.max(m, Number(String(p.id).split("-")[1]) || 0), 999);
  return `${prefix}-${max + 1}`;
}

/** Blank record for the "add employee" form. */
export function emptyPerson(roleKey = "worker") {
  return {
    id: "",
    roleKey,
    role: ROLE_LABEL[roleKey],
    name: "",
    designation: DESIGNATIONS[ROLE_LABEL[roleKey]][0],
    dept: DEPTS[0],
    line: LINES[0],
    shift: "General",
    employment: "Probation",
    mobile: "",
    joinDate: new Date().toISOString().slice(0, 10),
    nid: "",
    bloodGroup: "",
    district: DISTRICTS[0],
    emergencyName: "",
    emergencyMobile: "",
    bankName: "",
    bankAccount: "",
    mobileBanking: "",
    basic: 8500,
    status: "Present",
    punchIn: "--:--",
    punchOut: "--:--",
    documents: [],
    notes: "",
    active: true,
    photo: null,
  };
}

export const WEEK_TREND = [
  { day: "Sat", present: 3690, target: 4000 },
  { day: "Sun", present: 3820, target: 4000 },
  { day: "Mon", present: 3910, target: 4000 },
  { day: "Tue", present: 3760, target: 4000 },
  { day: "Wed", present: 3880, target: 4000 },
  { day: "Thu", present: 3940, target: 4000 },
];

export const HEADCOUNT_TARGET = 4000;
