/* Office notice board. Mirrors the seeded-mock pattern used by
   data/people.js etc — deterministic, no backend. `audience` is a
   list of NAV/role keys the notice is relevant to; "all" always
   matches. `pinned` notices stay at the top of the board regardless
   of date. */

export const NOTICE_CATEGORIES = ["General", "HR", "Production", "Safety", "Holiday"];

export const NOTICES = [
  {
    id: "NTC-101",
    title: "Winter shipment overtime roster — Line 1 to Line 4",
    category: "Production",
    priority: "High",
    audience: ["worker", "supervisor"],
    body:
      "To meet the NordicKnit AB ex-factory date of 14 October, Line 1–4 will run an extended shift " +
      "(one hour overtime) from Sunday to Thursday for the next three weeks. Overtime is paid at the " +
      "usual 2x hourly rate. Line supervisors will post the daily roster on each floor notice board.",
    postedBy: "Production Manager",
    postedAt: "2026-08-20",
    pinned: true,
  },
  {
    id: "NTC-102",
    title: "Fire drill — all floors, Thursday 10:00 AM",
    category: "Safety",
    priority: "High",
    audience: ["all"],
    body:
      "A factory-wide fire evacuation drill will be held this Thursday at 10:00 AM. All workers, staff " +
      "and visitors must exit via the marked stairwells to the assembly point in the front yard within " +
      "5 minutes of the alarm. Security will record attendance at the assembly point.",
    postedBy: "Compliance Manager",
    postedAt: "2026-08-19",
    pinned: true,
  },
  {
    id: "NTC-103",
    title: "August salary disbursement date",
    category: "HR",
    priority: "Normal",
    audience: ["all"],
    body:
      "August salary will be disbursed on the 3rd working day of September through the usual bKash " +
      "and bank channels. Anyone with a mobile number or bank account change should update it with " +
      "the HR office by 30 August to avoid a delay.",
    postedBy: "HR Manager",
    postedAt: "2026-08-18",
    pinned: false,
  },
  {
    id: "NTC-104",
    title: "New ID card re-issue for Linking section",
    category: "General",
    priority: "Normal",
    audience: ["worker", "security"],
    body:
      "Linking section ID cards issued before 2022 are being reprinted with the updated biometric chip. " +
      "Affected workers should visit the HR office between 2–4 PM this week with their old card for a " +
      "same-day replacement. The gate will accept the old card until 31 August only.",
    postedBy: "HR Officer",
    postedAt: "2026-08-17",
    pinned: false,
  },
  {
    id: "NTC-105",
    title: "Buyer audit — Rivage Textile, 28 August",
    category: "Production",
    priority: "High",
    audience: ["manager", "supervisor", "staff"],
    body:
      "Rivage Textile's compliance auditor will visit Unit 2 on 28 August for the chunky roll-neck order " +
      "(style RT-77). Please ensure the store, quality lab and finishing floor documentation are ready " +
      "for review a day in advance. Merchandising will circulate the audit checklist separately.",
    postedBy: "Merchandiser",
    postedAt: "2026-08-15",
    pinned: false,
  },
  {
    id: "NTC-106",
    title: "Eid-ul-Adha holiday schedule (advance notice)",
    category: "Holiday",
    priority: "Normal",
    audience: ["all"],
    body:
      "The factory will remain closed for Eid-ul-Adha; exact dates will follow the government gazette " +
      "once published and will be confirmed here at least two weeks in advance. Please plan travel " +
      "bookings only after the confirmed notice is posted.",
    postedBy: "Admin",
    postedAt: "2026-08-10",
    pinned: false,
  },
];
