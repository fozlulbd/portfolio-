import React, { useMemo, useState } from "react";
import { Megaphone, Pin, Printer, Plus, CheckCircle2 } from "../icons.js";
import { C, F } from "../theme/tokens.js";
import { can } from "../auth/roles.js";
import { NOTICES, NOTICE_CATEGORIES } from "../data/notices.js";
import { printNotice } from "../lib/print.js";
import Card from "../components/ui/Card.jsx";
import Stitch from "../components/ui/Stitch.jsx";
import Button, { IconButton } from "../components/ui/Button.jsx";
import { Badge } from "../components/ui/StatusPill.jsx";
import EmptyState from "../components/ui/EmptyState.jsx";
import Modal from "../components/ui/Modal.jsx";
import { Field, Input, Select, Textarea } from "../components/ui/Field.jsx";

const PRIORITY_TONE = { High: C.red, Normal: C.gold };

/* A pinned notice reads as pushed onto a board rather than sitting in
   a table row — the double gold frame and small alternating tilt are
   the page's one signature move; everything else stays quiet. */
function NoticeCard({ notice, unread, onMarkRead, onPrint, tilt }) {
  return (
    <Card
      style={{
        border: `1px solid ${C.line}`,
        outline: notice.pinned ? `1px solid ${C.gold}` : "none",
        outlineOffset: notice.pinned ? 3 : 0,
        transform: notice.pinned ? `rotate(${tilt}deg)` : "none",
        padding: "18px 20px",
        position: "relative",
      }}
      className="animate-fade-in"
    >
      {notice.pinned && (
        <div
          style={{ color: C.gold, background: C.bg, border: `1px solid ${C.gold}` }}
          className="absolute -top-3 left-4 w-6 h-6 rounded-full flex items-center justify-center"
          aria-hidden="true"
        >
          <Pin size={12} strokeWidth={2.5} />
        </div>
      )}

      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-2 flex-wrap">
          <Badge tone={PRIORITY_TONE[notice.priority] || C.muted} mono={false}>
            {notice.priority} priority
          </Badge>
          <Badge mono={false}>{notice.category}</Badge>
          {unread && (
            <span style={{ background: C.gold }} className="w-1.5 h-1.5 rounded-full" aria-label="Unread" />
          )}
        </div>
        <div className="flex items-center gap-1.5">
          <IconButton icon={Printer} label="Print this notice" size={30} onClick={() => onPrint(notice)} />
        </div>
      </div>

      <h3 style={{ fontFamily: F.display, color: C.text }} className="text-base font-semibold mt-3">
        {notice.title}
      </h3>
      <p style={{ color: C.muted }} className="text-[11px] mt-1">
        {notice.postedBy} · {notice.postedAt}
      </p>

      <Stitch style={{ margin: "12px 0" }} />

      <p style={{ color: C.text }} className="text-sm leading-relaxed">
        {notice.body}
      </p>

      {unread && (
        <button
          type="button"
          onClick={() => onMarkRead(notice.id)}
          style={{ color: C.gold }}
          className="text-xs mt-3 inline-flex items-center gap-1.5 hover:opacity-80"
        >
          <CheckCircle2 size={13} /> Mark as read
        </button>
      )}
    </Card>
  );
}

function NoticeForm({ open, onClose, onSave }) {
  const [draft, setDraft] = useState({ title: "", category: "General", priority: "Normal", body: "" });

  function set(key, value) {
    setDraft((d) => ({ ...d, [key]: value }));
  }

  function submit() {
    if (!draft.title.trim() || !draft.body.trim()) return;
    onSave(draft);
    setDraft({ title: "", category: "General", priority: "Normal", body: "" });
    onClose();
  }

  return (
    <Modal open={open} onClose={onClose} title="Post a new notice" subtitle="Visible on the board immediately.">
      <div className="px-5 py-4 space-y-4">
        <Field label="Title" required>
          <Input value={draft.title} onChange={(e) => set("title", e.target.value)} placeholder="e.g. Line 3 machine maintenance, Sunday" />
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Category">
            <Select value={draft.category} onChange={(e) => set("category", e.target.value)} options={NOTICE_CATEGORIES} />
          </Field>
          <Field label="Priority">
            <Select value={draft.priority} onChange={(e) => set("priority", e.target.value)} options={["Normal", "High"]} />
          </Field>
        </div>
        <Field label="Notice text" required>
          <Textarea rows={5} value={draft.body} onChange={(e) => set("body", e.target.value)} placeholder="Write the full notice as it should appear on the board…" />
        </Field>
      </div>
      <Stitch />
      <div className="px-5 py-4 flex items-center justify-end gap-2">
        <Button variant="outline" onClick={onClose}>Cancel</Button>
        <Button variant="primary" icon={Megaphone} onClick={submit}>Post notice</Button>
      </div>
    </Modal>
  );
}

export default function NoticeBoardPage({ authRole }) {
  const [extra, setExtra] = useState([]); // session-posted notices, newest first
  const [read, setRead] = useState(() => new Set());
  const [category, setCategory] = useState("");
  const [formOpen, setFormOpen] = useState(false);

  const all = useMemo(() => [...extra, ...NOTICES], [extra]);

  const visible = useMemo(() => {
    const filtered = category ? all.filter((n) => n.category === category) : all;
    return [...filtered].sort((a, b) => (b.pinned === a.pinned ? 0 : b.pinned ? 1 : -1));
  }, [all, category]);

  const unreadCount = all.filter((n) => !read.has(n.id)).length;

  function markRead(id) {
    setRead((prev) => new Set(prev).add(id));
  }

  function markAllRead() {
    setRead(new Set(all.map((n) => n.id)));
  }

  function postNotice(draft) {
    const id = `NTC-${900 + extra.length + 1}`;
    setExtra((prev) => [
      {
        id,
        ...draft,
        audience: ["all"],
        postedBy: authRole?.label || "Admin",
        postedAt: new Date().toISOString().slice(0, 10),
        pinned: draft.priority === "High",
      },
      ...prev,
    ]);
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={() => setCategory("")}
            style={{
              background: category === "" ? C.goldDim : "transparent",
              color: category === "" ? C.gold : C.muted,
              border: `1px solid ${category === "" ? C.gold : C.line}`,
            }}
            className="px-3 py-1.5 rounded-full text-xs font-medium"
          >
            All ({all.length})
          </button>
          {NOTICE_CATEGORIES.map((c) => (
            <button
              key={c}
              type="button"
              onClick={() => setCategory(c)}
              style={{
                background: category === c ? C.goldDim : "transparent",
                color: category === c ? C.gold : C.muted,
                border: `1px solid ${category === c ? C.gold : C.line}`,
              }}
              className="px-3 py-1.5 rounded-full text-xs font-medium"
            >
              {c}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          {unreadCount > 0 && (
            <Button variant="outline" onClick={markAllRead}>
              Mark all read ({unreadCount})
            </Button>
          )}
          {can(authRole, "create") && (
            <Button variant="primary" icon={Plus} onClick={() => setFormOpen(true)}>
              Post notice
            </Button>
          )}
        </div>
      </div>

      {visible.length === 0 ? (
        <EmptyState icon={Megaphone} title="No notices in this category" message="Try a different category or view all notices." />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pt-2">
          {visible.map((n, i) => (
            <NoticeCard
              key={n.id}
              notice={n}
              unread={!read.has(n.id)}
              onMarkRead={markRead}
              onPrint={printNotice}
              tilt={i % 2 === 0 ? -0.6 : 0.6}
            />
          ))}
        </div>
      )}

      <NoticeForm open={formOpen} onClose={() => setFormOpen(false)} onSave={postNotice} />
    </div>
  );
}
