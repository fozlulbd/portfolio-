import React from "react";
import {
  ResponsiveContainer, ComposedChart, Bar, Line, XAxis, YAxis, Tooltip,
  CartesianGrid, Cell,
} from "recharts";
import { BadgeCheck, PackageX, Percent, ClipboardCheck } from "../icons.js";
import { C, F } from "../theme/tokens.js";
import { usePalette } from "../theme/ThemeProvider.jsx";
import { DEFECTS, INSPECTIONS, paretoData, qualitySummary } from "../data/quality.js";
import { num, pct } from "../lib/format.js";
import { can } from "../auth/roles.js";
import { useFakeLoad } from "../hooks/dom.js";
import Card, { CardHeader } from "../components/ui/Card.jsx";
import KpiCard from "../components/ui/KpiCard.jsx";
import DataTable from "../components/DataTable.jsx";
import StatusPill from "../components/ui/StatusPill.jsx";
import Meter from "../components/ui/Meter.jsx";
import { CardsSkeleton, ChartSkeleton } from "../components/ui/Skeleton.jsx";

/* ---------------------------------------------------------------
   QUALITY — a Pareto is the right chart here: the cumulative line
   shows how few defect types account for most rejections, which is
   what a floor meeting actually needs to decide where to intervene.
----------------------------------------------------------------*/
export default function QualityPage({ authRole }) {
  const palette = usePalette();
  const loading = useFakeLoad(460, []);
  const pareto = paretoData(DEFECTS);
  const s = qualitySummary();
  const vital = pareto.filter((d) => d.cumulative <= 80).length || 1;

  const columns = [
    { key: "id", label: "Lot", mono: true, width: 96 },
    { key: "line", label: "Line", mono: true },
    { key: "styleNo", label: "Style", mono: true },
    { key: "aql", label: "AQL", mono: true, align: "right", hideBelow: "lg", width: 68 },
    { key: "checked", label: "Checked", mono: true, align: "right", render: (r) => num(r.checked) },
    {
      key: "rejected",
      label: "Rejected",
      mono: true,
      align: "right",
      render: (r) => <span style={{ color: C.red }}>{num(r.rejected)}</span>,
    },
    {
      key: "dhu",
      label: "DHU",
      mono: true,
      align: "right",
      hideBelow: "md",
      render: (r) => `${((r.rejected / r.checked) * 100).toFixed(2)}%`,
    },
    {
      key: "passRate",
      label: "Pass rate",
      sortable: false,
      csv: false,
      width: 160,
      render: (r) => {
        const rate = (r.checked - r.rejected) / r.checked;
        return <Meter value={rate} good={0.98} warn={0.97} right={pct(rate, 2)} />;
      },
    },
    { key: "result", label: "Result", render: (r) => <StatusPill status={r.result} /> },
  ];

  const rows = INSPECTIONS.map((r) => ({
    ...r,
    dhu: Number(((r.rejected / r.checked) * 100).toFixed(2)),
  }));

  if (loading) {
    return (
      <div className="space-y-5">
        <CardsSkeleton />
        <Card style={{ padding: 20 }}>
          <ChartSkeleton height={260} />
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <KpiCard label="Pieces inspected" value={num(s.checked)} sub="today, all lines" icon={ClipboardCheck} />
        <KpiCard
          label="Pass rate"
          value={pct(s.passRate, 2)}
          sub="first-pass, before rework"
          icon={BadgeCheck}
          tone={s.passRate >= 0.98 ? C.green : C.amber}
          delta={0.004}
        />
        <KpiCard
          label="DHU"
          value={`${s.dhu.toFixed(2)}%`}
          sub="defects per hundred units"
          icon={Percent}
          tone={C.amber}
          delta={-0.031}
          goodDirection="down"
        />
        <KpiCard
          label="Lots failed AQL"
          value={num(s.failedLots)}
          sub={`of ${INSPECTIONS.length} offered`}
          icon={PackageX}
          tone={C.red}
        />
      </div>

      <Card>
        <CardHeader
          title="Defect Pareto — today"
          subtitle={`${vital} defect type${vital > 1 ? "s" : ""} account for the first 80% of rejections`}
          icon={BadgeCheck}
        />
        <div style={{ height: 280, padding: "16px 8px 4px" }}>
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={pareto} margin={{ top: 6, right: 8, left: -22, bottom: 44 }}>
              <CartesianGrid stroke={palette.line} vertical={false} />
              <XAxis
                dataKey="defect"
                stroke={palette.muted}
                fontSize={10}
                tickLine={false}
                axisLine={{ stroke: palette.line }}
                angle={-28}
                textAnchor="end"
                interval={0}
                height={54}
              />
              <YAxis yAxisId="left" stroke={palette.muted} fontSize={11} tickLine={false} axisLine={false} />
              <YAxis
                yAxisId="right"
                orientation="right"
                stroke={palette.muted}
                fontSize={11}
                tickLine={false}
                axisLine={false}
                domain={[0, 100]}
                unit="%"
              />
              <Tooltip
                contentStyle={{
                  background: palette.panelAlt,
                  border: `1px solid ${palette.line}`,
                  borderRadius: 8,
                  fontSize: 12,
                  color: palette.text,
                }}
                formatter={(v, k) => (k === "cumulative" ? [`${v}%`, "Cumulative"] : [num(v), "Defects"])}
              />
              <Bar yAxisId="left" dataKey="count" radius={[3, 3, 0, 0]} maxBarSize={44}>
                {pareto.map((d) => (
                  <Cell key={d.defect} fill={d.cumulative <= 80 ? palette.red : palette.line} />
                ))}
              </Bar>
              <Line
                yAxisId="right"
                type="monotone"
                dataKey="cumulative"
                stroke={palette.gold}
                strokeWidth={2}
                dot={{ r: 2.5, fill: palette.gold }}
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </Card>

      <DataTable
        title="Inspection lots"
        subtitle="AQL 2.5 sampling, offered by line"
        icon={ClipboardCheck}
        columns={columns}
        rows={rows}
        searchKeys={["id", "line", "styleNo", "result"]}
        filterKeys={[
          { key: "result", label: "Result" },
          { key: "styleNo", label: "Style" },
        ]}
        exportName="inspection-lots"
        canExport={can(authRole, "export")}
        initialSort={{ key: "dhu", dir: "desc" }}
      />

      <Card>
        <CardHeader title="Where the defects come from" subtitle="Grouped by process" />
        <div className="px-5 py-4 grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-3">
          {["Knitting", "Linking", "Finishing", "Packing"].map((proc) => {
            const inProc = DEFECTS.filter((d) => d.process === proc);
            const count = inProc.reduce((a, d) => a + d.count, 0);
            const total = DEFECTS.reduce((a, d) => a + d.count, 0);
            return (
              <div key={proc}>
                <Meter
                  value={count / total}
                  good={0}
                  warn={0}
                  tone={C.gold}
                  label={proc}
                  right={`${count} · ${pct(count / total, 0)}`}
                />
                <p style={{ color: C.muted, fontFamily: F.mono }} className="text-[10px] mt-1">
                  {inProc.map((d) => d.defect).join(" · ")}
                </p>
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
}
