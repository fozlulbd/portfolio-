import React, { useMemo, useState } from "react";
import { IdCard, Printer, Search, X, UserPlus, LayoutGrid } from "../icons.js";
import { C } from "../theme/tokens.js";
import { ROLE_KEYS, ROLE_LABEL } from "../data/constants.js";
import { useStore } from "../store/AppStore.jsx";
import { can } from "../auth/roles.js";
import { printIdCard, printIdSheet, printRows, printPayslips } from "../lib/print.js";
import { computeSalary, mockMonthInputs } from "../lib/payroll.js";
import Card from "../components/ui/Card.jsx";
import Button, { IconButton } from "../components/ui/Button.jsx";
import EmptyState from "../components/ui/EmptyState.jsx";
import { FilterSelect } from "../components/ui/Field.jsx";
import IdCardBadge from "../components/people/IdCardBadge.jsx";

function BadgeTile({ person, onOpen }) {
  return (
    <Card style={{ padding: 0, overflow: "hidden" }} hover className="flex flex-col">
      <div
        role="button"
        tabIndex={0}
        onClick={() => onOpen(person)}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") onOpen(person);
        }}
        className="cursor-pointer pt-3"
      >
        <IdCardBadge person={person} />
      </div>
      <div style={{ borderTop: `1px solid ${C.line}` }} className="px-3 py-2 flex items-center justify-between mt-auto">
        <button type="button" onClick={() => onOpen(person)} style={{ color: C.muted }} className="text-[10px] hover:underline">
          Tap card for full record
        </button>
        <IconButton icon={Printer} label={`Print ID card for ${person.name}`} size={28} onClick={() => printIdCard(person)} />
      </div>
    </Card>
  );
}

export default function IdCardPage({ authRole, onOpenPerson, onAdd }) {
  const { people } = useStore();
  const [query, setQuery] = useState("");
  const [role, setRole] = useState("");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return people.filter((p) => {
      if (role && p.roleKey !== role) return false;
      if (!q) return true;
      return (
        p.name.toLowerCase().includes(q) ||
        p.id.toLowerCase().includes(q) ||
        (p.mobile || "").includes(q) ||
        (p.nid || "").includes(q)
      );
    });
  }, [people, query, role]);

  function printAll() {
    printRows(
      filtered,
      [
        { key: "id", label: "ID" },
        { key: "name", label: "Name" },
        { key: "role", label: "Role" },
        { key: "dept", label: "Department" },
        { key: "bloodGroup", label: "Blood group" },
        { key: "mobile", label: "Mobile" },
      ],
      "ID card register"
    );
  }

  return (
    <div className="space-y-5">
      <Card style={{ padding: "14px 18px" }} className="flex items-center gap-3 flex-wrap justify-between">
        <div className="flex items-center gap-2.5 flex-wrap">
          <div style={{ background: C.panelAlt, border: `1px solid ${query ? C.gold : C.line}` }} className="flex items-center gap-2 px-3 py-2 rounded-md">
            <Search size={14} style={{ color: query ? C.gold : C.muted }} />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search ID, name, mobile, NID…"
              style={{ background: "transparent", color: C.text }}
              className="text-xs outline-none w-44"
            />
            {query && (
              <button type="button" onClick={() => setQuery("")} aria-label="Clear search">
                <X size={12} style={{ color: C.muted }} />
              </button>
            )}
          </div>
          <FilterSelect
            label="Role"
            value={role}
            onChange={setRole}
            options={ROLE_KEYS.map((k) => ROLE_LABEL[k])}
          />
          {role && (
            <button type="button" onClick={() => setRole("")} style={{ color: C.muted }} className="text-xs underline">
              Clear
            </button>
          )}
        </div>
        <div className="flex items-center gap-2">
          <span style={{ color: C.muted }} className="text-xs">{filtered.length} cards</span>
          <Button variant="outline" icon={Printer} onClick={printAll}>Print list</Button>
          <Button variant="outline" icon={LayoutGrid} onClick={() => printIdSheet(filtered)}>Print A4 sheet</Button>
          <Button
            variant="outline"
            icon={Printer}
            onClick={() =>
              printPayslips(filtered.map((p) => ({ person: p, pay: computeSalary(p, mockMonthInputs(p)) })))
            }
          >
            Print payslips
          </Button>
          {can(authRole, "create") && (
            <Button variant="primary" icon={UserPlus} onClick={() => onAdd("worker")}>Add employee</Button>
          )}
        </div>
      </Card>

      {filtered.length === 0 ? (
        <EmptyState icon={IdCard} title="No matching ID cards" message="Try a different search term or clear the role filter." />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filtered.map((p) => (
            <BadgeTile key={p.id} person={p} onOpen={onOpenPerson} />
          ))}
        </div>
      )}
    </div>
  );
}
