import React from "react";
import { ShieldAlert } from "../icons.js";
import { C, F } from "../theme/tokens.js";
import Card from "../components/ui/Card.jsx";
import EmptyState from "../components/ui/EmptyState.jsx";

/** Shown if a role somehow lands on a page it cannot see. */
export default function NoAccessPage({ authRole, onHome }) {
  return (
    <Card>
      <EmptyState
        icon={ShieldAlert}
        title="This screen is not part of your access"
        message={`You are signed in as ${authRole?.label || "a limited role"}. Ask the admin to widen your role if you need this module.`}
        actionLabel="Back to your home screen"
        onAction={onHome}
      />
      <p style={{ color: C.muted, fontFamily: F.mono }} className="text-[11px] text-center pb-6">
        Permissions live in src/auth/roles.js
      </p>
    </Card>
  );
}
