import React, { useMemo, useState } from "react";
import {
  UserPlus, CheckCircle2, XCircle, Trash2, Paperclip, Users,
} from "../icons.js";
import { C, F } from "../theme/tokens.js";
import { ROLE_LABEL } from "../data/constants.js";
import { formatMobile, prettyDate, taka, tenure } from "../lib/format.js";
import { can } from "../auth/roles.js";
import { useStore } from "../store/AppStore.jsx";
import { useFakeLoad } from "../hooks/dom.js";
import DataTable from "../components/DataTable.jsx";
import Avatar from "../components/ui/Avatar.jsx";
import StatusPill from "../components/ui/StatusPill.jsx";
import Button from "../components/ui/Button.jsx";
import { ConfirmModal } from "../components/ui/Modal.jsx";

/* ---------------------------------------------------------------
   PEOPLE — one directory page reused for all six role types. What a
   user can do here comes from their permissions: a supervisor gets
   the same table with the write actions absent, not disabled-looking.
----------------------------------------------------------------*/
export default function PeoplePage({ roleKey, authRole, onOpenPerson, onAdd }) {
  const { peopleOf, setStatus, removePeople } = useStore();
  const rows = peopleOf(roleKey);
  const loading = useFakeLoad(420, [roleKey]);
  const [pendingDelete, setPendingDelete] = useState(null);

  const canEdit = can(authRole, "edit");
  const canDelete = can(authRole, "delete");
  const canCreate = can(authRole, "create");
  const seeSalary = can(authRole, "seeSalary");

  const columns = useMemo(
    () => [
      { key: "id", label: "ID", mono: true, width: 96 },
      {
        key: "name",
        label: "Name",
        render: (r) => (
          <div className="flex items-center gap-2.5">
            <Avatar name={r.name} size="sm" src={r.photo} />
            <div className="min-w-0">
              <span style={{ color: C.text }} className="block truncate">
                {r.name}
              </span>
              <span style={{ color: C.muted }} className="text-[11px] block truncate">
                {r.designation}
              </span>
            </div>
          </div>
        ),
      },
      { key: "dept", label: "Department" },
      { key: "line", label: "Line", hideBelow: "lg" },
      { key: "shift", label: "Shift", hideBelow: "md" },
      {
        key: "mobile",
        label: "Mobile",
        mono: true,
        hideBelow: "md",
        render: (r) => formatMobile(r.mobile),
      },
      {
        key: "joinDate",
        label: "Joined",
        mono: true,
        hideBelow: "lg",
        render: (r) => (
          <span title={`${tenure(r.joinDate)} of service`}>{prettyDate(r.joinDate)}</span>
        ),
      },
      ...(seeSalary
        ? [{
            key: "basic",
            label: "Basic",
            mono: true,
            align: "right",
            hideBelow: "lg",
            render: (r) => taka(r.basic),
          }]
        : []),
      {
        key: "documents",
        label: "Docs",
        align: "right",
        sortable: false,
        csv: false,
        width: 64,
        render: (r) => (
          <span
            style={{ color: r.documents.length ? C.gold : C.muted, fontFamily: F.mono }}
            className="inline-flex items-center gap-1 text-xs"
            title={`${r.documents.length} document(s) on file`}
          >
            <Paperclip size={11} />
            {r.documents.length}
          </span>
        ),
      },
      { key: "punchIn", label: "In", mono: true, hideBelow: "md", width: 72 },
      { key: "punchOut", label: "Out", mono: true, hideBelow: "lg", width: 78 },
      {
        key: "status",
        label: "Status",
        render: (r) => <StatusPill status={r.status} />,
      },
    ],
    [seeSalary]
  );

  const bulkActions = [
    ...(canEdit
      ? [
          { label: "Mark present", icon: CheckCircle2, onRun: (ids) => setStatus(ids, "Present") },
          { label: "Mark absent", icon: XCircle, onRun: (ids) => setStatus(ids, "Absent") },
        ]
      : []),
    ...(canDelete
      ? [{ label: "Delete", icon: Trash2, tone: "danger", onRun: (ids) => setPendingDelete(ids), clearAfter: false }]
      : []),
  ];

  return (
    <>
      <DataTable
        title={`${ROLE_LABEL[roleKey]} directory`}
        icon={Users}
        columns={columns}
        rows={rows}
        loading={loading}
        searchKeys={["id", "name", "dept", "designation", "mobile", "line", "nid", "district"]}
        filterKeys={[
          { key: "dept", label: "Dept" },
          { key: "shift", label: "Shift" },
          { key: "status", label: "Status" },
          { key: "line", label: "Line" },
          { key: "employment", label: "Type" },
        ]}
        selectable={bulkActions.length > 0}
        bulkActions={bulkActions}
        onRowClick={onOpenPerson}
        exportName={`${roleKey}-directory`}
        canExport={can(authRole, "export")}
        initialSort={{ key: "id", dir: "asc" }}
        emptyTitle={`No ${ROLE_LABEL[roleKey].toLowerCase()} records match`}
        toolbarRight={
          canCreate ? (
            <Button variant="primary" icon={UserPlus} onClick={() => onAdd(roleKey)}>
              Add {ROLE_LABEL[roleKey].toLowerCase()}
            </Button>
          ) : null
        }
      />

      <ConfirmModal
        open={Boolean(pendingDelete)}
        onClose={() => setPendingDelete(null)}
        onConfirm={() => removePeople(pendingDelete)}
        title="Delete employee records?"
        confirmLabel={`Delete ${pendingDelete?.length || 0}`}
        message={`This removes ${pendingDelete?.length || 0} record${
          pendingDelete?.length === 1 ? "" : "s"
        } along with any attached documents. In this demo the change lasts until you reload the page.`}
      />
    </>
  );
}
