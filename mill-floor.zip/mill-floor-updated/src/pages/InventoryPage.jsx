import React, { useState } from "react";
import { Boxes, PackageX, AlertTriangle, PackageCheck, Warehouse, ShoppingCart, Tags, TrendingUp, TrendingDown } from "../icons.js";
import { C, F } from "../theme/tokens.js";
import { STOCK, stockState, stockSummary, PURCHASES, SALES, costSummary } from "../data/inventory.js";
import { num, taka, prettyDate } from "../lib/format.js";
import { can } from "../auth/roles.js";
import { useFakeLoad } from "../hooks/dom.js";
import Card, { CardHeader } from "../components/ui/Card.jsx";
import KpiCard from "../components/ui/KpiCard.jsx";
import DataTable from "../components/DataTable.jsx";
import StatusPill, { Badge } from "../components/ui/StatusPill.jsx";
import Meter from "../components/ui/Meter.jsx";
import Tabs from "../components/ui/Tabs.jsx";
import { CardsSkeleton, TableSkeleton } from "../components/ui/Skeleton.jsx";

/* ---------------------------------------------------------------
   YARN & STORE — the coverage meter compares stock against the
   reorder level rather than an absolute quantity, so 410 kg of ecru
   reads as a problem while 640 cones of thread does not.
----------------------------------------------------------------*/
export default function InventoryPage({ authRole }) {
  const loading = useFakeLoad(440, []);
  const [tab, setTab] = useState("stock");
  const s = stockSummary();
  const rows = STOCK.map((r) => ({ ...r, state: stockState(r) }));
  const alerts = rows.filter((r) => r.state !== "In stock");
  const cost = costSummary();

  const columns = [
    { key: "id", label: "Code", mono: true, width: 96 },
    {
      key: "item",
      label: "Item",
      render: (r) => (
        <div className="min-w-0">
          <span style={{ color: C.text }} className="block truncate">
            {r.item}
          </span>
          <span style={{ color: C.muted, fontFamily: F.mono }} className="text-[10px] block truncate">
            {r.lot} · {r.location}
          </span>
        </div>
      ),
    },
    { key: "category", label: "Category", hideBelow: "md" },
    { key: "buyer", label: "Reserved for", hideBelow: "lg" },
    {
      key: "inStock",
      label: "In stock",
      mono: true,
      align: "right",
      render: (r) => `${num(r.inStock)} ${r.unit}`,
    },
    {
      key: "reorder",
      label: "Reorder at",
      mono: true,
      align: "right",
      hideBelow: "md",
      render: (r) => num(r.reorder),
    },
    {
      key: "coverage",
      label: "Coverage",
      sortable: false,
      csv: false,
      width: 150,
      render: (r) => {
        const ratio = r.reorder ? r.inStock / (r.reorder * 2) : 1;
        return <Meter value={ratio} good={0.75} warn={0.5} right={`${Math.round(ratio * 100)}%`} />;
      },
    },
    { key: "state", label: "Status", render: (r) => <StatusPill status={r.state} /> },
  ];

  if (loading) {
    return (
      <div className="space-y-5">
        <CardsSkeleton />
        <Card>
          <TableSkeleton rows={6} cols={5} />
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <Tabs
        value={tab}
        onChange={setTab}
        tabs={[
          { key: "stock", label: "Stock register" },
          { key: "buysell", label: "Buy / Sell" },
        ]}
      />

      {tab === "stock" ? (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
            <KpiCard label="Stock lines" value={num(s.lines)} sub="yarn, trims and packing" icon={Boxes} />
            <KpiCard label="Healthy" value={num(s.healthy)} sub="above reorder level" icon={PackageCheck} tone={C.green} />
            <KpiCard label="At reorder" value={num(s.reorder)} sub="raise a requisition" icon={AlertTriangle} tone={C.amber} />
            <KpiCard label="Out of stock" value={num(s.out)} sub="production blocked" icon={PackageX} tone={C.red} />
          </div>

          {alerts.length > 0 && (
            <Card style={{ borderColor: C.amber }}>
              <CardHeader
                title="Needs a requisition today"
                subtitle={`${alerts.length} line${alerts.length > 1 ? "s" : ""} at or below reorder level`}
                icon={AlertTriangle}
              />
              <ul className="px-5 py-4 space-y-3">
                {alerts.map((a) => (
                  <li key={a.id} className="flex items-start justify-between gap-3 flex-wrap">
                    <div className="min-w-0">
                      <p style={{ color: C.text }} className="text-sm">
                        {a.item}
                      </p>
                      <p style={{ color: C.muted, fontFamily: F.mono }} className="text-[11px] mt-0.5">
                        {num(a.inStock)} {a.unit} on hand · reorder at {num(a.reorder)} · for {a.buyer}
                      </p>
                    </div>
                    <StatusPill status={a.state} />
                  </li>
                ))}
              </ul>
            </Card>
          )}

          <DataTable
            title="Store register"
            subtitle="Yarn, trims and packing materials across three stores"
            icon={Warehouse}
            columns={columns}
            rows={rows}
            searchKeys={["id", "item", "category", "buyer", "lot", "location"]}
            filterKeys={[
              { key: "category", label: "Category" },
              { key: "state", label: "Status" },
              { key: "buyer", label: "Buyer" },
            ]}
            exportName="store-register"
            canExport={can(authRole, "export")}
            initialSort={{ key: "inStock", dir: "asc" }}
          />
        </>
      ) : (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
            <KpiCard label="Total purchase cost" value={taka(cost.totalPurchase)} sub={`${PURCHASES.length} purchase bills`} icon={ShoppingCart} />
            <KpiCard label="Total sales value" value={taka(cost.totalSales)} sub={`${SALES.length} sale entries`} icon={Tags} tone={C.green} />
            <KpiCard label="Surplus stock sold" value={taka(cost.surplusValue)} sub={`${cost.surplusCount} local sale${cost.surplusCount === 1 ? "" : "s"}`} icon={TrendingUp} tone={C.gold} />
            <KpiCard
              label="Net position"
              value={taka(Math.abs(cost.netPosition))}
              sub={cost.netPosition >= 0 ? "sales ahead of purchase" : "purchase ahead of sales"}
              icon={cost.netPosition >= 0 ? TrendingUp : TrendingDown}
              tone={cost.netPosition >= 0 ? C.green : C.red}
            />
          </div>

          <DataTable
            title="Purchases"
            subtitle="Material bought into the store against a supplier bill"
            icon={ShoppingCart}
            columns={[
              { key: "id", label: "Ref", mono: true, width: 90 },
              { key: "item", label: "Item" },
              { key: "qty", label: "Qty", mono: true, align: "right", render: (r) => `${num(r.qty)} ${r.unit}` },
              { key: "unitCost", label: "Unit cost", mono: true, align: "right", render: (r) => taka(r.unitCost) },
              { key: "total", label: "Total", mono: true, align: "right", render: (r) => taka(r.qty * r.unitCost), csv: false },
              { key: "supplier", label: "Supplier", hideBelow: "md" },
              { key: "invoice", label: "Invoice", mono: true, hideBelow: "lg" },
              { key: "date", label: "Date", mono: true, render: (r) => prettyDate(r.date) },
            ]}
            rows={PURCHASES}
            searchKeys={["id", "item", "supplier", "invoice"]}
            exportName="store-purchases"
            canExport={can(authRole, "export")}
            initialSort={{ key: "date", dir: "desc" }}
          />

          <DataTable
            title="Sales / issue against order"
            subtitle="Order consumption billed to the buyer, plus any surplus stock sold locally"
            icon={Tags}
            columns={[
              { key: "id", label: "Ref", mono: true, width: 90 },
              { key: "item", label: "Item" },
              { key: "type", label: "Type", render: (r) => <Badge tone={r.type === "Surplus sale" ? C.gold : C.muted}>{r.type}</Badge> },
              { key: "qty", label: "Qty", mono: true, align: "right", render: (r) => `${num(r.qty)} ${r.unit}` },
              { key: "total", label: "Value", mono: true, align: "right", render: (r) => taka(r.qty * r.unitPrice), csv: false },
              { key: "buyer", label: "Buyer / customer", hideBelow: "md" },
              { key: "refOrder", label: "Order ref", mono: true, hideBelow: "lg" },
              { key: "date", label: "Date", mono: true, render: (r) => prettyDate(r.date) },
            ]}
            rows={SALES}
            searchKeys={["id", "item", "buyer", "refOrder"]}
            filterKeys={[{ key: "type", label: "Type" }]}
            exportName="store-sales"
            canExport={can(authRole, "export")}
            initialSort={{ key: "date", dir: "desc" }}
          />
        </>
      )}
    </div>
  );
}
