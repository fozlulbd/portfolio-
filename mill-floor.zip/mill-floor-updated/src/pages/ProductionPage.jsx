import React from "react";
import {
  ResponsiveContainer, ComposedChart, Bar, Line, XAxis, YAxis, Tooltip,
  CartesianGrid, ReferenceLine,
} from "recharts";
import { Factory, Gauge, Users, AlertTriangle, Layers } from "../icons.js";
import { C, F } from "../theme/tokens.js";
import { usePalette } from "../theme/ThemeProvider.jsx";
import { LINE_PERFORMANCE, HOURLY_OUTPUT, WIP, productionSummary, efficiency } from "../data/production.js";
import { num, pct } from "../lib/format.js";
import { can } from "../auth/roles.js";
import { useFakeLoad } from "../hooks/dom.js";
import Card, { CardHeader } from "../components/ui/Card.jsx";
import KpiCard from "../components/ui/KpiCard.jsx";
import Meter from "../components/ui/Meter.jsx";
import DataTable from "../components/DataTable.jsx";
import { Badge } from "../components/ui/StatusPill.jsx";
import { ChartSkeleton, CardsSkeleton } from "../components/ui/Skeleton.jsx";

/* ---------------------------------------------------------------
   PRODUCTION — efficiency is output over an SMV-derived target, so a
   line running a 26.8-minute roll-neck is judged on the same scale as
   one running a 14-minute v-neck.
----------------------------------------------------------------*/
export default function ProductionPage({ authRole }) {
  const palette = usePalette();
  const loading = useFakeLoad(480, []);
  const s = productionSummary();

  const columns = [
    { key: "line", label: "Line", mono: true, width: 84 },
    { key: "styleNo", label: "Style", mono: true },
    { key: "operators", label: "Operators", align: "right", mono: true, hideBelow: "md" },
    {
      key: "smv",
      label: "SMV",
      align: "right",
      mono: true,
      hideBelow: "lg",
      render: (r) => r.smv.toFixed(1),
    },
    { key: "target", label: "Target", align: "right", mono: true, render: (r) => num(r.target) },
    { key: "output", label: "Output", align: "right", mono: true, render: (r) => num(r.output) },
    {
      key: "defects",
      label: "Defects",
      align: "right",
      mono: true,
      hideBelow: "md",
      render: (r) => <span style={{ color: r.defects > 15 ? C.red : C.muted }}>{r.defects}</span>,
    },
    {
      key: "efficiency",
      label: "Efficiency",
      align: "right",
      sortable: false,
      csv: false,
      width: 168,
      render: (r) => <Meter value={efficiency(r)} right={pct(efficiency(r))} />,
    },
  ];

  const rows = LINE_PERFORMANCE.map((r) => ({ ...r, efficiency: Number((efficiency(r) * 100).toFixed(1)) }));

  if (loading) {
    return (
      <div className="space-y-5">
        <CardsSkeleton />
        <Card style={{ padding: 20 }}>
          <ChartSkeleton height={250} />
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <KpiCard
          label="Shift output"
          value={num(s.output)}
          sub={`target ${num(s.target)} pcs`}
          icon={Factory}
          delta={0.021}
        />
        <KpiCard
          label="Overall efficiency"
          value={pct(s.efficiency)}
          sub="output ÷ SMV target"
          icon={Gauge}
          tone={s.efficiency >= 0.95 ? C.green : C.amber}
          delta={-0.009}
        />
        <KpiCard label="Operators on line" value={num(s.operators)} sub="across six lines" icon={Users} />
        <KpiCard
          label="DHU"
          value={`${s.dhu.toFixed(2)}%`}
          sub={`${s.defects} defects found`}
          icon={AlertTriangle}
          tone={C.red}
          delta={-0.04}
          goodDirection="down"
        />
      </div>

      <Card>
        <CardHeader
          title="Hourly output — current shift"
          subtitle="Bars are actual pieces; the line is the hourly target"
          icon={Factory}
          right={<Badge tone={C.gold}>Lunch 12:00–13:00</Badge>}
        />
        <div style={{ height: 250, padding: "16px 8px 4px" }}>
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={HOURLY_OUTPUT} margin={{ top: 6, right: 12, left: -20, bottom: 0 }}>
              <CartesianGrid stroke={palette.line} vertical={false} />
              <XAxis dataKey="hour" stroke={palette.muted} fontSize={11} tickLine={false} axisLine={{ stroke: palette.line }} />
              <YAxis stroke={palette.muted} fontSize={11} tickLine={false} axisLine={false} />
              <Tooltip
                contentStyle={{
                  background: palette.panelAlt,
                  border: `1px solid ${palette.line}`,
                  borderRadius: 8,
                  fontSize: 12,
                  color: palette.text,
                }}
                formatter={(v, k) => [num(v), k === "output" ? "Output" : "Target"]}
              />
              <Bar dataKey="output" fill={palette.gold} radius={[3, 3, 0, 0]} maxBarSize={38} />
              <Line type="monotone" dataKey="target" stroke={palette.muted} strokeWidth={1.5} strokeDasharray="4 3" dot={false} />
              <ReferenceLine x="12:00" stroke={palette.line} strokeDasharray="2 4" />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </Card>

      <DataTable
        title="Line-wise performance"
        subtitle={`Best: ${s.best.line} at ${pct(efficiency(s.best))} · needs help: ${s.worst.line} at ${pct(efficiency(s.worst))}`}
        icon={Gauge}
        columns={columns}
        rows={rows}
        searchKeys={["line", "styleNo"]}
        filterKeys={[{ key: "styleNo", label: "Style" }]}
        exportName="line-performance"
        canExport={can(authRole, "export")}
        initialSort={{ key: "efficiency", dir: "desc" }}
      />

      <Card>
        <CardHeader
          title="Work in progress"
          subtitle="Pieces sitting at each process, front to back"
          icon={Layers}
        />
        <div className="px-5 py-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-6 gap-y-4">
          {WIP.map((w) => (
            <div key={w.process}>
              <p style={{ color: C.muted }} className="text-[11px] uppercase tracking-wide">
                {w.process}
              </p>
              <p style={{ color: C.text, fontFamily: F.display }} className="text-lg font-semibold mt-0.5">
                {w.pcs ? num(w.pcs) : num(w.kg)}
                <span style={{ color: C.muted }} className="text-[11px] font-normal ml-1">
                  {w.pcs ? "pcs" : "kg"}
                </span>
              </p>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
