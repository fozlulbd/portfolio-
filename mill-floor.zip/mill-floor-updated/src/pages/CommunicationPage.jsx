import React, { useState } from "react";
import {
  PhoneCall, PhoneIncoming, PhoneOutgoing, PhoneMissed, MessageSquare, Send, Plus,
} from "../icons.js";
import { C, F } from "../theme/tokens.js";
import {
  CALL_LOG, MESSAGES, MESSAGE_AUDIENCES, MESSAGE_CHANNELS, communicationSummary,
} from "../data/communication.js";
import { can } from "../auth/roles.js";
import Card, { CardHeader } from "../components/ui/Card.jsx";
import KpiCard from "../components/ui/KpiCard.jsx";
import Stitch from "../components/ui/Stitch.jsx";
import Tabs from "../components/ui/Tabs.jsx";
import Button from "../components/ui/Button.jsx";
import DataTable from "../components/DataTable.jsx";
import { Badge } from "../components/ui/StatusPill.jsx";
import Meter from "../components/ui/Meter.jsx";
import Modal from "../components/ui/Modal.jsx";
import { Field, Input, Select, Textarea } from "../components/ui/Field.jsx";

const DIR_ICON = { Incoming: PhoneIncoming, Outgoing: PhoneOutgoing, Missed: PhoneMissed };
const DIR_TONE = { Incoming: C.green, Outgoing: C.gold, Missed: C.red };

function LogCallForm({ open, onClose, onSave }) {
  const [draft, setDraft] = useState({ direction: "Incoming", party: "", topic: "", handledBy: "" });
  const set = (k, v) => setDraft((d) => ({ ...d, [k]: v }));

  function submit() {
    if (!draft.party.trim() || !draft.topic.trim()) return;
    onSave(draft);
    setDraft({ direction: "Incoming", party: "", topic: "", handledBy: "" });
    onClose();
  }

  return (
    <Modal open={open} onClose={onClose} title="Log a call" subtitle="Added to today's call register.">
      <div className="px-5 py-4 space-y-4">
        <Field label="Direction">
          <Select value={draft.direction} onChange={(e) => set("direction", e.target.value)} options={["Incoming", "Outgoing", "Missed"]} />
        </Field>
        <Field label="Caller / party" required>
          <Input value={draft.party} onChange={(e) => set("party", e.target.value)} placeholder="Name — company or ID" />
        </Field>
        <Field label="Topic" required>
          <Input value={draft.topic} onChange={(e) => set("topic", e.target.value)} placeholder="What the call was about" />
        </Field>
        <Field label="Handled by">
          <Input value={draft.handledBy} onChange={(e) => set("handledBy", e.target.value)} placeholder="e.g. HR Officer" />
        </Field>
      </div>
      <Stitch />
      <div className="px-5 py-4 flex items-center justify-end gap-2">
        <Button variant="outline" onClick={onClose}>Cancel</Button>
        <Button variant="primary" icon={PhoneCall} onClick={submit}>Save call</Button>
      </div>
    </Modal>
  );
}

function SendMessageForm({ open, onClose, onSave }) {
  const [draft, setDraft] = useState({ title: "", body: "", audience: "All", channel: "App + SMS" });
  const set = (k, v) => setDraft((d) => ({ ...d, [k]: v }));

  function submit() {
    if (!draft.title.trim() || !draft.body.trim()) return;
    onSave(draft);
    setDraft({ title: "", body: "", audience: "All", channel: "App + SMS" });
    onClose();
  }

  return (
    <Modal open={open} onClose={onClose} title="Send a message" subtitle="Pushed to the worker mobile app immediately; SMS follows within a few minutes.">
      <div className="px-5 py-4 space-y-4">
        <Field label="Title" required>
          <Input value={draft.title} onChange={(e) => set("title", e.target.value)} placeholder="Short headline" />
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Audience">
            <Select value={draft.audience} onChange={(e) => set("audience", e.target.value)} options={MESSAGE_AUDIENCES} />
          </Field>
          <Field label="Channel">
            <Select value={draft.channel} onChange={(e) => set("channel", e.target.value)} options={MESSAGE_CHANNELS} />
          </Field>
        </div>
        <Field label="Message" required>
          <Textarea rows={4} value={draft.body} onChange={(e) => set("body", e.target.value)} placeholder="Write the message as workers will see it in the app…" />
        </Field>
      </div>
      <Stitch />
      <div className="px-5 py-4 flex items-center justify-end gap-2">
        <Button variant="outline" onClick={onClose}>Cancel</Button>
        <Button variant="primary" icon={Send} onClick={submit}>Send now</Button>
      </div>
    </Modal>
  );
}

export default function CommunicationPage({ authRole }) {
  const [tab, setTab] = useState("calls");
  const [calls, setCalls] = useState(CALL_LOG);
  const [messages, setMessages] = useState(MESSAGES);
  const [callFormOpen, setCallFormOpen] = useState(false);
  const [msgFormOpen, setMsgFormOpen] = useState(false);

  const summary = communicationSummary();

  function saveCall(draft) {
    const id = `CL-${800 + calls.length}`;
    setCalls((prev) => [
      { id, time: new Date().toTimeString().slice(0, 5), status: draft.direction === "Missed" ? "Call back" : "Completed", duration: draft.direction === "Missed" ? "—" : "—", ...draft },
      ...prev,
    ]);
  }

  function saveMessage(draft) {
    const id = `MSG-${500 + messages.length}`;
    setMessages((prev) => [
      ...prev,
      {
        id,
        ...draft,
        sentBy: authRole?.label || "Admin",
        sentAt: new Date().toISOString().slice(0, 16).replace("T", " "),
        delivered: 0,
        total: 4060,
      },
    ]);
  }

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <KpiCard label="Calls today" value={summary.todayCalls} sub="incoming, outgoing & missed" icon={PhoneCall} />
        <KpiCard label="Call-backs pending" value={summary.missed} sub="missed calls awaiting a return" icon={PhoneMissed} tone={summary.missed ? C.red : C.green} />
        <KpiCard label="Messages sent" value={summary.messageCount} sub="to the worker app / SMS" icon={MessageSquare} />
        <KpiCard label="Avg. delivery" value={`${Math.round(summary.avgDeliveryPct * 100)}%`} sub="across all recipients" icon={Send} tone={C.gold} />
      </div>

      <Tabs
        value={tab}
        onChange={setTab}
        tabs={[
          { key: "calls", label: "Call log", count: calls.length },
          { key: "messages", label: "Messages", count: messages.length },
        ]}
      />

      {tab === "calls" ? (
        <>
          <div className="flex justify-end">
            {can(authRole, "create") && (
              <Button variant="primary" icon={Plus} onClick={() => setCallFormOpen(true)}>Log a call</Button>
            )}
          </div>
          <DataTable
            title="Call register"
            subtitle="Front-desk and office intercom calls"
            icon={PhoneCall}
            columns={[
              { key: "time", label: "Time", mono: true, width: 70 },
              {
                key: "direction",
                label: "Direction",
                render: (r) => {
                  const Icon = DIR_ICON[r.direction] || PhoneCall;
                  return (
                    <span style={{ color: DIR_TONE[r.direction] || C.muted }} className="inline-flex items-center gap-1.5 text-xs">
                      <Icon size={13} /> {r.direction}
                    </span>
                  );
                },
              },
              { key: "party", label: "Caller / party" },
              { key: "topic", label: "Topic", hideBelow: "md" },
              { key: "handledBy", label: "Handled by", hideBelow: "lg" },
              { key: "duration", label: "Duration", mono: true, align: "right", width: 90 },
              { key: "status", label: "Status", render: (r) => <Badge tone={r.status === "Call back" ? C.red : C.green}>{r.status}</Badge> },
            ]}
            rows={calls}
            searchKeys={["id", "party", "topic", "handledBy"]}
            filterKeys={[{ key: "direction", label: "Direction" }, { key: "status", label: "Status" }]}
            exportName="call-log"
            canExport={can(authRole, "export")}
            initialSort={{ key: "time", dir: "desc" }}
          />
        </>
      ) : (
        <>
          <div className="flex justify-end">
            {can(authRole, "create") && (
              <Button variant="primary" icon={Plus} onClick={() => setMsgFormOpen(true)}>Send a message</Button>
            )}
          </div>
          <div className="space-y-4">
            {[...messages].reverse().map((m) => {
              const ratio = m.total ? m.delivered / m.total : 0;
              return (
                <Card key={m.id} style={{ padding: "18px 20px" }}>
                  <div className="flex items-start justify-between gap-3 flex-wrap">
                    <div className="flex items-center gap-2 flex-wrap">
                      <Badge>{m.audience}</Badge>
                      <Badge tone={C.muted}>{m.channel}</Badge>
                    </div>
                    <span style={{ color: C.muted, fontFamily: F.mono }} className="text-[11px]">{m.sentAt}</span>
                  </div>
                  <h3 style={{ fontFamily: F.display, color: C.text }} className="text-sm font-semibold mt-2.5">{m.title}</h3>
                  <p style={{ color: C.muted }} className="text-xs mt-0.5">by {m.sentBy}</p>
                  <Stitch style={{ margin: "12px 0" }} />
                  <p style={{ color: C.text }} className="text-sm">{m.body}</p>
                  <div className="mt-3">
                    <Meter value={ratio} good={0.9} warn={0.7} label="Delivered" right={`${m.delivered.toLocaleString()} / ${m.total.toLocaleString()}`} />
                  </div>
                </Card>
              );
            })}
          </div>
        </>
      )}

      <LogCallForm open={callFormOpen} onClose={() => setCallFormOpen(false)} onSave={saveCall} />
      <SendMessageForm open={msgFormOpen} onClose={() => setMsgFormOpen(false)} onSave={saveMessage} />
    </div>
  );
}
