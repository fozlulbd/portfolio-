import React, { useMemo, useState } from "react";
import { ScanFace, Lock, Fingerprint, ChevronRight, User, Info } from "../icons.js";
import { C, F, weaveBackground } from "../theme/tokens.js";
import { ROLE_LIST, ROLES } from "../auth/roles.js";
import Card from "../components/ui/Card.jsx";
import Stitch from "../components/ui/Stitch.jsx";
import Button from "../components/ui/Button.jsx";
import { Field, Input } from "../components/ui/Field.jsx";

/* One full-screen backdrop per sign-in, picked once when the screen
   mounts (so signing out and back in shows a different one) rather
   than a slideshow — a still photo reads calmer behind a login form
   than something moving underneath it. All four are on-brand for a
   knitwear mill: the CAD/knitting studio, the machine floor, and a
   sewing station, not generic fashion stock. */
const BACKDROPS = [
  "/login-bg/knit-cad-studio.jpg",
  "/login-bg/knit-cad-render.jpg",
  "/login-bg/knit-machine-team.jpg",
  "/login-bg/sewing-station.jpg",
];

/* The pitch panel sits directly over the photo + scrim, not over a
   card, so its text uses fixed light values rather than the C.text /
   C.muted theme tokens — those flip dark in light mode, which would
   go straight into a dark scrim and disappear. */
const PITCH_TEXT = "#F4F3EF";
const PITCH_MUTED = "rgba(244,243,239,0.72)";

/* ---------------------------------------------------------------
   LOGIN — the role picker is the important control here: it decides
   which modules exist for the rest of the session. Credentials are
   accepted as-is; this is a front-end demo with no auth backend.
----------------------------------------------------------------*/
export default function LoginScreen({ onLogin }) {
  const [roleKey, setRoleKey] = useState("admin");
  const [pass, setPass] = useState("");
  const [error, setError] = useState("");
  const role = ROLES[roleKey];

  // Picked once per mount — a fresh sign-in (or a sign-out and back)
  // gets a different backdrop; the same session never flickers to a
  // new one mid-use.
  const backdrop = useMemo(() => BACKDROPS[Math.floor(Math.random() * BACKDROPS.length)], []);

  function submit(e) {
    e?.preventDefault();
    if (pass.trim().length < 4) {
      setError("Enter at least 4 characters — any value works in this demo");
      return;
    }
    onLogin(role);
  }

  return (
    <div className="min-h-screen relative flex items-center justify-center overflow-hidden p-4 sm:p-6">
      {/* Photo backdrop */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          backgroundImage: `url(${backdrop})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
        className="animate-fade-in"
        aria-hidden="true"
      />
      {/* Dark scrim so the pitch text and the sign-in card stay legible
          no matter how bright the photo underneath is. */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          background:
            "linear-gradient(120deg, rgba(9,11,15,.94) 0%, rgba(9,11,15,.86) 42%, rgba(9,11,15,.74) 100%)",
        }}
        aria-hidden="true"
      />
      {/* Stitched-thread texture, kept faint, on top of the scrim so the
          brand motif still reads through a photo background. */}
      <div style={{ position: "absolute", inset: 0, opacity: 0.16, ...weaveBackground() }} aria-hidden="true" />

      <div className="relative w-full max-w-4xl grid lg:grid-cols-2 gap-5">
        {/* ── pitch panel ─────────────────────────────────────── */}
        <div className="hidden lg:flex flex-col justify-between py-2">
          <div>
            <div className="flex items-center gap-3">
              <div
                style={{ background: "rgba(201,162,75,0.18)", color: C.gold, border: "1px solid rgba(244,243,239,0.22)" }}
                className="w-12 h-12 rounded-lg flex items-center justify-center"
              >
                <ScanFace size={24} strokeWidth={1.7} />
              </div>
              <div>
                <p style={{ fontFamily: F.display, color: PITCH_TEXT }} className="text-xl font-semibold leading-tight">
                  Mill Floor
                </p>
                <p style={{ color: PITCH_MUTED }} className="text-xs">
                  Knitwear workforce &amp; production system
                </p>
              </div>
            </div>

            <Stitch style={{ margin: "26px 0", opacity: 0.5 }} />

            <p style={{ color: PITCH_TEXT }} className="text-sm leading-relaxed max-w-sm">
              Attendance from the gate terminals, payroll, buyer orders, line efficiency and the
              yarn store — one register for the whole unit.
            </p>

            <ul className="mt-6 space-y-2.5">
              {[
                "4,000 employees across six role types",
                "Biometric punches from four gate devices",
                "Line-wise efficiency against SMV targets",
                "Buyer orders, tech packs and shipment dates",
              ].map((t) => (
                <li key={t} className="flex items-start gap-2.5">
                  <span style={{ background: C.gold }} className="w-1 h-1 rounded-full mt-2 shrink-0" />
                  <span style={{ color: PITCH_MUTED }} className="text-xs leading-relaxed">
                    {t}
                  </span>
                </li>
              ))}
            </ul>
          </div>

          <p style={{ color: PITCH_MUTED, fontFamily: F.mono }} className="text-[10px]">
            v1.0 · Gazipur Unit 2 · demo data
          </p>
        </div>

        {/* ── sign-in card ────────────────────────────────────── */}
        <Card style={{ padding: "28px 26px", boxShadow: C.shadow }} className="animate-rise-in">
          <div className="flex items-center gap-2.5 lg:hidden mb-4">
            <div style={{ background: C.goldDim, color: C.gold }} className="w-10 h-10 rounded-lg flex items-center justify-center">
              <ScanFace size={20} strokeWidth={1.8} />
            </div>
            <div>
              <p style={{ fontFamily: F.display, color: C.text }} className="text-base font-semibold leading-tight">
                Mill Floor
              </p>
              <p style={{ color: C.muted }} className="text-[11px] leading-tight">
                Factory Workforce System
              </p>
            </div>
          </div>

          <h2 style={{ fontFamily: F.display, color: C.text }} className="text-sm font-semibold">
            Sign in
          </h2>
          <p style={{ color: C.muted }} className="text-xs mt-1 mb-4">
            Pick the role you are signing in as — it decides which modules open.
          </p>

          <div className="grid grid-cols-2 gap-2 mb-4">
            {ROLE_LIST.map((r) => {
              const active = r.key === roleKey;
              return (
                <button
                  key={r.key}
                  type="button"
                  onClick={() => {
                    setRoleKey(r.key);
                    setError("");
                  }}
                  aria-pressed={active}
                  style={{
                    background: active ? C.goldDim : C.panelAlt,
                    border: `1px solid ${active ? C.gold : C.line}`,
                    color: active ? C.gold : C.muted,
                  }}
                  className={`text-left px-3 py-2 rounded-md transition-all duration-150 ${
                    r.key === "admin" ? "col-span-2" : ""
                  }`}
                >
                  <span className="text-xs font-medium block">{r.label}</span>
                  <span style={{ fontFamily: F.mono }} className="text-[10px] opacity-80 block truncate">
                    {r.username}
                  </span>
                </button>
              );
            })}
          </div>

          <div
            style={{ background: C.panelAlt, border: `1px solid ${C.line}` }}
            className="rounded-md px-3 py-2.5 mb-4 flex items-start gap-2"
          >
            <Info size={12} style={{ color: C.gold }} className="mt-0.5 shrink-0" />
            <p style={{ color: C.muted }} className="text-[11px] leading-relaxed">
              {role.blurb}
            </p>
          </div>

          <form onSubmit={submit}>
            <Field label="Username">
              <div
                style={{ background: C.panelAlt, border: `1px solid ${C.line}` }}
                className="w-full rounded-md px-3 py-2.5 flex items-center gap-2"
              >
                <User size={14} style={{ color: C.muted }} />
                <input
                  value={role.username}
                  readOnly
                  aria-label="Username"
                  style={{ background: "transparent", color: C.text, fontFamily: F.mono }}
                  className="w-full text-sm outline-none"
                />
              </div>
            </Field>

            <Field label="Password" error={error} className="mt-3.5">
              <div
                style={{ background: C.panelAlt, border: `1px solid ${error ? C.red : C.line}` }}
                className="w-full rounded-md px-3 py-2.5 flex items-center gap-2"
              >
                <Lock size={14} style={{ color: C.muted }} />
                <input
                  type="password"
                  value={pass}
                  onChange={(e) => {
                    setPass(e.target.value);
                    setError("");
                  }}
                  placeholder="Type anything — e.g. 1234"
                  aria-label="Password"
                  style={{ background: "transparent", color: C.text }}
                  className="w-full text-sm outline-none"
                />
              </div>
            </Field>

            <Button
              variant="primary"
              size="md"
              iconRight={ChevronRight}
              className="w-full mt-5"
              onClick={submit}
            >
              Open dashboard
            </Button>
          </form>

          <div className="flex items-center gap-1.5 justify-center mt-4">
            <Fingerprint size={12} style={{ color: C.muted }} />
            <p style={{ color: C.muted }} className="text-[11px]">
              Demo build · no password is checked or stored
            </p>
          </div>
        </Card>
      </div>
    </div>
  );
}
