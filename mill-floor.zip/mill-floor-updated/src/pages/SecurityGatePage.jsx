import React, { useState } from "react";
import {
  ShieldCheck, DoorOpen, LogIn, LogOut, UserCheck, Cpu, WifiOff, Wifi,
} from "../icons.js";
import { C, F } from "../theme/tokens.js";
import { GATE_LOG, VISITORS, DEVICES } from "../data/gate.js";
import { num } from "../lib/format.js";
import { can } from "../auth/roles.js";
import { useStore } from "../store/AppStore.jsx";
import Card, { CardHeader } from "../components/ui/Card.jsx";
import Tabs from "../components/ui/Tabs.jsx";
import KpiCard from "../components/ui/KpiCard.jsx";
import DataTable from "../components/DataTable.jsx";
import StatusPill, { Badge } from "../components/ui/StatusPill.jsx";
import Meter from "../components/ui/Meter.jsx";

/* ---------------------------------------------------------------
   GATE & DEVICES — the security role's landing page. Every punch row
   links back to the employee record, so a guard checking a late entry
   can open the card without leaving the desk.
----------------------------------------------------------------*/
export default function SecurityGatePage({ authRole, onOpenPerson }) {
  const { byId } = useStore();
  const [tab, setTab] = useState("movement");
  const canExport = can(authRole, "export");

  const ins = GATE_LOG.filter((g) => g.dir === "IN").length;
  const outs = GATE_LOG.filter((g) => g.dir === "OUT").length;
  const flagged = GATE_LOG.filter((g) => g.flag).length;
  const offline = DEVICES.filter((d) => d.status === "Offline").length;
  const punches = DEVICES.reduce((a, d) => a + d.punchesToday, 0);

  const gateColumns = [
    { key: "time", label: "Time", mono: true, width: 76 },
    {
      key: "dir",
      label: "Direction",
      width: 104,
      render: (r) => (
        <span
          style={{ color: r.dir === "IN" ? C.green : C.amber, fontFamily: F.mono }}
          className="inline-flex items-center gap-1.5 text-xs"
        >
          {r.dir === "IN" ? <LogIn size={12} /> : <LogOut size={12} />}
          {r.dir}
        </span>
      ),
    },
    { key: "empId", label: "ID", mono: true, width: 96 },
    { key: "name", label: "Name" },
    { key: "gate", label: "Gate", hideBelow: "md" },
    { key: "device", label: "Device", mono: true, hideBelow: "lg" },
    { key: "method", label: "Method", hideBelow: "md", render: (r) => <Badge>{r.method}</Badge> },
    {
      key: "flag",
      label: "Flag",
      render: (r) => (r.flag ? <StatusPill status={r.flag} /> : <span style={{ color: C.muted }}>—</span>),
    },
  ];

  const visitorColumns = [
    { key: "id", label: "Pass", mono: true, width: 88 },
    { key: "time", label: "In at", mono: true, width: 76 },
    { key: "name", label: "Visitor" },
    { key: "org", label: "Organisation", hideBelow: "md" },
    { key: "purpose", label: "Purpose", hideBelow: "lg" },
    { key: "host", label: "Host dept", hideBelow: "md" },
    { key: "badge", label: "Badge", mono: true, width: 80 },
    { key: "status", label: "Status", render: (r) => <StatusPill status={r.status} /> },
  ];

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <KpiCard label="Punches recorded" value={num(punches)} sub="all terminals, today" icon={ShieldCheck} />
        <KpiCard label="Movements logged" value={`${ins} in · ${outs} out`} sub="at the guard desk" icon={DoorOpen} />
        <KpiCard
          label="Flagged entries"
          value={num(flagged)}
          sub="late or on official duty"
          icon={UserCheck}
          tone={flagged ? C.amber : C.green}
        />
        <KpiCard
          label="Terminals offline"
          value={num(offline)}
          sub={offline ? "punches not syncing" : "all devices healthy"}
          icon={offline ? WifiOff : Wifi}
          tone={offline ? C.red : C.green}
        />
      </div>

      <Tabs
        value={tab}
        onChange={setTab}
        tabs={[
          { key: "movement", label: "Movement log", count: GATE_LOG.length },
          { key: "visitors", label: "Visitors", count: VISITORS.length },
          { key: "devices", label: "Devices", count: DEVICES.length },
        ]}
      />

      {tab === "movement" && (
        <DataTable
          title="Gate movement log"
          subtitle="Biometric and card punches, newest last"
          icon={DoorOpen}
          columns={gateColumns}
          rows={GATE_LOG}
          searchKeys={["empId", "name", "gate", "device", "method", "flag"]}
          filterKeys={[
            { key: "dir", label: "Direction" },
            { key: "gate", label: "Gate" },
            { key: "method", label: "Method" },
          ]}
          onRowClick={(r) => {
            const p = byId(r.empId);
            if (p) onOpenPerson(p);
          }}
          exportName="gate-log"
          canExport={canExport}
          initialSort={{ key: "time", dir: "asc" }}
          dense
        />
      )}

      {tab === "visitors" && (
        <DataTable
          title="Visitor register"
          subtitle="Badges issued at reception today"
          icon={UserCheck}
          columns={visitorColumns}
          rows={VISITORS}
          searchKeys={["id", "name", "org", "purpose", "host", "badge"]}
          filterKeys={[
            { key: "status", label: "Status" },
            { key: "host", label: "Host dept" },
          ]}
          exportName="visitor-register"
          canExport={canExport}
        />
      )}

      {tab === "devices" && (
        <Card>
          <CardHeader
            title="Attendance terminals"
            subtitle="Punch volume is a proxy for whether a device is actually reading"
            icon={Cpu}
          />
          <div className="px-5 py-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
            {DEVICES.map((d) => {
              const dead = d.status === "Offline";
              return (
                <div
                  key={d.id}
                  style={{
                    background: C.panelAlt,
                    border: `1px solid ${dead ? C.red : C.line}`,
                  }}
                  className="rounded-lg p-4"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p style={{ color: C.text, fontFamily: F.display }} className="text-sm font-semibold truncate">
                        {d.name}
                      </p>
                      <p style={{ color: C.muted, fontFamily: F.mono }} className="text-[11px] mt-0.5 truncate">
                        {d.id} · {d.gate}
                      </p>
                    </div>
                    <StatusPill status={d.status} />
                  </div>

                  <div className="mt-3.5">
                    <Meter
                      value={d.punchesToday / 3000}
                      good={0.2}
                      warn={0.05}
                      label="Punches today"
                      right={num(d.punchesToday)}
                    />
                  </div>

                  <p style={{ color: dead ? C.red : C.muted, fontFamily: F.mono }} className="text-[11px] mt-2.5">
                    Last sync {d.lastSync}
                    {dead && " — send a technician to Gate 4"}
                  </p>
                </div>
              );
            })}
          </div>
        </Card>
      )}
    </div>
  );
}
