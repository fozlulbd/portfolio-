import React from "react";
import { Ship, Plane, AlertTriangle, CalendarClock, Check, PackageCheck } from "../icons.js";
import { C, F } from "../theme/tokens.js";
import { SHIPMENTS } from "../data/commercial.js";
import { num, pct, prettyDate } from "../lib/format.js";
import { can } from "../auth/roles.js";
import Card, { CardHeader } from "../components/ui/Card.jsx";
import KpiCard from "../components/ui/KpiCard.jsx";
import Stitch from "../components/ui/Stitch.jsx";
import StatusPill, { Badge } from "../components/ui/StatusPill.jsx";
import Meter from "../components/ui/Meter.jsx";
import DataTable from "../components/DataTable.jsx";

const daysLeft = (d) => Math.round((new Date(d) - new Date("2026-08-24")) / 86_400_000);
const doneRatio = (s) => s.milestones.filter((m) => m.done).length / s.milestones.length;

/* ---------------------------------------------------------------
   SHIPMENT — the milestone rail is the point of this page. A status
   word tells you nothing; seeing that yarn is still not in-house on a
   November air shipment tells you everything.
----------------------------------------------------------------*/
export default function ShipmentPage({ authRole }) {
  const atRisk = SHIPMENTS.filter((s) => s.status === "At risk");
  const totalPcs = SHIPMENTS.reduce((a, s) => a + s.qty, 0);
  const nearest = SHIPMENTS.reduce((a, s) => (daysLeft(s.date) < daysLeft(a.date) ? s : a));

  const columns = [
    { key: "id", label: "Ref", mono: true, width: 80 },
    { key: "buyer", label: "Buyer" },
    { key: "styleNo", label: "Style", mono: true },
    { key: "qty", label: "Quantity", mono: true, align: "right", render: (r) => num(r.qty) },
    {
      key: "mode",
      label: "Mode",
      hideBelow: "md",
      render: (r) => (
        <span style={{ color: C.muted }} className="inline-flex items-center gap-1.5 text-xs">
          {r.mode.startsWith("Air") ? <Plane size={12} /> : <Ship size={12} />}
          {r.mode}
        </span>
      ),
    },
    { key: "forwarder", label: "Forwarder", hideBelow: "lg" },
    {
      key: "date",
      label: "Ship date",
      mono: true,
      align: "right",
      render: (r) => (
        <span>
          {prettyDate(r.date)}
          <span style={{ color: C.muted }} className="block text-[10px]">
            in {daysLeft(r.date)} days
          </span>
        </span>
      ),
    },
    {
      key: "completion",
      label: "Milestones",
      sortable: false,
      csv: false,
      width: 150,
      render: (r) => <Meter value={doneRatio(r)} good={0.6} warn={0.3} right={pct(doneRatio(r), 0)} />,
    },
    { key: "status", label: "Status", render: (r) => <StatusPill status={r.status} /> },
  ];

  const rows = SHIPMENTS.map((s) => ({ ...s, completion: Math.round(doneRatio(s) * 100) }));

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <KpiCard label="Open shipments" value={SHIPMENTS.length} sub="booked with forwarders" icon={PackageCheck} />
        <KpiCard label="Pieces to ship" value={num(totalPcs)} sub="all consignments" icon={Ship} />
        <KpiCard
          label="At risk"
          value={atRisk.length}
          sub={atRisk.length ? atRisk.map((s) => s.id).join(", ") : "nothing flagged"}
          icon={AlertTriangle}
          tone={atRisk.length ? C.red : C.green}
        />
        <KpiCard
          label="Next ex-factory"
          value={`${daysLeft(nearest.date)} days`}
          sub={`${nearest.buyer} · ${nearest.styleNo}`}
          icon={CalendarClock}
          tone={C.amber}
        />
      </div>

      {atRisk.length > 0 && (
        <Card style={{ borderColor: C.red }}>
          <CardHeader title="Shipments needing a decision" subtitle="Escalate today, not at the weekly review" icon={AlertTriangle} />
          <ul className="px-5 py-4 space-y-3">
            {atRisk.map((s) => (
              <li key={s.id}>
                <p style={{ color: C.text }} className="text-sm">
                  {s.buyer}
                  <span style={{ color: C.muted, fontFamily: F.mono }} className="text-[11px] ml-2">
                    {s.id} · {s.styleNo} · {prettyDate(s.date)}
                  </span>
                </p>
                <p style={{ color: C.red }} className="text-xs mt-1 leading-relaxed">
                  {s.risk}
                </p>
              </li>
            ))}
          </ul>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {SHIPMENTS.map((s) => (
          <Card key={s.id} hover className="flex flex-col">
            <div className="px-5 py-4">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <p style={{ color: C.gold, fontFamily: F.mono }} className="text-[11px]">
                    {s.id} · {s.styleNo}
                  </p>
                  <h3 style={{ fontFamily: F.display, color: C.text }} className="text-sm font-semibold mt-1 truncate">
                    {s.buyer}
                  </h3>
                  <p style={{ color: C.muted, fontFamily: F.mono }} className="text-[11px] mt-1">
                    {num(s.qty)} pcs · {s.mode}
                  </p>
                </div>
                <StatusPill status={s.status} />
              </div>
            </div>

            <Stitch />

            <ol className="px-5 py-4 flex-1">
              {s.milestones.map((m, i) => (
                <li key={m.label} className="flex gap-3">
                  <div className="flex flex-col items-center">
                    <div
                      style={{
                        background: m.done ? C.gold : "transparent",
                        border: `1px solid ${m.done ? C.gold : C.line}`,
                        color: m.done ? C.bg : C.muted,
                      }}
                      className="w-5 h-5 rounded-full flex items-center justify-center shrink-0"
                    >
                      {m.done ? <Check size={11} strokeWidth={3} /> : <span className="w-1 h-1 rounded-full" style={{ background: C.muted }} />}
                    </div>
                    {i < s.milestones.length - 1 && (
                      <div style={{ background: m.done ? C.gold : C.line }} className="w-px flex-1 my-0.5" />
                    )}
                  </div>
                  <p
                    style={{ color: m.done ? C.text : C.muted }}
                    className={`text-xs pb-3.5 ${m.done ? "" : "opacity-80"}`}
                  >
                    {m.label}
                  </p>
                </li>
              ))}
            </ol>

            <div style={{ background: C.panelAlt, borderTop: `1px solid ${C.line}` }} className="px-5 py-3.5 rounded-b-lg">
              <Meter
                value={doneRatio(s)}
                good={0.6}
                warn={0.3}
                label={`${s.forwarder} · ${prettyDate(s.date)}`}
                right={`${daysLeft(s.date)} days`}
              />
            </div>
          </Card>
        ))}
      </div>

      <DataTable
        title="Shipment book"
        subtitle="Sort by ship date to see what leaves the factory first"
        icon={Ship}
        columns={columns}
        rows={rows}
        searchKeys={["id", "buyer", "styleNo", "mode", "forwarder", "status"]}
        filterKeys={[
          { key: "status", label: "Status" },
          { key: "mode", label: "Mode" },
          { key: "forwarder", label: "Forwarder" },
        ]}
        exportName="shipment-book"
        canExport={can(authRole, "export")}
        initialSort={{ key: "date", dir: "asc" }}
      />
    </div>
  );
}
