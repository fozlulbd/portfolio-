import React from "react";
import { ClipboardList, Palette, Layers, CalendarClock, Info } from "../icons.js";
import { C, F } from "../theme/tokens.js";
import { REQUIREMENTS } from "../data/commercial.js";
import { num, pct, prettyDate } from "../lib/format.js";
import { can } from "../auth/roles.js";
import Card, { CardHeader } from "../components/ui/Card.jsx";
import KpiCard from "../components/ui/KpiCard.jsx";
import Meter from "../components/ui/Meter.jsx";
import Stitch from "../components/ui/Stitch.jsx";
import { Badge } from "../components/ui/StatusPill.jsx";
import DataTable from "../components/DataTable.jsx";

const usd = (n) => `$${num(Math.round(n))}`;
const daysLeft = (d) => Math.round((new Date(d) - new Date("2026-08-24")) / 86_400_000);

/* ---------------------------------------------------------------
   BUYER REQUIREMENT — each style card carries the things that stop a
   line: the gauge, the yarn the buyer nominated, the colourways and
   the one instruction people forget.
----------------------------------------------------------------*/
export default function RequirementPage({ authRole }) {
  const totalQty = REQUIREMENTS.reduce((a, r) => a + r.qty, 0);
  const totalValue = REQUIREMENTS.reduce((a, r) => a + r.qty * r.unitPrice, 0);
  const avgProgress = REQUIREMENTS.reduce((a, r) => a + r.progress, 0) / REQUIREMENTS.length;
  const tightest = REQUIREMENTS.reduce((a, r) => (daysLeft(r.deadline) < daysLeft(a.deadline) ? r : a));

  const columns = [
    { key: "id", label: "Ref", mono: true, width: 80 },
    { key: "buyer", label: "Buyer" },
    { key: "styleNo", label: "Style" },
    { key: "gauge", label: "Gauge", mono: true, align: "right", width: 84, hideBelow: "md" },
    { key: "qty", label: "Quantity", mono: true, align: "right", render: (r) => num(r.qty) },
    {
      key: "unitPrice",
      label: "FOB / pc",
      mono: true,
      align: "right",
      hideBelow: "md",
      render: (r) => `$${r.unitPrice.toFixed(2)}`,
    },
    {
      key: "value",
      label: "Order value",
      mono: true,
      align: "right",
      render: (r) => <span style={{ color: C.gold }}>{usd(r.qty * r.unitPrice)}</span>,
    },
    { key: "stage", label: "Stage", hideBelow: "lg", render: (r) => <Badge tone={C.gold}>{r.stage}</Badge> },
    {
      key: "deadline",
      label: "Deadline",
      mono: true,
      align: "right",
      render: (r) => {
        const d = daysLeft(r.deadline);
        return (
          <span style={{ color: d < 60 ? C.amber : C.muted }}>
            {prettyDate(r.deadline)}
            <span className="block text-[10px]">{d} days</span>
          </span>
        );
      },
    },
    {
      key: "progress",
      label: "Progress",
      sortable: false,
      csv: false,
      width: 150,
      render: (r) => <Meter value={r.progress} good={0.7} warn={0.35} right={pct(r.progress, 0)} />,
    },
  ];

  const rows = REQUIREMENTS.map((r) => ({
    ...r,
    value: Math.round(r.qty * r.unitPrice),
    progress: r.progress,
    colourList: r.colours.join(", "),
  }));

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <KpiCard label="Live requirements" value={REQUIREMENTS.length} sub="open styles" icon={ClipboardList} />
        <KpiCard label="Pieces committed" value={num(totalQty)} sub="across all buyers" icon={Layers} />
        <KpiCard label="Order book" value={usd(totalValue)} sub="FOB value" icon={Palette} tone={C.gold} />
        <KpiCard
          label="Nearest deadline"
          value={`${daysLeft(tightest.deadline)} days`}
          sub={`${tightest.buyer} · ${tightest.id}`}
          icon={CalendarClock}
          tone={C.amber}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {REQUIREMENTS.map((r) => {
          const left = daysLeft(r.deadline);
          return (
            <Card key={r.id} hover className="flex flex-col">
              <div className="px-5 py-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p style={{ color: C.gold, fontFamily: F.mono }} className="text-[11px]">
                      {r.buyer}
                    </p>
                    <h3 style={{ fontFamily: F.display, color: C.text }} className="text-sm font-semibold mt-1 leading-snug">
                      {r.styleNo}
                    </h3>
                  </div>
                  <Badge tone={left < 60 ? C.amber : C.muted}>{left} d</Badge>
                </div>
              </div>

              <Stitch />

              <div className="px-5 py-4 space-y-3 flex-1">
                <div className="grid grid-cols-2 gap-x-4 gap-y-3">
                  {[
                    ["Quantity", num(r.qty) + " pcs"],
                    ["FOB / pc", `$${r.unitPrice.toFixed(2)}`],
                    ["Gauge", r.gauge],
                    ["Ship by", prettyDate(r.deadline)],
                  ].map(([k, v]) => (
                    <div key={k}>
                      <p style={{ color: C.muted }} className="text-[10px] uppercase tracking-wide">
                        {k}
                      </p>
                      <p style={{ color: C.text, fontFamily: F.mono }} className="text-xs mt-0.5">
                        {v}
                      </p>
                    </div>
                  ))}
                </div>

                <div>
                  <p style={{ color: C.muted }} className="text-[10px] uppercase tracking-wide mb-1">
                    Yarn
                  </p>
                  <p style={{ color: C.text }} className="text-xs">
                    {r.yarn}
                  </p>
                </div>

                <div>
                  <p style={{ color: C.muted }} className="text-[10px] uppercase tracking-wide mb-1.5">
                    Colourways
                  </p>
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {r.colours.map((c) => (
                      <Badge key={c}>{c}</Badge>
                    ))}
                  </div>
                </div>

                <Meter value={r.progress} good={0.7} warn={0.35} label={`Stage: ${r.stage}`} right={pct(r.progress, 0)} />
              </div>

              <div
                style={{ background: C.panelAlt, borderTop: `1px solid ${C.line}` }}
                className="px-5 py-3 rounded-b-lg"
              >
                <p style={{ color: C.muted }} className="text-[11px] leading-relaxed flex gap-2">
                  <Info size={12} style={{ color: C.gold }} className="shrink-0 mt-0.5" />
                  {r.note}
                </p>
              </div>
            </Card>
          );
        })}
      </div>

      <DataTable
        title="Requirement sheet"
        subtitle="One row per open style — sort by deadline before the Monday plan meeting"
        icon={ClipboardList}
        columns={columns}
        rows={rows}
        searchKeys={["id", "buyer", "styleNo", "yarn", "gauge", "stage", "colourList"]}
        filterKeys={[
          { key: "buyer", label: "Buyer" },
          { key: "stage", label: "Stage" },
        ]}
        exportName="requirement-sheet"
        canExport={can(authRole, "export")}
        initialSort={{ key: "deadline", dir: "asc" }}
      />
    </div>
  );
}
