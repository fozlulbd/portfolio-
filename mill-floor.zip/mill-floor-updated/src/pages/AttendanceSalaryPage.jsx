import React, { useMemo, useState } from "react";
import {
  Clock, Wallet, CheckCircle2, XCircle, Lock, Users, Receipt, Search, X,
  Printer, FileText, Landmark,
} from "../icons.js";
import { C, F } from "../theme/tokens.js";
import { taka, num, prettyDate, formatMobile } from "../lib/format.js";
import { computeSalary, mockMonthInputs, payrollTotals } from "../lib/payroll.js";
import { printPayslip, printPayslips } from "../lib/print.js";
import { can } from "../auth/roles.js";
import { useStore } from "../store/AppStore.jsx";
import { useFakeLoad } from "../hooks/dom.js";
import DataTable from "../components/DataTable.jsx";
import Card, { CardHeader } from "../components/ui/Card.jsx";
import Tabs from "../components/ui/Tabs.jsx";
import Avatar from "../components/ui/Avatar.jsx";
import StatusPill from "../components/ui/StatusPill.jsx";
import KpiCard from "../components/ui/KpiCard.jsx";
import EmptyState from "../components/ui/EmptyState.jsx";
import Button from "../components/ui/Button.jsx";

/* ---------------------------------------------------------------
   ATTENDANCE & SALARY — the attendance sheet is the whole register in
   one table; the salary sheet runs every row through lib/payroll so
   the gross, overtime and net always agree with the payslip in the
   employee drawer.
----------------------------------------------------------------*/
export default function AttendanceSalaryPage({ authRole, onOpenPerson }) {
  const { people, setStatus } = useStore();
  const [tab, setTab] = useState("attendance");
  const loading = useFakeLoad(420, [tab]);
  const [slipQuery, setSlipQuery] = useState("");
  const [slipPerson, setSlipPerson] = useState(null);

  const canEdit = can(authRole, "edit");
  const seeSalary = can(authRole, "seeSalary");
  const canExport = can(authRole, "export");

  /* Payroll rows are people joined with their computed month. */
  const payroll = useMemo(
    () =>
      people.map((p) => {
        const month = mockMonthInputs(p);
        const s = computeSalary(p, month);
        return {
          id: p.id,
          name: p.name,
          role: p.role,
          dept: p.dept,
          designation: p.designation,
          otHours: s.otHours,
          basic: s.basic,
          gross: s.gross,
          ot: s.ot,
          deductions: s.deductions,
          net: s.net,
          absentDays: s.absentDays,
        };
      }),
    [people]
  );

  const totals = useMemo(() => payrollTotals(payroll), [payroll]);

  const slipMatches = useMemo(() => {
    const q = slipQuery.trim().toLowerCase();
    if (!q) return [];
    return people
      .filter(
        (p) =>
          p.id.toLowerCase().includes(q) ||
          p.name.toLowerCase().includes(q) ||
          (p.mobile || "").includes(q)
      )
      .slice(0, 8);
  }, [people, slipQuery]);

  const slipPay = useMemo(() => {
    if (!slipPerson) return null;
    return computeSalary(slipPerson, mockMonthInputs(slipPerson));
  }, [slipPerson]);

  const attendanceColumns = [
    { key: "id", label: "ID", mono: true, width: 96 },
    {
      key: "name",
      label: "Name",
      render: (r) => (
        <div className="flex items-center gap-2.5">
          <Avatar name={r.name} size="sm" src={r.photo} />
          <div className="min-w-0">
            <span style={{ color: C.text }} className="block truncate">
              {r.name}
            </span>
            <span style={{ color: C.muted }} className="text-[11px] block truncate">
              {r.role} · {r.designation}
            </span>
          </div>
        </div>
      ),
    },
    { key: "dept", label: "Department" },
    { key: "line", label: "Line", hideBelow: "lg" },
    { key: "shift", label: "Shift", hideBelow: "md" },
    { key: "mobile", label: "Mobile", mono: true, hideBelow: "lg", render: (r) => formatMobile(r.mobile) },
    { key: "punchIn", label: "Punch in", mono: true, width: 88 },
    { key: "punchOut", label: "Punch out", mono: true, width: 92, hideBelow: "md" },
    { key: "status", label: "Status", render: (r) => <StatusPill status={r.status} /> },
  ];

  const salaryColumns = [
    { key: "id", label: "ID", mono: true, width: 96 },
    {
      key: "name",
      label: "Name",
      render: (r) => (
        <div className="min-w-0">
          <span style={{ color: C.text }} className="block truncate">
            {r.name}
          </span>
          <span style={{ color: C.muted }} className="text-[11px] block truncate">
            {r.role} · {r.dept}
          </span>
        </div>
      ),
    },
    { key: "basic", label: "Basic", mono: true, align: "right", render: (r) => taka(r.basic) },
    { key: "gross", label: "Gross", mono: true, align: "right", hideBelow: "md", render: (r) => taka(r.gross) },
    {
      key: "otHours",
      label: "OT hrs",
      mono: true,
      align: "right",
      hideBelow: "lg",
      width: 78,
      render: (r) => `${r.otHours} h`,
    },
    {
      key: "ot",
      label: "Overtime",
      mono: true,
      align: "right",
      render: (r) => <span style={{ color: C.green }}>+{taka(r.ot)}</span>,
    },
    {
      key: "deductions",
      label: "Deductions",
      mono: true,
      align: "right",
      hideBelow: "md",
      render: (r) => <span style={{ color: r.deductions ? C.red : C.muted }}>−{taka(r.deductions)}</span>,
    },
    {
      key: "net",
      label: "Net payable",
      mono: true,
      align: "right",
      render: (r) => (
        <span style={{ color: C.gold }} className="font-semibold">
          {taka(r.net)}
        </span>
      ),
    },
  ];

  return (
    <div className="space-y-4">
      <Tabs
        value={tab}
        onChange={setTab}
        tabs={[
          { key: "attendance", label: "Attendance sheet", count: people.length },
          { key: "salary", label: "Salary sheet", count: seeSalary ? people.length : undefined },
          { key: "payslip", label: "Payslip" },
        ]}
      />

      {tab === "attendance" && (
        <DataTable
          title="Attendance sheet — whole register"
          subtitle={`${num(people.length)} employees · ${prettyDate(new Date().toISOString())}`}
          icon={Clock}
          columns={attendanceColumns}
          rows={people}
          loading={loading}
          searchKeys={["id", "name", "dept", "designation", "mobile", "role", "line"]}
          filterKeys={[
            { key: "role", label: "Role" },
            { key: "dept", label: "Dept" },
            { key: "shift", label: "Shift" },
            { key: "status", label: "Status" },
            { key: "line", label: "Line" },
          ]}
          selectable={canEdit}
          bulkActions={
            canEdit
              ? [
                  { label: "Mark present", icon: CheckCircle2, onRun: (ids) => setStatus(ids, "Present") },
                  { label: "Mark late", icon: Clock, onRun: (ids) => setStatus(ids, "Late") },
                  { label: "Mark absent", icon: XCircle, onRun: (ids) => setStatus(ids, "Absent") },
                ]
              : []
          }
          onRowClick={onOpenPerson}
          exportName="attendance-sheet"
          canExport={canExport}
          initialSort={{ key: "id", dir: "asc" }}
        />
      )}

      {tab === "salary" &&
        (!seeSalary ? (
          <Card>
            <EmptyState
              icon={Lock}
              title="Salary figures are restricted"
              message="Your role can view attendance but not pay. Ask an HR officer or the admin for the payroll sheet."
            />
          </Card>
        ) : (
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
              <KpiCard label="Employees on payroll" value={num(payroll.length)} icon={Users} />
              <KpiCard label="Gross this month" value={taka(totals.gross)} icon={Receipt} />
              <KpiCard label="Overtime payable" value={taka(totals.ot)} icon={Clock} tone={C.green} />
              <KpiCard label="Net payable" value={taka(totals.net)} icon={Wallet} tone={C.gold} />
            </div>

            <DataTable
              title="Salary sheet — August 2026"
              subtitle="Basic 60% · house rent 50% of basic · OT at 2× hourly on 208 ordinary hours"
              icon={Wallet}
              columns={salaryColumns}
              rows={payroll}
              loading={loading}
              searchKeys={["id", "name", "dept", "role", "designation"]}
              filterKeys={[
                { key: "role", label: "Role" },
                { key: "dept", label: "Dept" },
              ]}
              exportName="salary-sheet"
              canExport={canExport}
              initialSort={{ key: "net", dir: "desc" }}
              dense
            />

            <Card>
              <CardHeader title="How these numbers are built" divider={false} />
              <p style={{ color: C.muted }} className="px-5 pb-5 text-xs leading-relaxed">
                Gross is basic plus house rent at half of basic, plus fixed medical, transport and food
                allowances. Overtime is paid at twice the ordinary hourly rate, where the hourly rate is
                basic divided by 208 ordinary hours a month. Deductions cover unpaid absence at the daily
                gross rate, the 5% employee provident fund contribution on basic, and any advance already
                drawn. Change the rules in{" "}
                <code style={{ color: C.gold, fontFamily: F.mono }}>src/lib/payroll.js</code> and every
                screen follows.
              </p>
            </Card>
          </div>
        ))}

      {tab === "payslip" &&
        (!seeSalary ? (
          <Card>
            <EmptyState
              icon={Lock}
              title="Payslips are restricted"
              message="Your role can view attendance but not pay. Ask an HR officer or the admin for a payslip."
            />
          </Card>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-[320px_1fr] gap-4 items-start">
            <Card style={{ padding: "14px 16px" }} className="space-y-3">
              <Button
                variant="outline"
                icon={Printer}
                className="w-full justify-center"
                onClick={() =>
                  printPayslips(people.map((p) => ({ person: p, pay: computeSalary(p, mockMonthInputs(p)) })))
                }
              >
                Print all {people.length} payslips
              </Button>
              <div
                style={{ background: C.panelAlt, border: `1px solid ${slipQuery ? C.gold : C.line}` }}
                className="flex items-center gap-2 px-3 py-2.5 rounded-md"
              >
                <Search size={14} style={{ color: slipQuery ? C.gold : C.muted }} />
                <input
                  value={slipQuery}
                  onChange={(e) => {
                    setSlipQuery(e.target.value);
                    setSlipPerson(null);
                  }}
                  placeholder="Search worker ID, name or mobile…"
                  style={{ background: "transparent", color: C.text }}
                  className="text-xs outline-none w-full"
                  autoFocus
                />
                {slipQuery && (
                  <button
                    type="button"
                    onClick={() => {
                      setSlipQuery("");
                      setSlipPerson(null);
                    }}
                    aria-label="Clear search"
                  >
                    <X size={12} style={{ color: C.muted }} />
                  </button>
                )}
              </div>

              {slipQuery && (
                <div className="space-y-1">
                  {slipMatches.length === 0 ? (
                    <p style={{ color: C.muted }} className="text-xs px-1 py-2">
                      No employee matches “{slipQuery}”.
                    </p>
                  ) : (
                    slipMatches.map((p) => {
                      const active = slipPerson?.id === p.id;
                      return (
                        <button
                          key={p.id}
                          type="button"
                          onClick={() => setSlipPerson(p)}
                          style={{
                            background: active ? C.goldDim : "transparent",
                            border: `1px solid ${active ? C.gold : "transparent"}`,
                          }}
                          className="w-full flex items-center gap-2.5 px-2 py-2 rounded-md text-left transition-colors hover:brightness-110"
                        >
                          <Avatar name={p.name} size="sm" src={p.photo} />
                          <div className="min-w-0">
                            <span style={{ color: active ? C.gold : C.text }} className="block text-xs truncate font-medium">
                              {p.name}
                            </span>
                            <span style={{ color: C.muted }} className="text-[11px] block truncate">
                              {p.id} · {p.designation}
                            </span>
                          </div>
                        </button>
                      );
                    })
                  )}
                </div>
              )}

              {!slipQuery && (
                <p style={{ color: C.muted }} className="text-[11px] leading-relaxed px-1">
                  Type a worker ID, name or mobile number to find their payslip. Selecting a result
                  shows a preview you can print.
                </p>
              )}
            </Card>

            {!slipPerson ? (
              <Card>
                <EmptyState
                  icon={FileText}
                  title="No payslip selected"
                  message="Search for a worker on the left, then pick them from the results to preview and print their slip."
                />
              </Card>
            ) : (
              <Card style={{ padding: 0, overflow: "hidden" }}>
                <CardHeader
                  title={`Payslip — ${slipPerson.name}`}
                  subtitle={`${slipPerson.id} · ${slipPerson.designation} · August 2026`}
                  icon={FileText}
                  right={
                    <Button variant="primary" icon={Printer} onClick={() => printPayslip(slipPerson, slipPay)}>
                      Print payslip
                    </Button>
                  }
                />
                <div className="p-5 space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <SlipRow label="Basic" value={taka(slipPay.basic)} />
                      <SlipRow label="House rent" value={taka(slipPay.houseRent)} />
                      <SlipRow label="Medical" value={taka(slipPay.medical)} />
                      <SlipRow label="Transport" value={taka(slipPay.transport)} />
                      <SlipRow label="Food" value={taka(slipPay.food)} />
                      <SlipRow label={`Overtime (${slipPay.otHours} h)`} value={`+ ${taka(slipPay.ot)}`} tone={C.green} />
                    </div>
                    <div className="space-y-1.5">
                      <SlipRow label={`Absence (${slipPay.absentDays} d)`} value={`− ${taka(slipPay.absenceDeduction)}`} tone={C.red} />
                      <SlipRow label="Provident fund" value={`− ${taka(slipPay.providentFund)}`} tone={C.red} />
                      {slipPay.advance > 0 && (
                        <SlipRow label="Advance drawn" value={`− ${taka(slipPay.advance)}`} tone={C.red} />
                      )}
                      <div style={{ borderTop: `1px solid ${C.line}` }} className="pt-1.5 mt-1.5">
                        <SlipRow label="Gross pay" value={taka(slipPay.gross + slipPay.ot)} />
                        <SlipRow label="Net payable" value={taka(slipPay.net)} tone={C.gold} strong />
                      </div>
                    </div>
                  </div>

                  <div
                    style={{ background: C.panelAlt, border: `1px solid ${C.line}` }}
                    className="rounded-md px-3.5 py-3 flex items-center gap-2.5"
                  >
                    <Landmark size={14} style={{ color: C.gold }} className="shrink-0" />
                    <div className="min-w-0">
                      <span style={{ color: C.muted }} className="text-[11px] block">
                        {slipPerson.bankAccount ? "Bank account" : slipPerson.mobileBanking ? "Mobile banking" : "Payout channel"}
                      </span>
                      <span style={{ color: C.text, fontFamily: F.mono }} className="text-xs">
                        {slipPerson.bankAccount || slipPerson.mobileBanking || "Not on file — cash in hand"}
                      </span>
                    </div>
                  </div>
                </div>
              </Card>
            )}
          </div>
        ))}
    </div>
  );
}

function SlipRow({ label, value, tone, strong = false }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <span style={{ color: C.muted }} className="text-xs">
        {label}
      </span>
      <span
        style={{ color: tone || C.text, fontFamily: F.mono }}
        className={`text-xs ${strong ? "font-semibold" : ""}`}
      >
        {value}
      </span>
    </div>
  );
}
