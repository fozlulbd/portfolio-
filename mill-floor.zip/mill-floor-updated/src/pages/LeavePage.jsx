import React, { useState } from "react";
import {
  CalendarDays, CalendarCheck, CalendarX, Check, X, PartyPopper, Lock,
} from "../icons.js";
import { C, F } from "../theme/tokens.js";
import { HOLIDAYS, LEAVE_BALANCE } from "../data/leave.js";
import { prettyDate } from "../lib/format.js";
import { can } from "../auth/roles.js";
import { useStore } from "../store/AppStore.jsx";
import Card, { CardHeader } from "../components/ui/Card.jsx";
import Tabs from "../components/ui/Tabs.jsx";
import Button from "../components/ui/Button.jsx";
import StatusPill, { Badge } from "../components/ui/StatusPill.jsx";
import Avatar from "../components/ui/Avatar.jsx";
import Stitch from "../components/ui/Stitch.jsx";
import Meter from "../components/ui/Meter.jsx";
import EmptyState from "../components/ui/EmptyState.jsx";
import KpiCard from "../components/ui/KpiCard.jsx";

/* ---------------------------------------------------------------
   LEAVE & HOLIDAY — the approve/reject buttons are the only truly
   stateful control on this page; roles without `approveLeave` get the
   same list read-only rather than a wall of dead buttons.
----------------------------------------------------------------*/
export default function LeavePage({ authRole, onOpenPerson }) {
  const { leave, decideLeave, byId } = useStore();
  const [tab, setTab] = useState("requests");
  const mayDecide = can(authRole, "approveLeave");

  const pending = leave.filter((l) => l.status === "Pending");
  const approved = leave.filter((l) => l.status === "Approved");
  const rejected = leave.filter((l) => l.status === "Rejected");

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KpiCard label="Awaiting decision" value={pending.length} icon={CalendarDays} tone={C.amber} />
        <KpiCard label="Approved this month" value={approved.length} icon={CalendarCheck} tone={C.green} />
        <KpiCard label="Rejected" value={rejected.length} icon={CalendarX} tone={C.red} />
      </div>

      <Tabs
        value={tab}
        onChange={setTab}
        tabs={[
          { key: "requests", label: "Requests", count: leave.length },
          { key: "holidays", label: "Holiday calendar", count: HOLIDAYS.length },
          { key: "balance", label: "Entitlement" },
        ]}
      />

      {tab === "requests" && (
        <Card>
          <CardHeader
            title="Leave requests"
            subtitle={
              mayDecide
                ? `${pending.length} waiting on you`
                : "Read-only — your role cannot approve leave"
            }
            icon={CalendarDays}
            right={!mayDecide ? <Badge tone={C.muted}><Lock size={10} /> read-only</Badge> : null}
          />

          {leave.length === 0 ? (
            <EmptyState title="No leave requests" />
          ) : (
            <ul>
              {leave.map((l) => {
                const person = byId(l.empId);
                return (
                  <li key={l.id} style={{ borderTop: `1px solid ${C.line}` }} className="px-5 py-4">
                    <div className="flex items-start justify-between gap-3 flex-wrap">
                      <button
                        type="button"
                        onClick={() => person && onOpenPerson(person)}
                        className="flex items-start gap-3 min-w-0 text-left"
                      >
                        <Avatar name={l.name} />
                        <div className="min-w-0">
                          <p style={{ color: C.text }} className="text-sm font-medium truncate">
                            {l.name}
                          </p>
                          <p style={{ color: C.muted, fontFamily: F.mono }} className="text-[11px] mt-0.5">
                            {l.empId} · {l.dept} · applied {prettyDate(l.appliedOn)}
                          </p>
                        </div>
                      </button>

                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge tone={C.gold}>{l.type}</Badge>
                        <Badge>
                          {l.days} day{l.days > 1 ? "s" : ""}
                        </Badge>
                        <StatusPill status={l.status} />
                      </div>
                    </div>

                    <p style={{ color: C.muted }} className="text-xs mt-2.5 leading-relaxed">
                      <span style={{ fontFamily: F.mono, color: C.text }}>
                        {prettyDate(l.from)} → {prettyDate(l.to)}
                      </span>
                      {" · "}
                      {l.reason}
                    </p>

                    {l.note && (
                      <p style={{ color: C.amber }} className="text-[11px] mt-1.5">
                        Note: {l.note}
                      </p>
                    )}

                    {mayDecide && l.status === "Pending" && (
                      <div className="flex items-center gap-2 mt-3">
                        <Button
                          variant="gold-soft"
                          icon={Check}
                          onClick={() => decideLeave(l.id, "Approved")}
                        >
                          Approve
                        </Button>
                        <Button
                          variant="danger"
                          icon={X}
                          onClick={() =>
                            decideLeave(l.id, "Rejected", "Declined by HR — discuss with your supervisor.")
                          }
                        >
                          Reject
                        </Button>
                      </div>
                    )}
                  </li>
                );
              })}
            </ul>
          )}
        </Card>
      )}

      {tab === "holidays" && (
        <Card>
          <CardHeader
            title="Holiday calendar 2026"
            subtitle="Government holidays plus the factory's own closures"
            icon={PartyPopper}
          />
          <ul className="px-5 py-4 space-y-0">
            {HOLIDAYS.map((h, i) => (
              <li key={h.date} className="flex gap-4">
                <div className="flex flex-col items-center">
                  <div
                    style={{
                      background: h.kind === "Factory" ? C.goldDim : "transparent",
                      color: C.gold,
                      border: `1px solid ${C.gold}`,
                      fontFamily: F.mono,
                    }}
                    className="w-7 h-7 rounded-full flex items-center justify-center text-[10px] shrink-0"
                  >
                    {h.date.slice(8)}
                  </div>
                  {i < HOLIDAYS.length - 1 && <div style={{ background: C.line }} className="w-px flex-1 my-1" />}
                </div>
                <div className="pb-5 flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <p style={{ color: C.text, fontFamily: F.display }} className="text-sm font-semibold">
                      {h.name}
                    </p>
                    <Badge tone={h.kind === "Factory" ? C.gold : C.muted}>{h.kind}</Badge>
                  </div>
                  <p style={{ color: C.muted, fontFamily: F.mono }} className="text-[11px] mt-0.5">
                    {prettyDate(h.date)}
                  </p>
                </div>
              </li>
            ))}
          </ul>
        </Card>
      )}

      {tab === "balance" && (
        <Card>
          <CardHeader
            title="Standard entitlement"
            subtitle="Per employee, per calendar year — Bangladesh Labour Act minimums"
          />
          <div className="px-5 py-5 space-y-4">
            {LEAVE_BALANCE.map((b) => (
              <div key={b.type}>
                <Meter
                  value={b.taken / b.entitled}
                  good={0}
                  warn={0}
                  tone={b.taken / b.entitled > 0.8 ? C.amber : C.gold}
                  label={`${b.type} leave`}
                  right={`${b.taken} of ${b.entitled} used`}
                />
              </div>
            ))}
            <Stitch style={{ margin: "6px 0" }} />
            <p style={{ color: C.muted }} className="text-xs leading-relaxed">
              Maternity leave is 16 weeks on full pay and sits outside the annual entitlement.
              Earned leave accrues at one day for every eighteen days worked and can be carried forward.
            </p>
          </div>
        </Card>
      )}
    </div>
  );
}
