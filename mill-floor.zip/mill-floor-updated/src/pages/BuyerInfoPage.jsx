import React, { useState } from "react";
import {
  Handshake, Mail, Phone, FileText, Download, Globe, Landmark, ChevronRight,
} from "../icons.js";
import { C, F } from "../theme/tokens.js";
import { BUYERS, REQUIREMENTS } from "../data/commercial.js";
import { num, fileSize } from "../lib/format.js";
import Card, { CardHeader } from "../components/ui/Card.jsx";
import KpiCard from "../components/ui/KpiCard.jsx";
import Stitch from "../components/ui/Stitch.jsx";
import { Badge } from "../components/ui/StatusPill.jsx";
import DetailList from "../components/ui/DetailList.jsx";
import Drawer from "../components/ui/Drawer.jsx";
import Button from "../components/ui/Button.jsx";

const usd = (n) => `$${num(n)}`;

/* ---------------------------------------------------------------
   BUYER INFO — buyers are cards rather than a table because the useful
   unit here is "everything about NordicKnit on one surface", not a
   sortable column of names.
----------------------------------------------------------------*/
export default function BuyerInfoPage({ onNavigate }) {
  const [open, setOpen] = useState(null);
  const openValue = BUYERS.reduce((a, b) => a + b.openValue, 0);
  const openPcs = REQUIREMENTS.reduce((a, r) => a + r.qty, 0);

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KpiCard label="Active buyers" value={BUYERS.length} sub="across three countries" icon={Handshake} />
        <KpiCard label="Open order value" value={usd(openValue)} sub="FOB, unshipped" icon={Landmark} tone={C.gold} />
        <KpiCard label="Pieces committed" value={num(openPcs)} sub="against live requirements" icon={FileText} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {BUYERS.map((b) => {
          const styles = REQUIREMENTS.filter((r) => r.buyer === b.name);
          return (
            <Card key={b.id} hover className="flex flex-col">
              <div className="px-5 py-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <h3 style={{ fontFamily: F.display, color: C.text }} className="text-base font-semibold truncate">
                      {b.name}
                    </h3>
                    <p style={{ color: C.muted }} className="text-xs mt-1 flex items-center gap-1.5">
                      <Globe size={11} /> {b.country} · since {b.since}
                    </p>
                  </div>
                  <Badge tone={C.gold}>{b.id}</Badge>
                </div>
              </div>

              <Stitch />

              <div className="px-5 py-4 space-y-2.5 flex-1">
                <p style={{ color: C.muted }} className="text-xs flex items-center gap-2 min-w-0">
                  <Mail size={12} className="shrink-0" />
                  <span className="truncate" style={{ fontFamily: F.mono }}>{b.contact}</span>
                </p>
                <p style={{ color: C.muted }} className="text-xs flex items-center gap-2">
                  <Phone size={12} className="shrink-0" />
                  <span style={{ fontFamily: F.mono }}>{b.phone}</span>
                </p>
                <p style={{ color: C.muted }} className="text-xs">
                  Attn: <span style={{ color: C.text }}>{b.person}</span>
                </p>

                <div className="pt-1.5 flex items-center gap-2 flex-wrap">
                  <Badge>{b.terms}</Badge>
                  <Badge tone={C.green}>{usd(b.openValue)} open</Badge>
                </div>

                {styles.length > 0 && (
                  <ul className="pt-2 space-y-1">
                    {styles.map((s) => (
                      <li key={s.id} style={{ color: C.muted, fontFamily: F.mono }} className="text-[11px] truncate">
                        · {s.styleNo}
                      </li>
                    ))}
                  </ul>
                )}
              </div>

              <Stitch />

              <button
                type="button"
                onClick={() => setOpen(b)}
                style={{ color: C.gold }}
                className="px-5 py-3 text-xs flex items-center justify-between hover:opacity-80 transition-opacity"
              >
                <span className="flex items-center gap-1.5">
                  <FileText size={12} /> {b.docs.length} document{b.docs.length > 1 ? "s" : ""} on file
                </span>
                <ChevronRight size={14} />
              </button>
            </Card>
          );
        })}
      </div>

      <Card>
        <CardHeader
          title="What each buyer expects of us"
          subtitle="Standing instructions worth re-reading before a pre-production meeting"
          icon={Handshake}
          right={
            onNavigate ? (
              <Button variant="outline" size="xs" onClick={() => onNavigate("requirement")}>
                Open requirements
              </Button>
            ) : null
          }
        />
        <ul className="px-5 py-4 space-y-3.5">
          {REQUIREMENTS.map((r) => (
            <li key={r.id}>
              <p style={{ color: C.text }} className="text-sm">
                {r.buyer}
                <span style={{ color: C.muted, fontFamily: F.mono }} className="text-[11px] ml-2">
                  {r.styleNo}
                </span>
              </p>
              <p style={{ color: C.muted }} className="text-xs mt-1 leading-relaxed">
                {r.note}
              </p>
            </li>
          ))}
        </ul>
      </Card>

      <Drawer
        open={!!open}
        onClose={() => setOpen(null)}
        title={open?.name || ""}
        subtitle={open ? `${open.country} · ${open.terms}` : ""}
      >
        {open && (
          <div className="space-y-6">
            <DetailList
              items={[
                { label: "Buyer code", value: open.id, mono: true },
                { label: "Trading since", value: open.since, mono: true },
                { label: "Contact person", value: open.person },
                { label: "Phone", value: open.phone, mono: true },
                { label: "Email", value: open.contact, mono: true, wide: true },
                { label: "Payment terms", value: open.terms, wide: true },
                { label: "Open value", value: usd(open.openValue), mono: true, tone: C.gold },
              ]}
            />

            <div>
              <p style={{ color: C.muted }} className="text-[11px] uppercase tracking-wide mb-2.5">
                Documents on file
              </p>
              <ul className="space-y-2">
                {open.docs.map((d) => (
                  <li
                    key={d.name}
                    style={{ background: C.panelAlt, border: `1px solid ${C.line}` }}
                    className="rounded-md px-3 py-2.5 flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <FileText size={14} style={{ color: C.gold }} className="shrink-0" />
                      <div className="min-w-0">
                        <p style={{ color: C.text }} className="text-xs truncate">
                          {d.name}
                        </p>
                        <p style={{ color: C.muted, fontFamily: F.mono }} className="text-[10px]">
                          {d.kind} · {fileSize(d.size)}
                        </p>
                      </div>
                    </div>
                    <span
                      title="Sample record — no file attached in the demo"
                      style={{ color: C.muted }}
                      className="shrink-0"
                    >
                      <Download size={13} />
                    </span>
                  </li>
                ))}
              </ul>
              <p style={{ color: C.muted }} className="text-[11px] mt-2.5 leading-relaxed">
                These are seeded records. Upload real files against an employee from the People screens —
                those come with working thumbnails and downloads.
              </p>
            </div>
          </div>
        )}
      </Drawer>
    </div>
  );
}
