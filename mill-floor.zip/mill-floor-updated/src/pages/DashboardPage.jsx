import React, { useMemo } from "react";
import {
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid,
  BarChart, Bar, ReferenceLine, Cell,
} from "recharts";
import {
  Users, CheckCircle2, AlertCircle, XCircle, TrendingUp, Factory,
  ScanFace, ArrowRight, Boxes, Truck, Megaphone, Pin,
} from "../icons.js";
import { C, F } from "../theme/tokens.js";
import { usePalette } from "../theme/ThemeProvider.jsx";
import { WEEK_TREND, HEADCOUNT_TARGET } from "../data/people.js";
import { LINE_PERFORMANCE, productionSummary, efficiency } from "../data/production.js";
import { STOCK, stockState } from "../data/inventory.js";
import { SHIPMENTS } from "../data/commercial.js";
import { GATE_LOG } from "../data/gate.js";
import { NOTICES } from "../data/notices.js";
import { DEPTS } from "../data/constants.js";
import { num, pct, prettyDate } from "../lib/format.js";
import { canSee } from "../auth/roles.js";
import { useStore } from "../store/AppStore.jsx";
import { useFakeLoad } from "../hooks/dom.js";
import Card, { CardHeader } from "../components/ui/Card.jsx";
import KpiCard from "../components/ui/KpiCard.jsx";
import Avatar from "../components/ui/Avatar.jsx";
import StatusPill, { Badge } from "../components/ui/StatusPill.jsx";
import Meter from "../components/ui/Meter.jsx";
import Stitch from "../components/ui/Stitch.jsx";
import { CardsSkeleton, ChartSkeleton } from "../components/ui/Skeleton.jsx";

/* ---------------------------------------------------------------
   DASHBOARD — the same shell for every role, but the panels a role
   cannot open are never rendered: security sees the gate feed, a
   merchandiser sees line efficiency and shipments instead.
----------------------------------------------------------------*/
export default function DashboardPage({ authRole, onNavigate, onSelectPerson }) {
  const { people, leave } = useStore();
  const palette = usePalette();
  const loading = useFakeLoad(520, []);

  const stats = useMemo(() => {
    const present = people.filter((p) => p.status === "Present").length;
    const late = people.filter((p) => p.status === "Late").length;
    const absent = people.filter((p) => p.status === "Absent").length;
    const onLeave = people.filter((p) => p.status === "On leave").length;
    return { present, late, absent, onLeave, total: people.length };
  }, [people]);

  const byDept = useMemo(
    () =>
      DEPTS.map((dept) => {
        const inDept = people.filter((p) => p.dept === dept);
        const present = inDept.filter((p) => p.status === "Present").length;
        return {
          dept,
          present,
          headcount: inDept.length,
          rate: inDept.length ? present / inDept.length : 0,
        };
      }),
    [people]
  );

  const prod = productionSummary();
  const lowStock = STOCK.filter((s) => stockState(s) !== "In stock");
  const pendingLeave = leave.filter((l) => l.status === "Pending");
  const showProduction = canSee(authRole, "production");
  const showGate = canSee(authRole, "gate");
  const showCommercial = canSee(authRole, "shipment");
  const showStore = canSee(authRole, "inventory");

  if (loading) {
    return (
      <div className="space-y-5">
        <CardsSkeleton />
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
          <Card className="xl:col-span-2" style={{ padding: 20 }}>
            <ChartSkeleton />
          </Card>
          <Card style={{ padding: 20 }}>
            <ChartSkeleton height={220} />
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* ── KPI strip ───────────────────────────────────────── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <KpiCard
          label="On the register"
          value={num(stats.total)}
          sub="across 6 role types"
          icon={Users}
          onClick={() => onNavigate("worker")}
        />
        <KpiCard
          label="Present today"
          value={num(stats.present)}
          sub={`${pct(stats.present / stats.total, 0)} of register`}
          icon={CheckCircle2}
          tone={C.green}
          delta={0.014}
        />
        <KpiCard
          label="Late punch-in"
          value={num(stats.late)}
          sub="after 08:15 at the gate"
          icon={AlertCircle}
          tone={C.amber}
          delta={-0.062}
          goodDirection="down"
        />
        <KpiCard
          label="Absent / on leave"
          value={num(stats.absent + stats.onLeave)}
          sub={`${stats.absent} absent · ${stats.onLeave} on leave`}
          icon={XCircle}
          tone={C.red}
          delta={0.008}
          goodDirection="down"
        />
      </div>

      {/* ── attendance trend + department split ─────────────── */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        <Card className="xl:col-span-2">
          <CardHeader
            title="Attendance trend — this week"
            subtitle={`Against a ${num(HEADCOUNT_TARGET)} headcount target`}
            icon={TrendingUp}
            right={<Badge tone={C.gold}>6-day week</Badge>}
          />
          <div style={{ height: 236, padding: "16px 8px 4px" }}>
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={WEEK_TREND} margin={{ top: 6, right: 12, left: -18, bottom: 0 }}>
                <defs>
                  <linearGradient id="goldFade" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={palette.gold} stopOpacity={0.35} />
                    <stop offset="100%" stopColor={palette.gold} stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke={palette.line} vertical={false} />
                <XAxis dataKey="day" stroke={palette.muted} fontSize={11} tickLine={false} axisLine={{ stroke: palette.line }} />
                <YAxis stroke={palette.muted} fontSize={11} tickLine={false} axisLine={false} domain={[3400, 4050]} />
                <Tooltip
                  contentStyle={{
                    background: palette.panelAlt,
                    border: `1px solid ${palette.line}`,
                    borderRadius: 8,
                    fontSize: 12,
                    color: palette.text,
                  }}
                  formatter={(v) => num(v)}
                />
                <ReferenceLine
                  y={HEADCOUNT_TARGET}
                  stroke={palette.muted}
                  strokeDasharray="4 4"
                  label={{ value: "target", fill: palette.muted, fontSize: 10, position: "insideTopRight" }}
                />
                <Area type="monotone" dataKey="present" stroke={palette.gold} fill="url(#goldFade)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card>
          <CardHeader title="Attendance by department" subtitle="Present as a share of headcount" />
          <div className="px-5 py-4 space-y-3.5">
            {byDept.map((d) => (
              <Meter
                key={d.dept}
                value={d.rate}
                good={0.9}
                warn={0.8}
                label={d.dept}
                right={`${d.present}/${d.headcount}`}
              />
            ))}
          </div>
        </Card>
      </div>

      {/* ── production ─────────────────────────────────────── */}
      {showProduction && (
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
          <Card className="xl:col-span-2">
            <CardHeader
              title="Line efficiency — current shift"
              subtitle={`${num(prod.output)} pcs against ${num(prod.target)} target · overall ${pct(prod.efficiency)}`}
              icon={Factory}
              right={
                <button
                  type="button"
                  onClick={() => onNavigate("production")}
                  style={{ color: C.gold }}
                  className="text-xs inline-flex items-center gap-1"
                >
                  Open floor <ArrowRight size={12} />
                </button>
              }
            />
            <div style={{ height: 220, padding: "16px 8px 4px" }}>
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={LINE_PERFORMANCE} margin={{ top: 6, right: 12, left: -22, bottom: 0 }}>
                  <CartesianGrid stroke={palette.line} vertical={false} />
                  <XAxis dataKey="line" stroke={palette.muted} fontSize={11} tickLine={false} axisLine={{ stroke: palette.line }} />
                  <YAxis stroke={palette.muted} fontSize={11} tickLine={false} axisLine={false} />
                  <Tooltip
                    contentStyle={{
                      background: palette.panelAlt,
                      border: `1px solid ${palette.line}`,
                      borderRadius: 8,
                      fontSize: 12,
                      color: palette.text,
                    }}
                    formatter={(v, k) => [num(v), k === "output" ? "Output" : "Target"]}
                  />
                  <Bar dataKey="target" fill={palette.line} radius={[3, 3, 0, 0]} />
                  <Bar dataKey="output" radius={[3, 3, 0, 0]}>
                    {LINE_PERFORMANCE.map((row) => {
                      const e = efficiency(row);
                      return (
                        <Cell
                          key={row.line}
                          fill={e >= 0.95 ? palette.green : e >= 0.85 ? palette.amber : palette.red}
                        />
                      );
                    })}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>

          <Card>
            <CardHeader title="Shift summary" subtitle="Rolled up across six lines" />
            <div className="px-5 py-4 space-y-3">
              <Row label="Output" value={`${num(prod.output)} pcs`} />
              <Row label="Target" value={`${num(prod.target)} pcs`} />
              <Row label="Operators on line" value={num(prod.operators)} />
              <Row label="Defects found" value={num(prod.defects)} tone={C.red} />
              <Row label="DHU" value={`${prod.dhu.toFixed(2)}%`} tone={C.amber} />
              <Stitch style={{ margin: "4px 0" }} />
              <Row label="Best line" value={`${prod.best.line} · ${pct(efficiency(prod.best))}`} tone={C.green} />
              <Row label="Needs help" value={`${prod.worst.line} · ${pct(efficiency(prod.worst))}`} tone={C.red} />
            </div>
          </Card>
        </div>
      )}

      {/* ── gate feed / attention ──────────────────────────── */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        {canSee(authRole, "notice") && (
          <Card
            style={{ outline: `1px solid ${C.gold}`, outlineOffset: 3, position: "relative" }}
            className="animate-fade-in"
          >
            <div
              style={{ color: C.gold, background: C.bg, border: `1px solid ${C.gold}` }}
              className="absolute -top-3 left-4 w-6 h-6 rounded-full flex items-center justify-center"
              aria-hidden="true"
            >
              <Pin size={12} strokeWidth={2.5} />
            </div>
            <CardHeader
              title="Notice board"
              subtitle={`${NOTICES.filter((n) => n.pinned).length} pinned notice(s)`}
              icon={Megaphone}
              right={
                <button
                  type="button"
                  onClick={() => onNavigate("notice")}
                  style={{ color: C.gold }}
                  className="text-xs inline-flex items-center gap-1"
                >
                  Board <ArrowRight size={12} />
                </button>
              }
            />
            <div className="px-5 py-4 space-y-3.5">
              {NOTICES.filter((n) => n.pinned)
                .concat(NOTICES.filter((n) => !n.pinned))
                .slice(0, 3)
                .map((n) => (
                  <button
                    key={n.id}
                    type="button"
                    onClick={() => onNavigate("notice")}
                    className="w-full text-left transition-opacity hover:opacity-80"
                  >
                    <p style={{ color: C.text }} className="text-xs font-medium truncate">{n.title}</p>
                    <p style={{ color: C.muted, fontFamily: F.mono }} className="text-[10px] mt-0.5">
                      {n.category} · {n.postedAt}
                    </p>
                  </button>
                ))}
            </div>
          </Card>
        )}

        {showGate && (
          <Card>
            <CardHeader
              title="Live device feed"
              subtitle="SenseFace 3A · Gate 1"
              icon={ScanFace}
              right={<StatusPill status="Online" size="xs" />}
            />
            <div className="px-5 py-4 space-y-3">
              {GATE_LOG.slice(0, 5).map((g) => {
                const person = people.find((p) => p.id === g.empId);
                return (
                  <button
                    key={g.id}
                    type="button"
                    onClick={() => person && onSelectPerson(person)}
                    className="w-full flex items-center gap-2.5 text-left transition-opacity hover:opacity-80"
                  >
                    <Avatar name={g.name} size="sm" />
                    <div className="flex-1 min-w-0">
                      <p style={{ color: C.text }} className="text-sm truncate">
                        {g.name}
                      </p>
                      <p style={{ color: C.muted, fontFamily: F.mono }} className="text-[10px]">
                        {g.empId} · {g.time} · {g.method}
                      </p>
                    </div>
                    <StatusPill status={g.dir} size="xs" />
                  </button>
                );
              })}
            </div>
          </Card>
        )}

        {showCommercial && (
          <Card>
            <CardHeader
              title="Next shipments"
              icon={Truck}
              right={
                <button
                  type="button"
                  onClick={() => onNavigate("shipment")}
                  style={{ color: C.gold }}
                  className="text-xs inline-flex items-center gap-1"
                >
                  All <ArrowRight size={12} />
                </button>
              }
            />
            <div className="px-5 py-4 space-y-3.5">
              {SHIPMENTS.map((s) => (
                <div key={s.id}>
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <p style={{ color: C.text }} className="text-xs truncate">
                      {s.buyer}
                    </p>
                    <StatusPill status={s.status} size="xs" />
                  </div>
                  <p style={{ color: C.muted, fontFamily: F.mono }} className="text-[10px]">
                    {prettyDate(s.date)} · {num(s.qty)} pcs · {s.mode}
                  </p>
                </div>
              ))}
            </div>
          </Card>
        )}

        {showStore && (
          <Card>
            <CardHeader
              title="Store alerts"
              icon={Boxes}
              subtitle={`${lowStock.length} lines at or below reorder level`}
              right={
                <button
                  type="button"
                  onClick={() => onNavigate("inventory")}
                  style={{ color: C.gold }}
                  className="text-xs inline-flex items-center gap-1"
                >
                  Store <ArrowRight size={12} />
                </button>
              }
            />
            <div className="px-5 py-4 space-y-3">
              {lowStock.slice(0, 5).map((s) => (
                <div key={s.id} className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p style={{ color: C.text }} className="text-xs truncate">
                      {s.item}
                    </p>
                    <p style={{ color: C.muted, fontFamily: F.mono }} className="text-[10px]">
                      {num(s.inStock)} {s.unit} · reorder at {num(s.reorder)}
                    </p>
                  </div>
                  <StatusPill status={stockState(s)} size="xs" />
                </div>
              ))}
            </div>
          </Card>
        )}

        {canSee(authRole, "leave") && (
          <Card>
            <CardHeader
              title="Leave awaiting decision"
              subtitle={`${pendingLeave.length} pending`}
              right={
                <button
                  type="button"
                  onClick={() => onNavigate("leave")}
                  style={{ color: C.gold }}
                  className="text-xs inline-flex items-center gap-1"
                >
                  Review <ArrowRight size={12} />
                </button>
              }
            />
            <div className="px-5 py-4 space-y-3">
              {pendingLeave.length === 0 ? (
                <p style={{ color: C.muted }} className="text-xs">
                  Nothing pending.
                </p>
              ) : (
                pendingLeave.slice(0, 5).map((l) => (
                  <div key={l.id} className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p style={{ color: C.text }} className="text-xs truncate">
                        {l.name}
                      </p>
                      <p style={{ color: C.muted, fontFamily: F.mono }} className="text-[10px]">
                        {l.type} · {l.days} d · from {prettyDate(l.from)}
                      </p>
                    </div>
                    <StatusPill status={l.status} size="xs" />
                  </div>
                ))
              )}
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}

function Row({ label, value, tone }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span style={{ color: C.muted }} className="text-xs">
        {label}
      </span>
      <span style={{ color: tone || C.text, fontFamily: F.mono }} className="text-xs font-medium">
        {value}
      </span>
    </div>
  );
}
