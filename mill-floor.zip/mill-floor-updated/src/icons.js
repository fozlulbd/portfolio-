/* ---------------------------------------------------------------
   ICONS — every lucide icon the app uses, funnelled through one
   module.

   Why this exists: importing a name that the installed lucide
   version does not export gives you `undefined`, and React then
   throws "Element type is invalid" and unmounts the entire tree —
   a blank page with no clue on screen. lucide also renamed a large
   batch of icons (AlertCircle → CircleAlert, CheckCircle2 →
   CircleCheckBig, UploadCloud → CloudUpload …), so the same code
   can break by upgrading *or* downgrading.

   `pick` tries the modern name, the legacy name, then a sensible
   stand-in, and only falls back to a neutral circle if lucide has
   none of them. A wrong-looking glyph is a cosmetic bug; an
   undefined component takes the whole app down.
----------------------------------------------------------------*/
import * as L from "lucide-react";
import React from "react";

/** Last resort, so `pick` can never return undefined. Written with
 *  createElement rather than JSX so this file can stay a plain .js
 *  module and be readable by the static checks in tests/. */
function Dot({ size = 16, strokeWidth = 2, ...rest }) {
  return React.createElement(
    "svg",
    {
      width: size,
      height: size,
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth,
      strokeLinecap: "round",
      "aria-hidden": "true",
      ...rest,
    },
    React.createElement("circle", { cx: 12, cy: 12, r: 9 })
  );
}

/** The list of names lucide could not supply — surfaced by check-icons.mjs. */
export const MISSING_ICONS = [];

function pick(...candidates) {
  for (const name of candidates) {
    const icon = L[name];
    if (typeof icon === "function" || (icon && typeof icon === "object")) return icon;
  }
  MISSING_ICONS.push(candidates[0]);
  return Dot;
}

export const AlertCircle = pick("AlertCircle", "CircleAlert");
export const AlertTriangle = pick("AlertTriangle", "TriangleAlert");
export const ArrowDown = pick("ArrowDown");
export const ArrowDownLeft = pick("ArrowDownLeft");
export const ArrowDownRight = pick("ArrowDownRight");
export const ArrowRight = pick("ArrowRight");
export const ArrowUp = pick("ArrowUp");
export const ArrowUpRight = pick("ArrowUpRight");
export const BadgeAlert = pick("BadgeAlert", "AlertCircle", "CircleAlert");
export const BadgeCheck = pick("BadgeCheck", "CheckCircle2", "CircleCheckBig");
export const Ban = pick("Ban");
export const Bell = pick("Bell");
export const Boxes = pick("Boxes");
export const Briefcase = pick("Briefcase");
export const Building2 = pick("Building2", "Building");
export const CalendarCheck = pick("CalendarCheck", "CalendarDays", "Calendar");
export const CalendarClock = pick("CalendarClock", "CalendarDays", "Calendar");
export const CalendarDays = pick("CalendarDays");
export const CalendarX = pick("CalendarX", "CalendarDays", "Calendar");
export const Camera = pick("Camera", "CameraIcon", "ImagePlus");
export const Check = pick("Check");
export const CheckCircle2 = pick("CheckCircle2", "CircleCheckBig", "CircleCheck", "Check");
export const ChevronLeft = pick("ChevronLeft");
export const ChevronRight = pick("ChevronRight");
export const ChevronsUpDown = pick("ChevronsUpDown", "ChevronDown");
export const ClipboardCheck = pick("ClipboardCheck", "ClipboardList", "Clipboard");
export const ClipboardList = pick("ClipboardList", "Clipboard");
export const Clock = pick("Clock");
export const Clock3 = pick("Clock3", "Clock");
export const CornerDownLeft = pick("CornerDownLeft", "ArrowLeft");
export const Cpu = pick("Cpu", "CircuitBoard", "Server");
export const DoorOpen = pick("DoorOpen", "Door", "LogIn");
export const Download = pick("Download");
export const Factory = pick("Factory");
export const FileImage = pick("FileImage", "Image", "ImageIcon", "FileText");
export const FileText = pick("FileText");
export const Fingerprint = pick("Fingerprint");
export const FolderOpen = pick("FolderOpen", "Folder");
export const Gauge = pick("Gauge", "Activity", "TrendingUp");
export const Globe = pick("Globe", "Globe2", "Earth");
export const Handshake = pick("Handshake", "HeartHandshake", "Users");
export const HardHat = pick("HardHat", "Shield");
export const IdCard = pick("IdCard", "Contact", "CreditCard", "BadgeCheck");
export const Info = pick("Info");
export const Landmark = pick("Landmark", "Building2", "Building");
export const Layers = pick("Layers", "Layers3", "Boxes");
export const LayoutDashboard = pick("LayoutDashboard");
export const LayoutGrid = pick("LayoutGrid", "Grid", "Grid3x3", "Boxes");
export const Lock = pick("Lock");
export const LogIn = pick("LogIn", "ArrowRight");
export const LogOut = pick("LogOut", "ArrowLeft");
export const Mail = pick("Mail");
export const Megaphone = pick("Megaphone", "Volume2", "Bell");
export const Menu = pick("Menu");
export const Moon = pick("Moon");
export const PackageCheck = pick("PackageCheck", "Package", "Check");
export const PackageX = pick("PackageX", "Package", "X");
export const Palette = pick("Palette", "Paintbrush", "Droplet");
export const PanelLeftClose = pick("PanelLeftClose", "ChevronsLeft");
export const PanelLeftOpen = pick("PanelLeftOpen", "ChevronsRight");
export const Paperclip = pick("Paperclip", "Link");
export const PartyPopper = pick("PartyPopper", "Sparkles", "Gift");
export const Pencil = pick("Pencil", "Edit", "SquarePen");
export const Percent = pick("Percent", "PercentCircle", "Hash");
export const Phone = pick("Phone");
export const Pin = pick("Pin", "MapPin");
export const Plane = pick("Plane", "Send");
export const Plus = pick("Plus", "PlusCircle");
export const Printer = pick("Printer");
export const QrCode = pick("QrCode", "ScanLine", "Scan");
export const Receipt = pick("Receipt", "FileText");
export const Save = pick("Save");
export const ShoppingCart = pick("ShoppingCart", "ShoppingBag");
export const Tags = pick("Tags", "Tag");
export const TrendingDown = pick("TrendingDown", "Activity");
export const MessageSquare = pick("MessageSquare", "MessageCircle", "Mail");
export const PhoneCall = pick("PhoneCall", "Phone");
export const Send = pick("Send", "Plane");
export const PhoneIncoming = pick("PhoneIncoming", "PhoneCall", "Phone");
export const PhoneOutgoing = pick("PhoneOutgoing", "PhoneCall", "Phone");
export const PhoneMissed = pick("PhoneMissed", "PhoneOff", "Phone");
export const RotateCw = pick("RotateCw", "RefreshCw", "Repeat");
export const ScanLine = pick("ScanLine", "Scan", "QrCode");
export const ScanFace = pick("ScanFace", "Scan", "UserRound", "User");
export const Search = pick("Search");
export const SearchX = pick("SearchX", "Search");
export const ShieldAlert = pick("ShieldAlert", "ShieldCheck", "Shield");
export const ShieldCheck = pick("ShieldCheck", "Shield");
export const Ship = pick("Ship", "Truck");
export const SlidersHorizontal = pick("SlidersHorizontal", "Sliders", "Filter");
export const Sun = pick("Sun");
export const Trash2 = pick("Trash2", "Trash");
export const TrendingUp = pick("TrendingUp");
export const Truck = pick("Truck");
export const UploadCloud = pick("UploadCloud", "CloudUpload", "Upload");
export const User = pick("User");
export const UserCheck = pick("UserCheck", "UserRoundCheck", "User");
export const UserCog = pick("UserCog", "UserRoundCog", "User");
export const UserPlus = pick("UserPlus", "UserRoundPlus", "User");
export const UserRound = pick("UserRound", "User");
export const Users = pick("Users");
export const Wallet = pick("Wallet", "CreditCard");
export const Warehouse = pick("Warehouse", "Boxes", "Package");
export const Wifi = pick("Wifi");
export const WifiOff = pick("WifiOff");
export const X = pick("X");
export const XCircle = pick("XCircle", "CircleX", "X");
