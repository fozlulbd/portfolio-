/* ---------------------------------------------------------------
   NAVIGATION & PERMISSIONS — deliberately free of React and of icon
   imports, so this module is pure data plus four predicates and can be
   unit-tested with plain `node`. The icon for each key lives in
   ./navIcons.js, which only the sidebar needs.
----------------------------------------------------------------*/
export const NAV = [
  { key: "dashboard", label: "Dashboard", group: "Overview" },
  { key: "notice", label: "Notice Board", group: "Overview" },

  { key: "worker", label: "Worker", group: "People" },
  { key: "staff", label: "Staff", group: "People" },
  { key: "manager", label: "Manager", group: "People" },
  { key: "supervisor", label: "Supervisor", group: "People" },
  { key: "security", label: "Security", group: "People" },
  { key: "bua", label: "Bua / Helper", group: "People" },
  { key: "idcards", label: "ID Cards", group: "People" },

  { key: "attendance", label: "Attendance & Salary", group: "Operations" },
  { key: "leave", label: "Leave & Holiday", group: "Operations" },
  { key: "production", label: "Production & Lines", group: "Operations" },
  { key: "quality", label: "Quality Control", group: "Operations" },
  { key: "inventory", label: "Yarn & Store", group: "Operations" },
  { key: "gate", label: "Gate & Devices", group: "Operations" },
  { key: "comms", label: "Call & Message", group: "Operations" },

  { key: "buyer", label: "Buyer Info", group: "Commercial" },
  { key: "requirement", label: "Buyer Requirement", group: "Commercial" },
  { key: "shipment", label: "Shipment Dates", group: "Commercial" },
];

export const GROUP_ORDER = ["Overview", "People", "Operations", "Commercial"];

const ALL_KEYS = NAV.map((n) => n.key);

/* ---------------------------------------------------------------
   ROLES — `pages` gates the sidebar, `can` gates the buttons. A
   supervisor can see the worker directory but not edit it; security
   sees the gate log but never a salary figure.
----------------------------------------------------------------*/
export const ROLES = {
  admin: {
    key: "admin",
    label: "Admin",
    username: "admin.hr",
    blurb: "Full access — every module, every action.",
    pages: ALL_KEYS,
    can: { create: true, edit: true, delete: true, export: true, seeSalary: true, approveLeave: true, uploadDocs: true },
  },
  hr: {
    key: "hr",
    label: "HR Officer",
    username: "hr.officer",
    blurb: "People records, attendance, payroll and leave.",
    pages: ["dashboard", "notice", "worker", "staff", "manager", "supervisor", "security", "bua", "idcards", "attendance", "leave", "gate", "comms"],
    can: { create: true, edit: true, delete: false, export: true, seeSalary: true, approveLeave: true, uploadDocs: true },
  },
  merchandiser: {
    key: "merchandiser",
    label: "Merchandiser",
    username: "merch.desk",
    blurb: "Buyers, orders, shipments and the production plan.",
    pages: ["dashboard", "notice", "buyer", "requirement", "shipment", "production", "quality", "inventory", "comms"],
    can: { create: false, edit: true, delete: false, export: true, seeSalary: false, approveLeave: false, uploadDocs: true },
  },
  supervisor: {
    key: "supervisor",
    label: "Line Supervisor",
    username: "line.super",
    blurb: "Own-floor workers, production output and quality.",
    pages: ["dashboard", "notice", "worker", "bua", "idcards", "attendance", "production", "quality", "leave"],
    can: { create: false, edit: false, delete: false, export: true, seeSalary: false, approveLeave: false, uploadDocs: false },
  },
  security: {
    key: "security",
    label: "Security",
    username: "gate.desk",
    blurb: "Gate movement, visitors and biometric devices.",
    pages: ["dashboard", "notice", "gate", "worker", "security", "idcards"],
    can: { create: false, edit: false, delete: false, export: false, seeSalary: false, approveLeave: false, uploadDocs: false },
  },
};

export const ROLE_LIST = Object.values(ROLES);

export function canSee(role, pageKey) {
  return Boolean(role?.pages?.includes(pageKey));
}

export function can(role, action) {
  return Boolean(role?.can?.[action]);
}

/** Sidebar entries this role may open, grouped in display order. */
export function navFor(role) {
  const visible = NAV.filter((n) => canSee(role, n.key));
  return GROUP_ORDER.map((group) => ({
    group,
    items: visible.filter((n) => n.group === group),
  })).filter((g) => g.items.length > 0);
}

/** First page a role should land on after signing in. */
export function landingPage(role) {
  return canSee(role, "dashboard") ? "dashboard" : role.pages[0];
}
