import {
  LayoutDashboard, Users, UserCog, ShieldCheck, Briefcase, HardHat,
  ClipboardList, Building2, FileText, Truck, Clock, Factory,
  Boxes, BadgeCheck, CalendarDays, DoorOpen, Megaphone, IdCard, PhoneCall,
} from "../icons.js";

/* The only thing in the navigation that needs React. Kept apart from
   roles.js so the permission rules stay plain data. */
export const NAV_ICONS = {
  dashboard: LayoutDashboard,
  notice: Megaphone,

  worker: Users,
  staff: UserCog,
  manager: Briefcase,
  supervisor: ClipboardList,
  security: ShieldCheck,
  bua: HardHat,
  idcards: IdCard,

  attendance: Clock,
  leave: CalendarDays,
  production: Factory,
  quality: BadgeCheck,
  inventory: Boxes,
  gate: DoorOpen,
  comms: PhoneCall,

  buyer: Building2,
  requirement: FileText,
  shipment: Truck,
};

export function navIcon(key) {
  return NAV_ICONS[key] || LayoutDashboard;
}
