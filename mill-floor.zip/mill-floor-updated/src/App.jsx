import React, { useCallback, useMemo, useState } from "react";
import { C } from "./theme/tokens.js";
import { NAV, can, canSee, landingPage } from "./auth/roles.js";
import { useStore } from "./store/AppStore.jsx";
import { useMediaQuery } from "./hooks/dom.js";

import Sidebar from "./components/Sidebar.jsx";
import Topbar from "./components/Topbar.jsx";
import Toaster from "./components/ui/Toaster.jsx";
import PersonDrawer from "./components/people/PersonDrawer.jsx";
import PersonForm from "./components/people/PersonForm.jsx";
import { ConfirmModal } from "./components/ui/Modal.jsx";

import LoginScreen from "./pages/LoginScreen.jsx";
import DashboardPage from "./pages/DashboardPage.jsx";
import NoticeBoardPage from "./pages/NoticeBoardPage.jsx";
import CommunicationPage from "./pages/CommunicationPage.jsx";
import IdCardPage from "./pages/IdCardPage.jsx";
import PeoplePage from "./pages/PeoplePage.jsx";
import AttendanceSalaryPage from "./pages/AttendanceSalaryPage.jsx";
import LeavePage from "./pages/LeavePage.jsx";
import ProductionPage from "./pages/ProductionPage.jsx";
import QualityPage from "./pages/QualityPage.jsx";
import InventoryPage from "./pages/InventoryPage.jsx";
import SecurityGatePage from "./pages/SecurityGatePage.jsx";
import BuyerInfoPage from "./pages/BuyerInfoPage.jsx";
import RequirementPage from "./pages/RequirementPage.jsx";
import ShipmentPage from "./pages/ShipmentPage.jsx";
import NoAccessPage from "./pages/NoAccessPage.jsx";

/* People pages are the same component with a different role slice. */
const PEOPLE_PAGES = ["worker", "staff", "manager", "supervisor", "security", "bua"];

/* ---------------------------------------------------------------
   APP — owns four pieces of state: who is signed in, which page is
   showing, which employee is open in the drawer, and which employee is
   open in the form. Keeping the drawer and form here (rather than
   inside each page) means global search can open any employee card
   from any screen.
----------------------------------------------------------------*/
export default function App() {
  const store = useStore();
  const [authRole, setAuthRole] = useState(null);
  const [page, setPage] = useState("dashboard");

  const [collapsed, setCollapsed] = useState(false);
  const [mobileNav, setMobileNav] = useState(false);
  const isDesktop = useMediaQuery("(min-width: 1024px)");

  const [activePerson, setActivePerson] = useState(null); // drawer
  const [editing, setEditing] = useState(null);           // { person } | { defaultRole }
  const [pendingDelete, setPendingDelete] = useState(null);

  /* ── session ─────────────────────────────────────────────── */
  const login = useCallback((role) => {
    setAuthRole(role);
    setPage(landingPage(role));
  }, []);

  const logout = useCallback(() => {
    setAuthRole(null);
    setActivePerson(null);
    setEditing(null);
    setMobileNav(false);
    setCollapsed(false);
  }, []);

  const navigate = useCallback((key) => {
    setPage(key);
    setMobileNav(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  /* The drawer always shows the live record, not the snapshot taken
     when the row was clicked — so an edit is reflected immediately. */
  const drawerPerson = activePerson ? store.byId(activePerson.id) || activePerson : null;

  const openPerson = useCallback((person) => setActivePerson(person), []);

  const nav = useMemo(() => NAV.find((n) => n.key === page), [page]);

  if (!authRole) return <LoginScreen onLogin={login} />;

  /* ── routing ─────────────────────────────────────────────── */
  function renderPage() {
    if (!canSee(authRole, page)) {
      return <NoAccessPage authRole={authRole} onHome={() => navigate(landingPage(authRole))} />;
    }

    if (PEOPLE_PAGES.includes(page)) {
      return (
        <PeoplePage
          key={page}
          roleKey={page}
          authRole={authRole}
          onOpenPerson={openPerson}
          onAdd={(roleKey) => setEditing({ defaultRole: roleKey })}
        />
      );
    }

    switch (page) {
      case "dashboard":
        return <DashboardPage authRole={authRole} onNavigate={navigate} onSelectPerson={openPerson} />;
      case "notice":
        return <NoticeBoardPage authRole={authRole} />;
      case "comms":
        return <CommunicationPage authRole={authRole} />;
      case "idcards":
        return (
          <IdCardPage
            authRole={authRole}
            onOpenPerson={openPerson}
            onAdd={(roleKey) => setEditing({ defaultRole: roleKey })}
          />
        );
      case "attendance":
        return <AttendanceSalaryPage authRole={authRole} onOpenPerson={openPerson} />;
      case "leave":
        return <LeavePage authRole={authRole} onOpenPerson={openPerson} />;
      case "production":
        return <ProductionPage authRole={authRole} />;
      case "quality":
        return <QualityPage authRole={authRole} />;
      case "inventory":
        return <InventoryPage authRole={authRole} />;
      case "gate":
        return <SecurityGatePage authRole={authRole} onOpenPerson={openPerson} />;
      case "buyer":
        return <BuyerInfoPage onNavigate={navigate} />;
      case "requirement":
        return <RequirementPage authRole={authRole} />;
      case "shipment":
        return <ShipmentPage authRole={authRole} />;
      default:
        return <NoAccessPage authRole={authRole} onHome={() => navigate(landingPage(authRole))} />;
    }
  }

  return (
    <div
      style={{
        background: C.bg,
        minHeight: "100vh",
        backgroundImage: `repeating-linear-gradient(115deg, ${C.goldDim} 0 1px, transparent 1px 34px), repeating-linear-gradient(25deg, ${C.line} 0 1px, transparent 1px 34px)`,
        backgroundAttachment: "fixed",
      }}
      className="flex"
    >
      {/* desktop rail */}
      <div className="hidden lg:block sticky top-0 h-screen">
        <Sidebar
          role={authRole}
          page={page}
          onNavigate={navigate}
          collapsed={collapsed}
          onToggleCollapse={() => setCollapsed((v) => !v)}
          onLogout={logout}
        />
      </div>

      {/* off-canvas rail on phones and tablets */}
      {mobileNav && !isDesktop && (
        <div className="fixed inset-0 z-50 flex lg:hidden">
          <div
            className="fixed inset-0 animate-fade-in"
            style={{ background: "rgba(8,10,14,.6)", backdropFilter: "blur(2px)" }}
            onClick={() => setMobileNav(false)}
          />
          <div className="relative h-full">
            <Sidebar
              role={authRole}
              page={page}
              onNavigate={navigate}
              collapsed={false}
              mobile
              onCloseMobile={() => setMobileNav(false)}
              onLogout={logout}
            />
          </div>
        </div>
      )}

      <div className="flex-1 min-w-0 flex flex-col">
        <Topbar
          title={nav?.label || "Mill Floor"}
          group={nav?.group || "Overview"}
          role={authRole}
          onOpenMobileNav={() => setMobileNav(true)}
          onNavigate={navigate}
          onSelectPerson={openPerson}
        />

        <main className="px-4 sm:px-6 py-5 flex-1 animate-fade-in">{renderPage()}</main>

        <footer
          style={{ borderTop: `1px solid ${C.line}`, color: C.muted }}
          className="px-4 sm:px-6 py-4 text-[11px] flex items-center justify-between gap-3 flex-wrap"
        >
          <span>Mill Floor · Knitwear Ltd, Unit 2 · Gazipur</span>
          <span>Demo data · changes last until you reload</span>
        </footer>
      </div>

      {/* ── one drawer, one form, shared by every page ───────── */}
      {/* Mounted only while a record is open, so the drawer's own tab
          state resets between employees. */}
      {drawerPerson && (
        <PersonDrawer
          key={drawerPerson.id}
          person={drawerPerson}
          open
          onClose={() => setActivePerson(null)}
          canEdit={can(authRole, "edit")}
          canDelete={can(authRole, "delete")}
          canSeeSalary={can(authRole, "seeSalary")}
          canUploadDocs={can(authRole, "uploadDocs")}
          actor={authRole.label}
          onEdit={(person) => setEditing({ person })}
          onDelete={(person) => setPendingDelete(person)}
          onAddDocs={(personId, docs) => store.addDocuments(personId, docs)}
          onRemoveDoc={(personId, docId, label) => store.removeDocument(personId, docId, label)}
        />
      )}
      <PersonForm
        open={Boolean(editing)}
        onClose={() => setEditing(null)}
        person={editing?.person || null}
        defaultRole={editing?.defaultRole || "worker"}
        canSeeSalary={can(authRole, "seeSalary")}
        onSave={(draft) => {
          if (editing?.person) {
            store.updatePerson(editing.person.id, draft);
            setActivePerson((prev) => (prev && prev.id === editing.person.id ? { ...prev, ...draft } : prev));
          } else {
            const created = store.addPerson(draft);
            setActivePerson(created);
          }
        }}
      />

      <ConfirmModal
        open={Boolean(pendingDelete)}
        onClose={() => setPendingDelete(null)}
        onConfirm={() => {
          store.removePeople([pendingDelete.id]);
          setActivePerson(null);
        }}
        title={`Delete ${pendingDelete?.name || "this record"}?`}
        confirmLabel="Delete record"
        message="The employee card and any attached documents are removed. In this demo the change lasts until you reload the page."
      />

      <Toaster />
    </div>
  );
}
