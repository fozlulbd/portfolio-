/* ---------------------------------------------------------------
   CHECK ICONS — the one check that needs node_modules, so it is not
   part of `npm test`. Run it after `npm install`:

       node tests/check-icons.mjs

   It loads the lucide-react that is actually installed, then reports
   any icon src/icons.js could not supply from the real export list.
   Those names fall back to a placeholder circle rather than crashing,
   so this is a cosmetic report — but it tells you exactly which names
   to update and what the current spelling is.
----------------------------------------------------------------*/
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const iconsFile = path.join(root, "src", "icons.js");

let lucide;
try {
  lucide = await import("lucide-react");
} catch {
  console.log("\n  Could not load lucide-react — run `npm install` first.\n");
  process.exit(1);
}

const exported = new Set(
  Object.keys(lucide).filter((k) => k !== "default" && /^[A-Z]/.test(k))
);

if (!fs.existsSync(iconsFile)) {
  console.log("\n  src/icons.js is missing — every icon import goes through it.\n");
  process.exit(1);
}

/* Each line looks like:  export const Foo = pick("Foo", "Bar", "Baz"); */
const entries = [
  ...fs.readFileSync(iconsFile, "utf8").matchAll(
    /export const ([A-Za-z0-9_]+) = pick\(([^)]*)\);/g
  ),
].map(([, name, args]) => ({
  name,
  candidates: [...args.matchAll(/"([A-Za-z0-9_]+)"/g)].map((m) => m[1]),
}));

/* Which files use which icon, so a report points somewhere useful. */
const usedIn = new Map();
(function walk(dir) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p);
    else if (/\.jsx?$/.test(e.name) && p !== iconsFile) {
      const src = fs.readFileSync(p, "utf8");
      for (const m of src.matchAll(/import\s*\{([^}]*)\}\s*from\s*["'][^"']*icons\.js["']/g)) {
        for (const raw of m[1].split(",")) {
          const name = raw.trim().split(/\s+as\s+/)[0].trim();
          if (!name) continue;
          if (!usedIn.has(name)) usedIn.set(name, []);
          usedIn.get(name).push(path.relative(root, p));
        }
      }
    }
  }
})(path.join(root, "src"));

/* Crude but effective closest-match on character bigrams. */
function similarity(a, b) {
  const grams = (s) => {
    const out = new Set();
    const t = s.toLowerCase();
    for (let i = 0; i < t.length - 1; i++) out.add(t.slice(i, i + 2));
    return out;
  };
  const A = grams(a);
  const B = grams(b);
  let shared = 0;
  for (const g of A) if (B.has(g)) shared++;
  return (2 * shared) / (A.size + B.size || 1);
}

function suggest(name) {
  return [...exported]
    .map((c) => [c, similarity(name, c)])
    .filter(([, s]) => s > 0.45)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 4)
    .map(([c]) => c);
}

const unmatched = entries.filter((e) => !e.candidates.some((c) => exported.has(c)));
const viaFallback = entries.filter(
  (e) => !exported.has(e.name) && e.candidates.some((c) => exported.has(c))
);

const version = (() => {
  try {
    return JSON.parse(
      fs.readFileSync(path.join(root, "node_modules", "lucide-react", "package.json"), "utf8")
    ).version;
  } catch {
    return "unknown";
  }
})();

console.log(
  `\n  lucide-react ${version} — ${exported.size} icons exported, ${entries.length} used by this app\n`
);

if (viaFallback.length) {
  console.log(`  ${viaFallback.length} name(s) resolved through a fallback candidate:`);
  for (const e of viaFallback) {
    const hit = e.candidates.find((c) => exported.has(c));
    console.log(`    ${e.name.padEnd(20)} → ${hit}`);
  }
  console.log("");
}

if (unmatched.length) {
  console.log(`  ${unmatched.length} name(s) lucide has none of — showing a placeholder circle:\n`);
  for (const e of unmatched) {
    console.log(`    ${e.name}`);
    console.log(`      tried:      ${e.candidates.join(", ")}`);
    const s = suggest(e.name);
    if (s.length) console.log(`      did you mean: ${s.join(", ")}`);
    const files = usedIn.get(e.name);
    if (files?.length) console.log(`      used in:    ${[...new Set(files)].join(", ")}`);
    console.log("");
  }
  console.log("  Add the right spelling to that icon's pick(...) list in src/icons.js.\n");
  process.exit(1);
}

console.log("  Every icon resolves to a real lucide component.\n");
