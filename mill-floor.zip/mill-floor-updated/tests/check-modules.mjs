/* Static checks that need no bundler and no node_modules.

   The sandbox this project was assembled in had no npm registry access,
   so `vite build` could not be run. These checks stand in for it and
   catch the failure modes that actually break a Vite build:

     1. an import path that does not exist on disk
     2. a named import the target module does not export
     3. a component or icon used in JSX but never imported
     4. a `C.x` / `F.x` / `palette.x` theme token that is not defined
     5. JSX elements that do not nest and close correctly
     6. a data field whose name collides with a React DOM prop

   Check 5 is a real scanner, not a regex count: it walks each file
   character by character, tracking whether it is inside code, inside a
   tag, or inside JSX text, so quotes in prose and `<Tag>` written inside
   a string literal cannot throw it off.

   Check 6 exists because of a real crash: see the note above it.

   Run with:  npm run check
*/
import { readFileSync, readdirSync, statSync, existsSync } from "node:fs";
import { join, dirname, resolve, relative, extname, sep } from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const SRC = join(ROOT, "src");

const problems = [];
const seen = new Set();
const fail = (file, msg) => {
  const line = `${relative(ROOT, file)}: ${msg}`;
  if (seen.has(line)) return;
  seen.add(line);
  problems.push(line);
};

/* ── collect source files ─────────────────────────────────────── */
function walk(dir, out = []) {
  for (const entry of readdirSync(dir)) {
    const full = join(dir, entry);
    if (statSync(full).isDirectory()) walk(full, out);
    else if ([".js", ".jsx"].includes(extname(full))) out.push(full);
  }
  return out;
}
const files = walk(SRC).sort();

/* ── strip comments so scanning does not trip over prose ──────── */
function stripComments(src) {
  return src
    .replace(/\/\*[\s\S]*?\*\//g, (m) => m.replace(/[^\n]/g, " "))
    .replace(/(^|[^:"'`\\])\/\/[^\n]*/g, (m, p1) => p1 + " ".repeat(m.length - p1.length));
}

const stripStrings = (s) =>
  s.replace(/"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'|`(?:[^`\\]|\\.)*`/g, '""');

/* ── what does a module export? ───────────────────────────────── */
const exportsOf = new Map();

function readExports(file) {
  if (exportsOf.has(file)) return exportsOf.get(file);
  const src = stripComments(readFileSync(file, "utf8"));
  const names = new Set();
  let hasDefault = false;

  for (const m of src.matchAll(/^export\s+(?:async\s+)?(?:function|class)\s+([A-Za-z_$][\w$]*)/gm)) names.add(m[1]);
  for (const m of src.matchAll(/^export\s+(?:const|let|var)\s+([A-Za-z_$][\w$]*)/gm)) names.add(m[1]);
  for (const m of src.matchAll(/^export\s*\{([^}]*)\}/gm)) {
    for (const part of m[1].split(",")) {
      const alias = part.trim().split(/\s+as\s+/).pop();
      if (alias) names.add(alias.trim());
    }
  }
  if (/^export\s+default\b/m.test(src)) hasDefault = true;

  const result = { names, hasDefault };
  exportsOf.set(file, result);
  return result;
}

/* ── parse the import statements of a file ────────────────────── */
function readImports(src) {
  const out = [];
  const re = /import\s+([\s\S]*?)\s*from\s*["']([^"']+)["']/g;
  for (const m of src.matchAll(re)) {
    const clause = m[1].trim();
    const spec = m[2];
    const named = [];
    let def = null;
    let namespace = null;

    const braced = clause.match(/\{([\s\S]*)\}/);
    if (braced) {
      for (const part of braced[1].split(",")) {
        const t = part.trim();
        if (!t) continue;
        const [orig, alias] = t.split(/\s+as\s+/).map((s) => s.trim());
        named.push({ orig, local: alias || orig });
      }
    }
    const head = clause.replace(/\{[\s\S]*\}/, "").replace(/,\s*$/, "").trim();
    if (head.startsWith("* as")) namespace = head.slice(4).trim();
    else if (head && !head.startsWith("{")) def = head.replace(/,$/, "").trim();

    out.push({ spec, named, def, namespace });
  }
  return out;
}

function resolveLocal(fromFile, spec) {
  const base = spec.startsWith("@/") ? join(SRC, spec.slice(2)) : resolve(dirname(fromFile), spec);
  for (const candidate of [base, `${base}.js`, `${base}.jsx`, join(base, "index.js"), join(base, "index.jsx")]) {
    if (existsSync(candidate) && statSync(candidate).isFile()) return candidate;
  }
  return null;
}

/* ── theme tokens ─────────────────────────────────────────────────
   Top-level keys of an object literal. Walks the body tracking nesting
   depth so only depth-0 `key:` pairs count, and blanks string literals
   first so a comma or colon inside a font stack cannot be mistaken for
   structure. (The previous regex version silently dropped the first key
   of every object, which made C.bg and F.display look undefined.) */
function objectKeys(src, declaration) {
  const start = src.indexOf(declaration);
  if (start === -1) return null;
  const open = src.indexOf("{", start);
  if (open === -1) return null;

  let depth = 0;
  let end = -1;
  for (let i = open; i < src.length; i += 1) {
    if (src[i] === "{") depth += 1;
    else if (src[i] === "}") {
      depth -= 1;
      if (depth === 0) { end = i; break; }
    }
  }
  if (end === -1) return null;

  const body = stripStrings(src.slice(open + 1, end));
  const keys = new Set();
  let nest = 0;
  let token = "";
  for (const ch of body) {
    if ("{[(".includes(ch)) { nest += 1; token = ""; continue; }
    if ("}])".includes(ch)) { nest -= 1; token = ""; continue; }
    if (nest > 0) continue;
    if (ch === ":") {
      const key = token.trim();
      if (/^[A-Za-z_$][\w$]*$/.test(key)) keys.add(key);
      token = "";
      continue;
    }
    if (ch === ",") { token = ""; continue; }
    token += ch;
  }
  return keys;
}

const tokensSrc = stripComments(readFileSync(join(SRC, "theme/tokens.js"), "utf8"));
const C_KEYS = objectKeys(tokensSrc, "export const C") || new Set();
const F_KEYS = objectKeys(tokensSrc, "export const F") || new Set();
const PALETTE_KEYS = objectKeys(tokensSrc, "dark:") || new Set();

for (const [label, keys] of [["C", C_KEYS], ["F", F_KEYS], ["PALETTE.dark", PALETTE_KEYS]]) {
  if (!keys.size) problems.push(`checker could not read the keys of ${label} from src/theme/tokens.js`);
}

/* ── JSX scanner ──────────────────────────────────────────────────
   Modes: "code" (JS), "tag" (between `<Foo` and its `>`), "text" (the
   children of an open element). Strings, template literals, comments
   and regex literals are only recognised in code and tag modes — inside
   JSX text an apostrophe is just an apostrophe. */
const EXPR_START = new Set(["(", "{", "[", ",", "=", ":", "?", "&", "|", "!", ";", ">", "\n", "+", "*", "%", undefined]);
/* `return <div>` on one line: the char before `<` is a letter, so the
   position has to be judged from the whole preceding word instead. */
const EXPR_KEYWORDS = new Set(["return", "case", "yield", "await", "typeof", "in", "of", "do", "else", "throw"]);

function prevSignificant(src, i) {
  for (let k = i - 1; k >= 0; k -= 1) {
    if (src[k] === " " || src[k] === "\t" || src[k] === "\r") continue;
    return src[k];
  }
  return undefined;
}

function prevWord(src, i) {
  let end = i;
  while (end > 0 && /\s/.test(src[end - 1])) end -= 1;
  let start = end;
  while (start > 0 && /[A-Za-z_$]/.test(src[start - 1])) start -= 1;
  return src.slice(start, end);
}

const canStartExpression = (src, i) =>
  EXPR_START.has(prevSignificant(src, i)) || EXPR_KEYWORDS.has(prevWord(src, i));

function scanJsx(src) {
  const errors = [];
  const modes = [{ kind: "code", braces: 0 }];
  const open = [];
  let i = 0;
  let line = 1;

  const top = () => modes[modes.length - 1];
  const readName = (from) => {
    let k = from;
    while (k < src.length && /[A-Za-z0-9_$.:-]/.test(src[k])) k += 1;
    return src.slice(from, k);
  };
  const skipQuoted = (quote) => {
    i += 1;
    while (i < src.length) {
      if (src[i] === "\\") { i += 2; continue; }
      if (src[i] === "\n") line += 1;
      if (src[i] === quote) { i += 1; return; }
      i += 1;
    }
    errors.push({ line, message: `unterminated ${quote === "`" ? "template literal" : "string"}` });
  };

  while (i < src.length) {
    const mode = top();
    const c = src[i];

    if (c === "\n") { line += 1; i += 1; continue; }

    /* ---- JSX text: only `<` and `{` mean anything ---- */
    if (mode.kind === "text") {
      if (c === "{") { modes.push({ kind: "code", braces: 0 }); i += 1; continue; }
      if (c !== "<") { i += 1; continue; }
    } else {
      /* ---- code and tag: skip comments, strings, regexes ---- */
      if (c === "/" && src[i + 1] === "/") { while (i < src.length && src[i] !== "\n") i += 1; continue; }
      if (c === "/" && src[i + 1] === "*") {
        i += 2;
        while (i < src.length && !(src[i] === "*" && src[i + 1] === "/")) { if (src[i] === "\n") line += 1; i += 1; }
        i += 2;
        continue;
      }
      if (c === '"' || c === "'" || c === "`") { skipQuoted(c); continue; }
      /* Regex literals only in code mode — inside a tag a `/` is the
         slash of `/>`, and its predecessor is usually `}` or `"`, which
         would otherwise look exactly like a regex position. */
      if (mode.kind === "code" && c === "/" && EXPR_START.has(prevSignificant(src, i))) {
        i += 1;
        let inClass = false;
        while (i < src.length) {
          if (src[i] === "\\") { i += 2; continue; }
          if (src[i] === "[") inClass = true;
          else if (src[i] === "]") inClass = false;
          else if (src[i] === "/" && !inClass) { i += 1; break; }
          else if (src[i] === "\n") { line += 1; break; }
          i += 1;
        }
        continue;
      }
    }

    if (mode.kind === "tag") {
      if (c === "/" && src[i + 1] === ">") { modes.pop(); i += 2; continue; }
      if (c === ">") {
        modes.pop();
        modes.push({ kind: "text", name: mode.name });
        open.push({ name: mode.name, line: mode.line });
        i += 1;
        continue;
      }
      if (c === "{") { modes.push({ kind: "code", braces: 0 }); i += 1; continue; }
      i += 1;
      continue;
    }

    if (mode.kind === "code") {
      if (c === "{") { mode.braces += 1; i += 1; continue; }
      if (c === "}") {
        if (mode.braces === 0 && modes.length > 1) { modes.pop(); i += 1; continue; }
        mode.braces = Math.max(0, mode.braces - 1);
        i += 1;
        continue;
      }
    }

    /* ---- a `<` that might start a tag ---- */
    if (c === "<") {
      if (src[i + 1] === "/") {
        const name = readName(i + 2);
        const close = src.indexOf(">", i + 2);
        i = close === -1 ? src.length : close + 1;
        const parent = top();
        if (parent.kind !== "text" || !open.length) {
          errors.push({ line, message: `</${name}> closes an element that was never opened` });
        } else {
          const expected = open.pop();
          modes.pop();
          if (expected.name !== name) {
            errors.push({
              line,
              message: `</${name}> closes <${expected.name}> opened on line ${expected.line}`,
            });
          }
        }
        continue;
      }
      const startsTag = /[A-Za-z_$>]/.test(src[i + 1] || "");
      const allowed = mode.kind === "text" || canStartExpression(src, i);
      if (startsTag && allowed) {
        const name = readName(i + 1);
        modes.push({ kind: "tag", name, line });
        i += 1 + name.length;
        continue;
      }
    }

    i += 1;
  }

  for (const el of open) errors.push({ line: el.line, message: `<${el.name}> is never closed` });
  return errors;
}

/* ── per-file checks ──────────────────────────────────────────── */
for (const file of files) {
  const raw = readFileSync(file, "utf8");
  const src = stripComments(raw);
  const imports = readImports(src);

  /* 1 + 2 — import paths and named exports */
  const scope = new Set();
  for (const imp of imports) {
    for (const n of imp.named) scope.add(n.local);
    if (imp.def) scope.add(imp.def);
    if (imp.namespace) scope.add(imp.namespace);

    const isLocal = imp.spec.startsWith(".") || imp.spec.startsWith("@/");
    if (!isLocal) continue;

    const target = resolveLocal(file, imp.spec);
    if (!target) {
      fail(file, `import path does not resolve: "${imp.spec}"`);
      continue;
    }
    if (extname(imp.spec) === "") fail(file, `extensionless local import: "${imp.spec}"`);

    const ex = readExports(target);
    for (const n of imp.named) {
      if (!ex.names.has(n.orig)) fail(file, `"${imp.spec}" does not export { ${n.orig} }`);
    }
    if (imp.def && !ex.hasDefault) {
      fail(file, `"${imp.spec}" has no default export (imported as ${imp.def})`);
    }
  }

  /* locally declared identifiers count as in scope */
  for (const m of src.matchAll(/(?:^|\s)(?:export\s+)?(?:async\s+)?function\s+([A-Za-z_$][\w$]*)/g)) scope.add(m[1]);
  for (const m of src.matchAll(/(?:^|\s)(?:export\s+)?(?:const|let|var|class)\s+([A-Za-z_$][\w$]*)/g)) scope.add(m[1]);
  for (const m of src.matchAll(/(?:const|let)\s*\{([^}]*)\}\s*=/g)) {
    for (const part of m[1].split(",")) {
      const alias = part.trim().split(/[:=]/).pop().trim();
      if (/^[A-Za-z_$][\w$]*$/.test(alias)) scope.add(alias);
    }
  }
  /* render props destructured as `{ icon: Icon }` and the like */
  for (const m of src.matchAll(/([A-Za-z_$][\w$]*)\s*:\s*([A-Z][\w$]*)\s*(?:=[^,}]*)?[,}]/g)) scope.add(m[2]);

  const KNOWN_GLOBALS = new Set([
    "Array", "Object", "String", "Number", "Boolean", "Math", "JSON", "Date", "Set", "Map",
    "Promise", "Blob", "URL", "File", "FileReader", "Intl", "Error", "RegExp",
  ]);

  /* 3 — components and icons used but not imported */
  const used = new Set();
  for (const m of stripStrings(src).matchAll(/<([A-Z][\w$]*)/g)) used.add(m[1]);
  for (const m of stripStrings(src).matchAll(/\b(?:icon|as|Icon)\s*[:=]\s*\{?\s*([A-Z][\w$]*)\s*\}?/g)) used.add(m[1]);
  for (const name of used) {
    if (!scope.has(name) && !KNOWN_GLOBALS.has(name)) {
      fail(file, `<${name}> is used but never imported or declared`);
    }
  }

  /* 4 — theme tokens */
  const noStrings = stripStrings(src);
  if (C_KEYS.size) {
    for (const m of noStrings.matchAll(/\bC\.([A-Za-z_$][\w$]*)/g)) {
      if (!C_KEYS.has(m[1])) fail(file, `C.${m[1]} is not defined in theme/tokens.js`);
    }
  }
  if (F_KEYS.size) {
    for (const m of noStrings.matchAll(/\bF\.([A-Za-z_$][\w$]*)/g)) {
      if (!F_KEYS.has(m[1])) fail(file, `F.${m[1]} is not defined in theme/tokens.js`);
    }
  }
  if (PALETTE_KEYS.size) {
    for (const m of noStrings.matchAll(/\bpalette\.([A-Za-z_$][\w$]*)/g)) {
      if (!PALETTE_KEYS.has(m[1])) fail(file, `palette.${m[1]} is not in PALETTE`);
    }
  }

  /* 5 — JSX nesting */
  if (extname(file) === ".jsx") {
    for (const e of scanJsx(raw)) fail(file, `line ${e.line}: ${e.message}`);
  }
}

/* ── data fields that collide with React DOM props ─────────────────
   Recharts spreads each data row onto the SVG shape it draws, so a
   row with `style: "NK-118"` reaches React as style="NK-118" and
   throws "The `style` prop expects a mapping from style properties to
   values, not a string" — which unmounts the whole tree. `style` is a
   natural garment field name (style no. on the job card), so this is
   easy to reintroduce; the field is called `styleNo` for that reason.
----------------------------------------------------------------*/
const RESERVED_FIELDS = {
  style: 'rename it "styleNo" — that is what the garment style number is called everywhere else in here',
  className: 'rename it "cssClass" or fold it into a status field',
  children: 'rename it "items" or "childRows"',
  ref: 'rename it "reference" or "refNo"',
  dangerouslySetInnerHTML: "drop it — data should never carry raw HTML",
};

for (const file of files) {
  if (!file.includes(`${sep}data${sep}`)) continue;
  const body = stripComments(readFileSync(file, "utf8"));
  const lines = body.split("\n");
  lines.forEach((line, i) => {
    for (const [field, advice] of Object.entries(RESERVED_FIELDS)) {
      if (new RegExp(`(^|[,{[]|\\s)${field}\\s*:`).test(line)) {
        fail(
          file,
          `line ${i + 1}: data field named "${field}" — React reserves that prop name, and ` +
            `Recharts spreads whole data rows onto the SVG shapes it draws, so charting this ` +
            `row would throw and unmount the app. ${advice}.`
        );
      }
    }
  });
}

/* ── entry points exist ───────────────────────────────────────── */
for (const required of ["src/main.jsx", "src/App.jsx", "index.html", "vite.config.js", "tailwind.config.js", "postcss.config.js", "package.json"]) {
  if (!existsSync(join(ROOT, required))) problems.push(`missing project file: ${required}`);
}

/* every page the shell routes to exists as a file */
const appSrc = readFileSync(join(SRC, "App.jsx"), "utf8");
for (const m of appSrc.matchAll(/from\s+"\.\/pages\/([A-Za-z]+)\.jsx"/g)) {
  if (!existsSync(join(SRC, "pages", `${m[1]}.jsx`))) problems.push(`App.jsx routes to a missing page: ${m[1]}`);
}

/* index.html must load the real entry point */
const indexHtml = readFileSync(join(ROOT, "index.html"), "utf8");
if (!/src=["']\/src\/main\.jsx["']/.test(indexHtml)) {
  problems.push("index.html does not load /src/main.jsx");
}

/* ── report ───────────────────────────────────────────────────── */
if (problems.length) {
  console.error(`\n  ${problems.length} problem${problems.length > 1 ? "s" : ""} found across ${files.length} source files\n`);
  for (const p of problems) console.error(`  ✗ ${p}`);
  console.error("");
  process.exit(1);
}
console.log(`\n  ${files.length} source files check out — imports resolve, exports match, tokens exist, JSX nests correctly\n`);
