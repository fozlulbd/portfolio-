/* Plain-node test runner. The logic-bearing helpers live in .js files
   with no JSX and no DOM, so they can be imported and asserted directly
   without vitest, jsdom or a transform step.

   Run with:  npm test
*/
import assert from "node:assert/strict";

import {
  search, filterBy, sortBy, paginate, buildView, distinct,
} from "../src/lib/table.js";
import { toCSV, stampedName } from "../src/lib/csv.js";
import {
  computeSalary, overtimeAmount, hourlyRate, mockMonthInputs, payrollTotals,
  OT_MULTIPLIER, ORDINARY_HOURS,
} from "../src/lib/payroll.js";
import {
  taka, num, pct, initials, prettyDate, tenure, fileSize,
  formatMobile, isValidBdMobile, isValidNid,
} from "../src/lib/format.js";
import {
  makeAllPeople, nextId, emptyPerson, COUNTS,
} from "../src/data/people.js";
import { stockState, stockSummary } from "../src/data/inventory.js";
import { efficiency, productionSummary } from "../src/data/production.js";
import { paretoData, qualitySummary } from "../src/data/quality.js";
import { ROLES, canSee, can, navFor, landingPage } from "../src/auth/roles.js";
import { code39Svg, code39Supported } from "../src/lib/barcode.js";

/* ── tiny harness ─────────────────────────────────────────────── */
let passed = 0;
const failures = [];

function test(name, fn) {
  try {
    fn();
    passed += 1;
  } catch (err) {
    failures.push({ name, err });
  }
}

/* ── fixtures ─────────────────────────────────────────────────── */
const ROWS = [
  { id: "WK-1000", name: "Karim Mia", dept: "Knitting", basic: 9000, punchOut: "17:02" },
  { id: "WK-1001", name: "Salma Begum", dept: "Linking", basic: 12000, punchOut: "--:--" },
  { id: "WK-1002", name: "Rahim Ahmed", dept: "Knitting", basic: 11000, punchOut: "17:10" },
  { id: "WK-1003", name: "nasrin akter", dept: "Finishing", basic: 9500, punchOut: "" },
];

/* ── lib/table ────────────────────────────────────────────────── */
test("search is case-insensitive and spans the given keys", () => {
  assert.equal(search(ROWS, "KARIM", ["name"]).length, 1);
  assert.equal(search(ROWS, "nasrin", ["name"]).length, 1);
  assert.equal(search(ROWS, "knitting", ["dept"]).length, 2);
  assert.equal(search(ROWS, "wk-100", ["id"]).length, 4);
});

test("search with an empty query returns the original array untouched", () => {
  assert.equal(search(ROWS, "   ", ["name"]), ROWS);
});

test("search does not match keys it was not given", () => {
  assert.equal(search(ROWS, "Knitting", ["name"]).length, 0);
});

test("filterBy applies every active constraint and ignores empty ones", () => {
  assert.equal(filterBy(ROWS, { dept: "Knitting" }).length, 2);
  assert.equal(filterBy(ROWS, { dept: "Knitting", name: "" }).length, 2);
  assert.equal(filterBy(ROWS, { dept: "all" }).length, 4);
  assert.equal(filterBy(ROWS, { dept: "Knitting", name: "Karim Mia" }).length, 1);
  assert.equal(filterBy(ROWS, {}), ROWS);
});

test("sortBy compares numbers numerically, not lexically", () => {
  const asc = sortBy(ROWS, "basic", "asc").map((r) => r.basic);
  assert.deepEqual(asc, [9000, 9500, 11000, 12000]);
  const desc = sortBy(ROWS, "basic", "desc").map((r) => r.basic);
  assert.deepEqual(desc, [12000, 11000, 9500, 9000]);
});

test("sortBy is case-insensitive on text", () => {
  const names = sortBy(ROWS, "name", "asc").map((r) => r.name);
  assert.deepEqual(names, ["Karim Mia", "nasrin akter", "Rahim Ahmed", "Salma Begum"]);
});

test("sortBy sinks blanks and --:-- placeholders in both directions", () => {
  const asc = sortBy(ROWS, "punchOut", "asc").map((r) => r.punchOut);
  const desc = sortBy(ROWS, "punchOut", "desc").map((r) => r.punchOut);
  assert.deepEqual(asc.slice(0, 2), ["17:02", "17:10"]);
  assert.deepEqual(desc.slice(0, 2), ["17:10", "17:02"]);
  assert.deepEqual(asc.slice(2), ["--:--", ""]);
  assert.deepEqual(desc.slice(2), ["--:--", ""]);
});

test("sortBy is stable for equal keys and never mutates the input", () => {
  const tied = [
    { id: "a", dept: "X" }, { id: "b", dept: "X" }, { id: "c", dept: "X" },
  ];
  assert.deepEqual(sortBy(tied, "dept", "asc").map((r) => r.id), ["a", "b", "c"]);
  assert.deepEqual(sortBy(tied, "dept", "desc").map((r) => r.id), ["a", "b", "c"]);
  const before = ROWS.map((r) => r.id);
  sortBy(ROWS, "basic", "desc");
  assert.deepEqual(ROWS.map((r) => r.id), before);
});

test("sortBy without a key is a no-op", () => {
  assert.equal(sortBy(ROWS, ""), ROWS);
});

test("paginate reports human 1-based from/to and clamps out-of-range pages", () => {
  const p1 = paginate(ROWS, 1, 2);
  assert.deepEqual([p1.page, p1.pageCount, p1.from, p1.to, p1.total], [1, 2, 1, 2, 4]);
  const p9 = paginate(ROWS, 9, 2);
  assert.equal(p9.page, 2);
  assert.deepEqual([p9.from, p9.to], [3, 4]);
  const p0 = paginate(ROWS, 0, 2);
  assert.equal(p0.page, 1);
});

test("paginate on an empty list stays coherent", () => {
  const p = paginate([], 3, 10);
  assert.deepEqual([p.rows.length, p.page, p.pageCount, p.from, p.to, p.total], [0, 1, 1, 0, 0, 0]);
});

test("buildView runs search, then filter, then sort, then page", () => {
  const v = buildView(ROWS, {
    query: "a",                 // matches all four names
    searchKeys: ["name"],
    filters: { dept: "Knitting" },
    sortKey: "basic",
    sortDir: "desc",
    page: 1,
    pageSize: 1,
  });
  assert.equal(v.matched, 2);
  assert.equal(v.pageCount, 2);
  assert.equal(v.rows.length, 1);
  assert.equal(v.rows[0].basic, 11000);
  assert.equal(v.all.length, 2);
});

test("buildView with no options returns the first page unchanged", () => {
  const v = buildView(ROWS);
  assert.equal(v.total, 4);
  assert.equal(v.matched, 4);
});

test("distinct is de-duplicated, sorted and drops blanks", () => {
  assert.deepEqual(distinct(ROWS, "dept"), ["Finishing", "Knitting", "Linking"]);
  assert.deepEqual(distinct(ROWS, "punchOut"), ["--:--", "17:02", "17:10"]);
});

/* ── lib/csv ──────────────────────────────────────────────────── */
test("toCSV writes a header row from the column labels", () => {
  const csv = toCSV([{ a: 1, b: 2 }], [{ key: "a", label: "Alpha" }, { key: "b", label: "Beta" }]);
  assert.equal(csv, "Alpha,Beta\r\n1,2");
});

test("toCSV quotes cells containing commas, quotes or newlines", () => {
  const csv = toCSV(
    [{ name: 'Mia, Karim', note: 'said "yes"', addr: "line1\nline2" }],
    [{ key: "name", label: "Name" }, { key: "note", label: "Note" }, { key: "addr", label: "Address" }]
  );
  assert.equal(csv, 'Name,Note,Address\r\n"Mia, Karim","said ""yes""","line1\nline2"');
});

test("toCSV neutralises spreadsheet formula injection", () => {
  const csv = toCSV([{ n: "=SUM(A1:A9)" }, { n: "+1" }, { n: "@cmd" }, { n: "-5" }], [{ key: "n", label: "N" }]);
  const lines = csv.split("\r\n");
  assert.equal(lines[1], "'=SUM(A1:A9)");
  assert.equal(lines[2], "'+1");
  assert.equal(lines[3], "'@cmd");
  assert.equal(lines[4], "'-5");
});

test("toCSV renders missing values as empty cells", () => {
  const csv = toCSV([{ a: null }, { a: undefined }, {}], [{ key: "a", label: "A" }]);
  assert.equal(csv, "A\r\n\r\n\r\n");
});

test("toCSV on an empty row set still emits the header", () => {
  assert.equal(toCSV([], [{ key: "a", label: "A" }]), "A");
});

test("stampedName appends an ISO date and the csv extension", () => {
  assert.equal(stampedName("worker-directory", new Date("2026-08-24T09:00:00Z")), "worker-directory-2026-08-24.csv");
});

/* ── lib/payroll ──────────────────────────────────────────────── */
test("hourly rate is basic over the ordinary-hours constant", () => {
  assert.equal(ORDINARY_HOURS, 208);
  assert.equal(OT_MULTIPLIER, 2);
  assert.equal(hourlyRate(10400), 50);
  assert.equal(hourlyRate(undefined), 0);
});

test("overtime pays double the hourly rate", () => {
  assert.equal(overtimeAmount(10400, 10), 1000);
  assert.equal(overtimeAmount(10400, 0), 0);
});

test("computeSalary builds gross from basic, house rent and fixed allowances", () => {
  const s = computeSalary({ basic: 10000 }, { otHours: 0, absentDays: 0, advance: 0 });
  assert.equal(s.houseRent, 5000);
  assert.equal(s.gross, 10000 + 5000 + 750 + 450 + 1250);
  assert.equal(s.providentFund, 500);
  assert.equal(s.deductions, 500);
  assert.equal(s.net, s.gross - 500);
});

test("computeSalary deducts absence at the daily gross rate", () => {
  const base = computeSalary({ basic: 10000 }, {});
  const withAbsence = computeSalary({ basic: 10000 }, { absentDays: 2 });
  assert.equal(withAbsence.absenceDeduction, Math.round((base.gross / 26) * 2));
  assert.equal(withAbsence.net, base.gross - withAbsence.deductions);
});

test("computeSalary adds overtime after deductions and honours the advance", () => {
  const s = computeSalary({ basic: 10400 }, { otHours: 20, advance: 1500 });
  assert.equal(s.ot, 2000);
  assert.equal(s.deductions, 520 + 1500);
  assert.equal(s.net, s.gross + s.ot - s.deductions);
});

test("computeSalary tolerates a missing or junk basic", () => {
  const s = computeSalary({}, {});
  assert.equal(s.basic, 0);
  assert.equal(s.gross, 2450);
  assert.equal(Number.isFinite(s.net), true);
});

test("mockMonthInputs is deterministic and within sane bounds", () => {
  const p = { id: "WK-1000" };
  const a = mockMonthInputs(p);
  const b = mockMonthInputs(p);
  assert.deepEqual(a, b);
  assert.ok(a.otHours >= 12 && a.otHours < 52, `otHours out of range: ${a.otHours}`);
  assert.ok(a.absentDays >= 0 && a.absentDays <= 2);
  assert.equal(a.workingDays, 26);
});

test("payrollTotals sums the four money columns", () => {
  const t = payrollTotals([
    { gross: 100, ot: 10, deductions: 5, net: 105 },
    { gross: 200, ot: 20, deductions: 10, net: 210 },
  ]);
  assert.deepEqual(t, { gross: 300, ot: 30, deductions: 15, net: 315 });
  assert.deepEqual(payrollTotals([]), { gross: 0, ot: 0, deductions: 0, net: 0 });
});

test("a real employee's payslip reconciles: gross + ot - deductions = net", () => {
  const people = makeAllPeople();
  for (const p of people.slice(0, 25)) {
    const s = computeSalary(p, mockMonthInputs(p));
    assert.equal(s.net, s.gross + s.ot - s.deductions, `mismatch on ${p.id}`);
    assert.equal(s.deductions, s.absenceDeduction + s.providentFund + s.advance);
    assert.ok(s.net > 0, `${p.id} nets nothing`);
  }
});

/* ── lib/format ───────────────────────────────────────────────── */
test("money and number formatting group thousands", () => {
  assert.equal(taka(12400), "৳12,400");
  assert.equal(taka(0), "৳0");
  assert.equal(taka("9500.6"), "৳9,501");
  assert.equal(taka(null), "৳0");
  assert.equal(num(1234567), "1,234,567");
});

test("percentages honour the digit argument", () => {
  assert.equal(pct(0.8734), "87.3%");
  assert.equal(pct(0.8734, 0), "87%");
  assert.equal(pct(0.8734, 2), "87.34%");
  assert.equal(pct(undefined), "0.0%");
});

test("initials take at most two letters", () => {
  assert.equal(initials("Karim Mia"), "KM");
  assert.equal(initials("md karim mia"), "MK");
  assert.equal(initials("Karim"), "K");
  assert.equal(initials(""), "");
});

test("dates render day-month-year and fail soft", () => {
  assert.equal(prettyDate("2019-04-11"), "11 Apr 2019");
  assert.equal(prettyDate(""), "—");
  assert.equal(prettyDate("not-a-date"), "—");
});

test("tenure switches from months to years at the one-year mark", () => {
  const now = new Date("2026-08-24T00:00:00Z");
  assert.equal(tenure("2020-08-24", now), "6.0 yrs");
  assert.equal(tenure("2026-05-24", now), "3 mo");
  assert.equal(tenure("2027-01-01", now), "—");
  assert.equal(tenure("", now), "—");
});

test("file sizes step through B, KB and MB", () => {
  assert.equal(fileSize(512), "512 B");
  assert.equal(fileSize(20480), "20.0 KB");
  assert.equal(fileSize(3_100_000), "3.0 MB");
  assert.equal(fileSize(0), "0 B");
});

test("BD mobile validation accepts the real operator prefixes only", () => {
  for (const ok of ["01712345678", "+8801812345678", "8801912345678", "01312345678", "017 1234 5678", "017-1234-5678"]) {
    assert.equal(isValidBdMobile(ok), true, `should accept ${ok}`);
  }
  for (const bad of ["01212345678", "0171234567", "017123456789", "1712345678", "", "abcdefghijk"]) {
    assert.equal(isValidBdMobile(bad), false, `should reject ${bad}`);
  }
});

test("NID validation accepts the three formats in circulation", () => {
  assert.equal(isValidNid("1234567890"), true);
  assert.equal(isValidNid("1234567890123"), true);
  assert.equal(isValidNid("12345678901234567"), true);
  // Separators are stripped before counting, so a typed-in NID with
  // spaces or dashes is still accepted.
  assert.equal(isValidNid("1990 1234567890123"), true);
  assert.equal(isValidNid("1234-5678-90"), true);
  // 12 digits is not one of the issued formats.
  assert.equal(isValidNid("123456789012"), false);
  assert.equal(isValidNid("12345"), false);
  assert.equal(isValidNid(""), false);
});

test("mobile display formatting is stable and degrades gracefully", () => {
  assert.equal(formatMobile("01712345678"), "+880 1712-345678");
  assert.equal(formatMobile("8801712345678"), "+880 1712-345678");
  assert.equal(formatMobile("123"), "123");
  assert.equal(formatMobile(""), "—");
});

/* ── data/people ──────────────────────────────────────────────── */
test("the seeded register has the expected head count per role", () => {
  const people = makeAllPeople();
  const expected = Object.values(COUNTS).reduce((a, n) => a + n, 0);
  assert.equal(people.length, expected);
  for (const [roleKey, n] of Object.entries(COUNTS)) {
    assert.equal(people.filter((p) => p.roleKey === roleKey).length, n, `${roleKey} count`);
  }
});

test("every seeded employee carries the fields the UI depends on", () => {
  const people = makeAllPeople();
  const required = [
    "id", "roleKey", "role", "name", "designation", "dept", "shift", "employment",
    "mobile", "joinDate", "nid", "bloodGroup", "district", "emergencyName",
    "emergencyMobile", "basic", "status", "punchIn", "punchOut", "documents",
  ];
  for (const p of people) {
    for (const key of required) {
      assert.ok(p[key] !== undefined && p[key] !== null, `${p.id} is missing ${key}`);
    }
    assert.ok(Array.isArray(p.documents), `${p.id} documents is not an array`);
    assert.equal(isValidBdMobile(p.mobile), true, `${p.id} has an invalid mobile: ${p.mobile}`);
    assert.equal(isValidNid(p.nid), true, `${p.id} has an invalid NID: ${p.nid}`);
    assert.ok(new Date(p.joinDate) <= new Date(), `${p.id} joins in the future`);
    assert.ok(p.basic > 0, `${p.id} has no basic salary`);
  }
});

test("employee ids are unique and prefixed by role", () => {
  const people = makeAllPeople();
  assert.equal(new Set(people.map((p) => p.id)).size, people.length);
  const prefixes = { worker: "WK", staff: "ST", manager: "MG", security: "SC", supervisor: "SV", bua: "BU" };
  for (const p of people) {
    assert.ok(p.id.startsWith(prefixes[p.roleKey]), `${p.id} does not match role ${p.roleKey}`);
  }
});

test("the register is deterministic across calls", () => {
  assert.deepEqual(
    makeAllPeople().map((p) => `${p.id}|${p.name}|${p.basic}`),
    makeAllPeople().map((p) => `${p.id}|${p.name}|${p.basic}`)
  );
});

test("nextId continues the sequence instead of colliding", () => {
  const people = makeAllPeople();
  const id = nextId(people, "worker");
  assert.ok(id.startsWith("WK-"));
  assert.equal(people.some((p) => p.id === id), false);
  assert.equal(nextId([], "staff"), "ST-1000");
});

test("emptyPerson is a valid starting draft for the form", () => {
  const draft = emptyPerson("worker");
  assert.equal(draft.roleKey, "worker");
  assert.deepEqual(draft.documents, []);
  assert.equal(draft.mobile, "");
  assert.equal(draft.id, "");
});

/* ── derived data ─────────────────────────────────────────────── */
test("stock state falls out of the reorder level", () => {
  assert.equal(stockState({ inStock: 0, reorder: 100 }), "Out of stock");
  assert.equal(stockState({ inStock: 100, reorder: 100 }), "Reorder");
  assert.equal(stockState({ inStock: 99, reorder: 100 }), "Reorder");
  assert.equal(stockState({ inStock: 101, reorder: 100 }), "In stock");
});

test("stock summary buckets add up to the number of lines", () => {
  const s = stockSummary();
  assert.equal(s.healthy + s.reorder + s.out, s.lines);
});

test("line efficiency is output over target and the summary agrees", () => {
  assert.equal(efficiency({ output: 900, target: 1000 }), 0.9);
  assert.equal(efficiency({ output: 5, target: 0 }), 0);
  const s = productionSummary();
  assert.ok(Math.abs(s.efficiency - s.output / s.target) < 1e-9);
  assert.ok(s.output > 0 && s.operators > 0);
  assert.ok(efficiency(s.best) >= efficiency(s.worst));
});

test("the defect Pareto is sorted and its cumulative reaches 100%", () => {
  const p = paretoData([
    { defect: "small", count: 1 },
    { defect: "big", count: 8 },
    { defect: "mid", count: 3 },
  ]);
  assert.deepEqual(p.map((d) => d.defect), ["big", "mid", "small"]);
  assert.ok(p[0].cumulative < p[1].cumulative);
  assert.equal(Math.round(p[p.length - 1].cumulative), 100);
});

test("quality summary derives pass rate and DHU consistently", () => {
  const q = qualitySummary();
  assert.ok(Math.abs(q.passRate - (q.checked - q.rejected) / q.checked) < 1e-9);
  assert.ok(Math.abs(q.dhu - (q.rejected / q.checked) * 100) < 1e-9);
  assert.ok(q.passRate > 0.9 && q.passRate <= 1);
});

/* ── auth/roles ───────────────────────────────────────────────── */
test("admin sees every module and may do everything", () => {
  const admin = ROLES.admin;
  for (const action of ["create", "edit", "delete", "export", "seeSalary", "approveLeave", "uploadDocs"]) {
    assert.equal(can(admin, action), true, `admin should be able to ${action}`);
  }
  assert.equal(canSee(admin, "shipment"), true);
  assert.equal(canSee(admin, "gate"), true);
});

test("salary is hidden from security, supervisor and merchandiser", () => {
  for (const key of ["security", "supervisor", "merchandiser"]) {
    assert.equal(can(ROLES[key], "seeSalary"), false, `${key} must not see salary`);
  }
  assert.equal(can(ROLES.hr, "seeSalary"), true);
});

test("only admin can delete records", () => {
  const deleters = Object.values(ROLES).filter((r) => can(r, "delete")).map((r) => r.key);
  assert.deepEqual(deleters, ["admin"]);
});

test("supervisor and security are read-only apart from export", () => {
  for (const key of ["supervisor", "security"]) {
    for (const action of ["create", "edit", "delete"]) {
      assert.equal(can(ROLES[key], action), false, `${key} should not ${action}`);
    }
  }
  assert.equal(can(ROLES.supervisor, "export"), true);
  assert.equal(can(ROLES.security, "export"), false);
});

test("a merchandiser cannot open the people or payroll screens", () => {
  const m = ROLES.merchandiser;
  for (const page of ["worker", "staff", "manager", "attendance", "leave", "gate"]) {
    assert.equal(canSee(m, page), false, `merchandiser should not see ${page}`);
  }
  assert.equal(canSee(m, "shipment"), true);
});

test("canSee and can fail closed on a missing role", () => {
  assert.equal(canSee(undefined, "dashboard"), false);
  assert.equal(can(null, "delete"), false);
  assert.equal(canSee(ROLES.admin, "nonexistent-page"), false);
});

test("navFor only returns pages the role may open, in group order", () => {
  for (const role of Object.values(ROLES)) {
    const groups = navFor(role);
    assert.ok(groups.length > 0, `${role.key} has an empty sidebar`);
    for (const g of groups) {
      assert.ok(g.items.length > 0, "empty group should have been dropped");
      for (const item of g.items) {
        assert.equal(canSee(role, item.key), true, `${role.key} was offered ${item.key}`);
        assert.equal(item.group, g.group);
      }
    }
    const order = groups.map((g) => g.group);
    assert.deepEqual([...order].sort(), [...order].sort(), "group order is deterministic");
  }
});

test("every role lands on a page it is allowed to see", () => {
  for (const role of Object.values(ROLES)) {
    assert.equal(canSee(role, landingPage(role)), true, `${role.key} lands somewhere it cannot see`);
  }
});

/* ── lib/barcode ──────────────────────────────────────────────── */
test("code39Supported accepts the ID alphabet and rejects the rest", () => {
  assert.equal(code39Supported("WK-1000"), true);
  assert.equal(code39Supported("NK-118"), true);
  assert.equal(code39Supported("2026-08-24"), true);
  assert.equal(code39Supported(""), false);
  assert.equal(code39Supported("WK@1000"), false); // '@' has no bar pattern here
  assert.equal(code39Supported("café"), false); // accented / lowercase-only-via-case is fine, but 'é' is not
});

test("code39Svg wraps the data in start/stop characters and draws 5 bars per character", () => {
  const svg = code39Svg("AB");
  assert.ok(svg.startsWith("<svg"), "should return standalone SVG markup");
  const barCount = (svg.match(/<rect x=/g) || []).length - 1; // minus the white background rect
  // "*AB*" = 4 characters * 5 bars each = 20 bars, regardless of which are wide.
  assert.equal(barCount, 20);
});

test("code39Svg is wider when the data has more wide elements (digit 0 vs digit 1)", () => {
  // digit '0' resolves to the same wide-bar pair as the 10-value slot (two wide
  // bars), while '1' uses the 1-value pair — both patterns have exactly two wide
  // bars, so instead this checks the encoder is deterministic and length-stable.
  const a = code39Svg("11111111", { showText: false });
  const b = code39Svg("1", { showText: false });
  const widthOf = (svg) => Number(svg.match(/width="([\d.]+)" height="\d+"/)[1]);
  assert.ok(widthOf(a) > widthOf(b), "eight digits should render wider than one");
});


const total = passed + failures.length;
if (failures.length) {
  console.error(`\n  ${failures.length} of ${total} tests failed\n`);
  for (const f of failures) {
    console.error(`  ✗ ${f.name}`);
    console.error(`    ${String(f.err.message).split("\n").join("\n    ")}\n`);
  }
  process.exit(1);
}
console.log(`\n  ${passed} of ${total} tests passed — table, csv, payroll, format, seed data, permissions\n`);
